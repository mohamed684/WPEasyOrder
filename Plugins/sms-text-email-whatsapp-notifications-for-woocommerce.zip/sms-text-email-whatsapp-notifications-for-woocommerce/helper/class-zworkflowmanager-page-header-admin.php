<?php
/**
 * Flow-Notify functionality for Header
 *
 * @package Flow-Notify/helper/class-zworkflowmanager-page-header-admin
 */

/**
 * Class ZWORKFLOWMANAGER_Page_Header_Admin
 */
class ZWORKFLOWMANAGER_Page_Header_Admin {

	/**
	 * ZWORKFLOWMANAGER_Page_Header_Admin constructor.
	 */
	public function __construct() {
		add_action( 'in_admin_header', array( $this, 'page_header' ) );
	}

	/**
	 * Page header
	 */
	public function page_header() {
		if ( ! $this->is_plugin_settings_page( 'toplevel_page_wc-workflows' ) ) {
			return;
		}
		$page_title = ( isset( $_GET['tab'] ) ) ? str_replace( '_', ' ', sanitize_text_field( $_GET['tab'] ) ) : '';
		$page_title = ( 'emails' === $page_title ) ? 'Notifications' : $page_title;
		?>

		<div class="fnh-layout__wrapper">
			<h1><?php echo esc_html__( $page_title, 'flow_notify_text' ); ?></h1>
		</div>
		<?php
	}

	/**
	 * Detect plugin setting page
	 *
	 * @param null $setting_slug setting_slug.
	 *
	 * @return bool
	 */
	private function is_plugin_settings_page( $setting_slug = null ) {
		$current_screen = get_current_screen();

		if ( is_null( $current_screen ) || is_null( $setting_slug ) ) {
			return false;
		}

		return ( $current_screen->id === $setting_slug );
	}


	/**
	 * Getting absolute part for requested asset
	 *
	 * @param null|string $asset_related_part asset_related_part.
	 *
	 * @return string
	 */
	private function get_asset_url( $asset_related_part = null ) {
		if ( is_null( $asset_related_part ) ) {
			return '';
		}

		return plugin_dir_url( dirname( __FILE__ ) ) . 'assets/' . $asset_related_part;
	}


	/**
	 * Check active class for highlighting according nav link
	 *
	 * @param string $tab_name tab name.
	 * @param bool   $is_it_primary_link primary link.
	 *
	 * @return string
	 */
	private function is_active_class( $tab_name, $is_it_primary_link = false ) {
		/* Retrieve current url and parse it */
		if ( isset( $_SERVER['REQUEST_URI'] ) && ! empty( $_SERVER['REQUEST_URI'] ) ) {
			$active_admin_url = admin_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) );
		}

		$url_components = wp_parse_url( $active_admin_url );

		/* Parse query parameters from the string */
		parse_str( $url_components['query'], $params );

		/* Check active class */
		$active_class = ( ! isset( $params['tab'] ) && $is_it_primary_link ) ? 'fnh-active-link' : '';
		$active_class = ( ! $active_class && $params['tab'] !== $tab_name ) ? '' : 'fnh-active-link';

		return $active_class;
	}

}

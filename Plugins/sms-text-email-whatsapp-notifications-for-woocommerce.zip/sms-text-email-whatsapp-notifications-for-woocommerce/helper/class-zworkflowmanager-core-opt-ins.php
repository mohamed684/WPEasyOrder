<?php
/**
 * Flow-Notify opt-ins functionality
 *
 * @package Flow-Notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class ZWORKFLOWMANAGER_Core_Opt_Ins
 */
class ZWORKFLOWMANAGER_Core_Opt_Ins extends WP_List_Table {

	/**
	 * ZWORKFLOWMANAGER_Core_Opt_Ins constructor.
	 */
	public function __construct() {

		parent::__construct(
			array(
				'singular' => 'opt_ins',
				'plural'   => 'opt_ins_table',
				'ajax'     => true,
			)
		);
		$this->prepare_items();
	}

	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$per_page    = 20;
		$total_items = 0;

		/* Init column headers. */
		$this->_column_headers          = array( $this->get_columns(), array(), array() );
		$subscribe_to_newsletter_option = get_option( 'subscribe_to_newsletter' );
		$global_subscriber              = get_option( 'global_subscribe_notification' );

		$results = get_users();

		if ( is_array( $subscribe_to_newsletter_option ) ) {
			foreach ( $subscribe_to_newsletter_option as $newsletter ) {
				array_push( $results, $newsletter );
			}
		}

		if ( is_array( $global_subscriber ) ) {
			foreach ( $global_subscriber as $subscriber ) {
				array_push( $results, $subscriber );
			}
		}

		$items = array();

		foreach ( $results as $result ) {

			$phone                        = is_array( $result ) ? $result['billing_phone']
				: get_user_meta( $result->ID, 'billing_phone', true );
			$email                        = is_array( $result ) ? $result['user_email'] : $result->user_email;
			$type                         = is_array( $result ) && isset( $result['type'] ) ? $result['type']
				: ( $phone ? 'Sms (product page)' : 'Email (product page)' );
			$settings_status              = new ZWORKFLOWMANAGER_Settings();
			$settings                     = $settings_status->get_settings();
			$all_notifications            = is_array( $result ) ? $result['all_notifications']
				: get_user_meta( $result->ID, 'all_notifications', true );
			$product_notifications        = is_array( $result ) ? $result['product_notifications']
				: get_user_meta( $result->ID, 'product_notifications', true );
			$communication_preference     = isset( $result->ID ) ? get_user_meta( $result->ID, 'communication_preference', true ) : '';
			$default_communication_method = ( isset( $settings['default_communication_method'] ) ) ? $settings['default_communication_method'] . ' (default)' : '';
			$communication_type           = $communication_preference ? $communication_preference
				: $default_communication_method;

			if ( ( ! $product_notifications && ! $all_notifications ) || ( ! $phone && ! $email ) ) {
				continue;
			}

			$item['id']                 = $result->ID ?? '';
			$item['username']           = $result->user_nicename ?? '';
			$item['name']               = is_array( $result ) && isset( $result['user_name'] ) ? $result['user_name'] : ( $result->display_name ?? '' );
			$item['phone']              = $phone;
			$item['email']              = $email;
			$item['communication_type'] = is_array( $result ) ? $type : $communication_type;
			$item['order']              = $all_notifications;
			$item['product']            = $product_notifications;

			array_push( $items, $item );
			$total_items ++;
		}

		$this->items = $items;

		/* Pagination. */
		$this->set_pagination_args(
			array(
				'total_items' => $total_items,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_items / $per_page ),
			)
		);

	}

	/**
	 * Get columns
	 *
	 * @return array|string[]
	 */
	public function get_columns() {
		$columns = array(
			'cb'                 => 'Cb',
			'username'           => 'Username',
			'name'               => 'Name',
			'phone'              => 'Phone number',
			'email'              => 'Email',
			'communication_type' => 'Communication Type',
			'order'              => 'Order',
			'product'            => 'Product',
		);

		return $columns;
	}

	/**
	 * Print overview
	 */
	public function print_overview() {
		?>
		<form id="<?php echo esc_attr( $this->_args['plural'] ); ?>" method="post"
			action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="opt_ins_table_action"/>
			<?php $nonce = wp_create_nonce( 'zwf_opt_nonce' ); ?>
			<input type="hidden" name="zwf_nonce" value="<?php echo esc_attr( $nonce ); ?>">

			<?php $this->display(); ?>
		</form>
		<?php
	}

	/**
	 * Column default
	 *
	 * @param array|object $result result.
	 * @param string       $column_name column name.
	 *
	 * @return string|void
	 */
	public function column_default( $result, $column_name ) {
		switch ( $column_name ) {
			case 'username':
				$user_link = admin_url( '/user-edit.php?user_id=' . $result['id'] . '' );
				$label     = __( 'Edit', 'flow_notify_text' );

				return $result['username'] ? '<div class="zworkflowstatus_entry">
							<a href="' . $user_link . '">' . $result['username'] . '</a>
							<br/>
							<a href="' . $user_link . '"
							   class="zworkflowmanager_display_link_on_hover">' . $label . '</a>
						</div>' : '<span>-</span>';
			case 'name':
				return '<span>' . ucfirst( $result['name'] ? $result['name'] : '-' ) . '</span>';
			case 'phone':
				return '<span>' . ucfirst( $result['phone'] ? $result['phone'] : '-' ) . '</span>';
			case 'email':
				return $result['email'] ? '<a href="mailto:' . $result['email'] . '">' . $result['email'] . '</a>'
					: '<span>-</span>';
			case 'communication_type':
				return '<span>' . ucfirst( $result['communication_type'] ) . '</span>';
			case 'order':
				return '<span>' . ucfirst( $result['order'] ? 'Y' : 'N' ) . '</span>';
			case 'product':
				return '<span>' . ucfirst( $result['product'] ? 'Y' : 'N' ) . '</span>';
		}

		return '';
	}

	/**
	 * Column cb
	 *
	 * @param array|object $item item.
	 */
	public function column_cb( $item ) {
		/* Restores the more descriptive, specific name for use within this method. */
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $item['id'] ); ?>">
			<?php
			/* translators: %s: User name. */
			printf( esc_html__( 'Select %s', 'flow_notify_text' ), esc_html( $item['username'] ) );
			?>
		</label>
		<input type="checkbox" name="user_ids[]"
			id="cb-select-<?php echo esc_attr( $item['id'] ); ?>"
			value="<?php echo esc_attr( $item['id'] ? $item['id'] : $item['email'] ); ?>"/>
		<?php
	}

	/**
	 * Display table navigation
	 *
	 * @param string $which which.
	 */
	public function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			echo '<div class="alignright" style="margin-bottom: 1rem;">';
			$this->pagination( 'top' );
			echo '</div>';
			echo '<div class="alignleft" style="margin-bottom: 1rem;">';
			$this->bulk_actions( 'top' );
			echo '</div>';
		}
	}

	/**
	 * Bulk actions
	 *
	 * @param string $which which.
	 */
	public function bulk_actions( $which = '' ) {
		$bulk_actions['bulk actions']      = 'Bulk actions';
		$bulk_actions['opted_out_both']    = 'Set as opted-out both';
		$bulk_actions['opted_out_order']   = 'Set as opted-out Order';
		$bulk_actions['opted_out_product'] = 'Set as opted-out Product';
		?>
		<select name="bulk_actions">
			<?php foreach ( $bulk_actions as $key => $item ) { ?>
				<option value="<?php echo esc_attr( $key ); ?>">
					<?php echo esc_textarea( $item ); ?>
				</option>
			<?php } ?>
		</select>
		<input type="submit" class="button action" value="<?php esc_html_e( 'Apply', 'flow_notify_text' ); ?>"/>
		<?php
	}
}

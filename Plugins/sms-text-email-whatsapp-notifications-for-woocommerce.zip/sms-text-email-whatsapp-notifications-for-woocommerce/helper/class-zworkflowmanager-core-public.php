<?php
/**
 * Flow-Notify Public Settings
 *
 * @package Flow-Notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* use Twilio\TwiML\MessagingResponse; */

/**
 * Class ZWORKFLOWMANAGER_Core_Public
 */
class ZWORKFLOWMANAGER_Core_Public {

	/**
	 * ZWORKFLOWMANAGER_Core_Public constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init_hooks' ), 1 );
	}

	/**
	 * Init hooks
	 */
	public function init_hooks() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Core_Admin' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'load_resources' ) );
		add_filter( 'woocommerce_my_account_my_orders_query', array( $this, 'my_account_my_orders_query' ), 1 );
		add_filter( 'wc_order_statuses', array( $this, 'get_order_statuses' ) );
		add_filter( 'woocommerce_order_is_paid_statuses', array( $this, 'order_paid_statuses' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_payment', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_cancel', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_order_is_pending_statuses', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_locate_template', array( $this, 'woo_addon_plugin_template' ), 20, 3 );
		add_action( 'woocommerce_new_order', array( $this, 'add_transaction_id_woocommerce_order' ), 10, 1 );
		add_filter( 'woocommerce_checkout_fields', array( $this, 'add_custom_checkout_fields' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'so_order_created' ), 10, 2 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'do_so_order_status_changed' ), 10, 3 );
		add_action( 'init', array( $this, 'register_notification_endpoint' ) );
		add_action( 'init', array( $this, 'unsubscribe_email' ) );
		if ( isset( $_GET['wc_twilio_sms_response'] ) ) {
			add_action( 'init', array( $this, 'reply_to_message' ) ); }
		add_action( 'comment_post', array( $this, 'so_new_review_submitted' ), 10, 3 );
		add_action( 'comment_post', array( $this, 'so_new_review_posted' ), 10, 3 );
	}

	/**
	 * Do so_order_status_changed
	 */
	public function do_so_order_status_changed( $order_id, $old_status, $new_status ) {
		$core_admin = new ZWORKFLOWMANAGER_Core_Admin();
		$core_admin->so_order_status_changed( $order_id, $old_status, $new_status );
	}

	/**
	 * Add custom checkout fields
	 */
	public function add_custom_checkout_fields( $fields ) {
		return $fields;
	}

	/**
	 * Return SMS Message twilio
	 */
	public function reply_to_message() {

		$twilio_settings           = get_option( 'twilio_settings' );
		$status_return_sms_message = $twilio_settings['status_return_sms_message'];
		$response_text             = $twilio_settings['response_message'];
		$response                  = '<response><message>' . $response_text . '</message></response>';

		if ( is_null( $status_return_sms_message ) ) {
			return;
		}

		$allowed_html = array(
			'response' => array(),
			'message'  => array(),
		);

		print wp_kses( $response, $allowed_html );
	}

	/**
	 * Register New Endpoint.
	 *
	 * @return void.
	 */
	public function register_notification_endpoint() {
		add_rewrite_endpoint( 'notification', EP_ROOT | EP_PAGES );

		/* Removes rewrite rules and then recreate rewrite rules */
		flush_rewrite_rules();
	}

	/**
	 * Unsubscribe email
	 */
	public function unsubscribe_email() {
		$email                          = isset( $_REQUEST['unsubscribe_email'] )
			? sanitize_text_field( wp_unslash( $_REQUEST['unsubscribe_email'] ) ) : '';
		$type                           = isset( $_REQUEST['type'] )
			? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';
		$subscribe_to_newsletter_option = get_option( 'subscribe_to_newsletter' );
		$global_subscriber              = get_option( 'global_subscribe_notification' );
		$order_hash_email               = get_option( 'order_hash_email' );

		if ( $order_hash_email && $email ) {
			foreach ( $order_hash_email as $key => $order ) {
				if ( ! strripos( $order['email'], $email ) ) {
					continue;
				}

				unset( $order_hash_email[ $key ] );
			}
			update_option( 'order_hash_email', $order_hash_email );
		}

		if ( 'product' === $type ) {
			foreach ( $subscribe_to_newsletter_option as $key => $item ) {

				if ( ! in_array( $email, $item, true ) ) {
					continue;
				}
				unset( $subscribe_to_newsletter_option[ $key ] );
			}
			update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );
		} elseif ( 'order' === $type ) {
			foreach ( $global_subscriber as $key => $item ) {

				if ( ! in_array( $email, $item, true ) ) {
					continue;
				}
				unset( $global_subscriber[ $key ] );
			}
			update_option( 'global_subscribe_notification', $global_subscriber );
		}
	}

	/**
	 * Woocommerce addon plugin template
	 *
	 * @param array  $template template.
	 * @param string $template_name template_name.
	 * @param string $template_path template_path.
	 *
	 * @return string
	 */
	public function woo_addon_plugin_template( $template, $template_name, $template_path ) {
		global $woocommerce;
		$_template = $template;
		if ( ! $template_path ) {
			$template_path = $woocommerce->template_url;
		}

		$plugin_path = untrailingslashit( plugin_dir_path( ZWORKFLOWMANAGER_BASE_FILE ) ) . '/woocommerce/';

		/* Look within passed path within the theme - this is priority */
		$template = locate_template(
			array(
				$template_path . $template_name,
				$template_name,
			)
		);

		if ( ! $template && file_exists( $plugin_path . $template_name ) ) {
			$template = $plugin_path . $template_name;
		}

		if ( ! $template ) {
			$template = $_template;
		}

		return $template;
	}

	/**
	 * Account my orders query
	 *
	 * @param array $array orders.
	 *
	 * @return mixed
	 */
	public function my_account_my_orders_query( $array ) {
		$array['post_status'] = array_keys( wc_get_order_statuses() );

		return $array;
	}

	/**
	 * Load resources
	 */
	public function load_resources() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		global $wp_scripts;

		/* Register admin styles. */
		wp_enqueue_style( 'jquery-ui-datepicker-style', '//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css', array(), '1.0.0' );
		wp_enqueue_style( 'wp-color-picker' );

		wp_enqueue_style( 'styles', plugins_url( 'assets/styles/app.css', ZWORKFLOWMANAGER_BASE_FILE ), array(), '1.0.0' );

		wp_enqueue_script( 'jquery-ui-datepicker' );

		wp_enqueue_script( 'libs_js', plugins_url( 'assets/js/libsApp.js', ZWORKFLOWMANAGER_BASE_FILE ), array( 'jquery' ), '1.0.0', true );

		if ( isset( $_GET['user_id'] ) ) {
			$user_id = sanitize_text_field( wp_unslash( $_GET['user_id'] ) );
		} else {
			$user_id = get_current_user_id();
		}

		$whatsapp_country    = ( get_user_meta( $user_id, 'zworkflow_whatsapp_country', true ) ) ? get_user_meta( $user_id, 'zworkflow_whatsapp_country', true ) : '';
		$billing_country     = ( get_user_meta( $user_id, 'zworkflow_billing_country', true ) ) ? get_user_meta( $user_id, 'zworkflow_billing_country', true ) : '';
		$default_country_iso = ( isset( get_option( 'notification_email_settings' )['default_code'] ) ) ? get_option( 'notification_email_settings' )['default_code'] : 'US';

		$register_scripts = array(
			'public_script' => array(
				'src'     => plugins_url( 'assets/js/appPublic.js', ZWORKFLOWMANAGER_BASE_FILE ),
				'deps'    => array( 'jquery' ),
				'version' => '1.0.0',
			),
		);

		foreach ( $register_scripts as $name => $props ) {
			wp_register_script( $name, $props['src'], $props['deps'], $props['version'], true );
		}

		wp_enqueue_script( 'public_script' );

		$ajax_order_statuses        = wc_get_order_statuses();
		$ajax_order_statuses['any'] = 'Any';
		ksort( $ajax_order_statuses );

		wp_localize_script(
			'main_js',
			'ajax_object',
			array(
				'ajax_url'            => admin_url( 'admin-ajax.php' ),
				'we_value'            => 1234,
				'order_statuses'      => $ajax_order_statuses,
				'whatsapp_country'    => $whatsapp_country,
				'billing_country'     => $billing_country,
				'default_country_iso' => $default_country_iso,
			)
		);

		wp_localize_script(
			'public_script',
			'ajax_object',
			array(
				'ajax_url'            => admin_url( 'admin-ajax.php' ),
				'whatsapp_country'    => $whatsapp_country,
				'billing_country'     => $billing_country,
				'default_country_iso' => $default_country_iso,
			)
		);

	}

	/**
	 * Get order statuses
	 *
	 * @param array $order_statuses order_statuses.
	 *
	 * @return array
	 */
	public function get_order_statuses( $order_statuses ) {
		$exist_status_query = new WP_Query(
			array(
				'posts_per_page' => - 1,
				'post_type'      => 'zworkflowstatus',
			)
		);
		$custom_statuses    = $exist_status_query->get_posts();
		if ( count( $custom_statuses ) === 0 ) {
			return $order_statuses;
		}
		$return_status = array();
		foreach ( $custom_statuses as $custom_status ) {
			$slug                   = get_post_meta( $custom_status->ID, 'zworkflowstatus_slug', true );
			$title                  = esc_textarea( $custom_status->post_title );
			$return_status[ $slug ] = $title;
		}

		return $return_status;

	}

	/**
	 * Order needs payment statuses
	 *
	 * @return array
	 */
	public function order_needs_payment_statuses() {

		$custom_needs_payment_statuses = array();
		$custom_statuses               = wc_get_order_statuses();

		foreach ( $custom_statuses as $order_status_slug => $order_status_name ) {

			$custom_status = new ZWORKFLOWMANAGER_Order_Status( $order_status_slug );

			if ( $custom_status->needs_payment() ) {
				$custom_needs_payment_statuses[] = substr( $order_status_slug, 3 );
			}
		}

		$custom_needs_payment_statuses = array_merge( array( 'on-hold', 'pending', 'failed', 'cancelled' ), $custom_needs_payment_statuses );

		return $custom_needs_payment_statuses;

	}

	/**
	 * Order paid statuses
	 *
	 * @return array
	 */
	public function order_paid_statuses() {

		$custom_paid_statuses = array();
		$custom_statuses      = wc_get_order_statuses();

		foreach ( $custom_statuses as $order_status_slug => $order_status_name ) {

			$custom_status = new ZWORKFLOWMANAGER_Order_Status( $order_status_slug );

			if ( $custom_status->is_paid() ) {
				$custom_paid_statuses[] = substr( $order_status_slug, 3 );
			}
		}

		return $custom_paid_statuses;
	}

	/**
	 * Sending notification when new review submitted
	 *
	 * @param int        $comment_id The comment ID.
	 * @param int|string $comment_approved 1 if the comment is approved, 0 if not, 'spam' if spam.
	 * @param array      $comment_data Comment data.
	 *
	 * @return array|string[]
	 */
	public function so_new_review_submitted( $comment_id, $comment_approved, $comment_data ) {

		$adm            = new ZWORKFLOWMANAGER_Core_Admin();
		$data           = array();
		$email          = get_bloginfo( 'admin_email' );
		$admin          = get_user_by( 'email', $email );
		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $email . ',' . $phone );

		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'new_review_submitted',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type = get_post_meta( $current_post->ID, 'zsending_type' )[0];

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type
							: '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
					)
				);
			}
		}

		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		return $adm->send_from_admin( $admin_contacts, null, $data, null );
	}

	/**
	 * Sending notification when order creating
	 *
	 * @param string $order_id order_id.
	 *
	 * @return array|string[]
	 */
	public function so_order_created( $order_id ) {

		$core_admin = new ZWORKFLOWMANAGER_Core_Admin();

		$data                            = array();
		$order                           = wc_get_order( $order_id );
		$communication_preference_method = $order->get_meta( 'communication_preference' );
		$users                           = array( $order->get_billing_email() . ',' . $order->get_billing_phone() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'order_created',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$type_preference_status_toggle = get_post_meta( $current_post->ID, 'type_preference_status_toggle' )[0];
				$zsending_type                 = ( $communication_preference_method && 'enabled' === $type_preference_status_toggle )
					? $communication_preference_method : get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id           = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => ( 'billing' === $order->get_meta( 'zworkflow_select_phone_type' ) ) ? $order->get_meta( 'zworkflow_billing_code' ) . $order->get_billing_phone() : $order->get_meta( 'billing_whatsapp_phone' ),
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id    = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $order->get_billing_phone(),
						'notification_email'  => $order->get_billing_email(),
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);
			$item['post_id'] = $send_post_id;
		}

		return $core_admin->send_from_admin( $users, null, $data, null, $order_id );
	}

	/**
	 * Sending notification when new review posted
	 *
	 * @param int        $comment_id The comment ID.
	 * @param int|string $comment_approved 1 if the comment is approved, 0 if not, 'spam' if spam.
	 * @param array      $comment_data Comment data.
	 *
	 * @return array|string[]
	 */
	public function so_new_review_posted( $comment_id, $comment_approved, $comment_data ) {

		$adm           = new ZWORKFLOWMANAGER_Core_Admin();
		$data          = array();
		$user_id       = $comment_data['user_ID'];
		$user          = get_userdata( $user_id );
		$email         = $user->user_email;
		$phone         = get_user_meta( $user_id, 'billing_phone', true );
		$user_contacts = array( $email . ',' . $phone );

		if ( 1 !== $comment_approved ) {
			return $data;
		}

		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'new_review_posted',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type = get_post_meta( $current_post->ID, 'zsending_type' )[0];

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type
							: '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
					)
				);
			}
		}

		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		return $adm->send_from_admin( $user_contacts, null, $data, null );
	}

	/**
	 * Add transaction_id for woocommerce order
	 *
	 * @param string $order_id order_id.
	 */
	public function add_transaction_id_woocommerce_order( $order_id ) {
		$order = new WC_Order( $order_id );
		$order->add_meta_data( '_transaction_id', gmdate( 'Ymdhis' ) );
		$order->save();
	}
}

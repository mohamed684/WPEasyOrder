<?php
/**
 * WooCommerce Order Status Settings
 *
 * @package WooCommerce/Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
}

/**
 * Class ZWORKFLOWMANAGER_Core_Order_Statuses
 */
class ZWORKFLOWMANAGER_Core_Order_Statuses extends WP_List_Table {

	/**
	 * ZWORKFLOWMANAGER_Core_Order_Statuses constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'order_status',
				'plural'   => 'order_statuses_table',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Print overview
	 */
	public function print_overview() {
		$this->prepare_items();
		echo '<div class="zworkflowmanager_overview_wrap" style="width: 95%;">';
		echo '<h2 class="screen-reader-text">' . esc_html__( 'Order Statuses', 'flow_notify_text' ) . '</h2>';
		if ( count( $this->items ) !== 0 ) {
			$this->display();
		} else {
			echo '<div style="color:#000; padding:1px 12px; background: #fff; border-left: solid 4px #ffb900;margin-top:20px;">';
			echo '<p style="margin: .5em 0; padding: 2px;">' . esc_html__( 'No Order Statuses', 'flow_notify_text' ) . '</p>';
			echo '</div>';
		}
		echo '</div>';
	}

	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( $current_page - 1 ) * $per_page : 0;

		/* Init column headers. */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$results = get_posts(
			array(
				'post_type'   => 'zworkflowstatus',
				'numberposts' => $per_page,
				'offset'      => $offset,
			)
		);

		$items = array();

		foreach ( $results as $result ) {
			$custom_status            = new ZWORKFLOWMANAGER_Order_Status( $result->ID );
			$item['id']               = $result->ID;
			$item['name']             = $custom_status->get_name();
			$item['slug']             = $custom_status->get_slug();
			$item['description']      = $custom_status->get_description();
			$item['text_color']       = $custom_status->get_text_color();
			$item['background_color'] = $custom_status->get_background_color();
			$item['type']             = $custom_status->get_type();

			array_push( $items, $item );
		}

		$this->items = $items;

		/* Pagination. */
		$total_results = $this->get_total_number_of_results();

		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	/**
	 * Get columns
	 *
	 * @return array|string[]
	 */
	public function get_columns() {
		$columns = array(
			'name'        => 'Name',
			'slug'        => 'Slug',
			'description' => 'Description',
			'label'       => 'Label',
			'type'        => 'Type',
		);

		return $columns;
	}

	/**
	 * Get total number of results
	 *
	 * @return int|void
	 */
	public function get_total_number_of_results() {
		$results = get_posts(
			array(
				'post_type'   => 'zworkflowstatus',
				'numberposts' => - 1,
			)
		);

		return count( $results );
	}

	/**
	 * Column default
	 *
	 * @param array|object $result result.
	 * @param string       $column_name column_name.
	 *
	 * @return string|void
	 */
	public function column_default( $result, $column_name ) {
		switch ( $column_name ) {
			case 'name':
				$edit_link = add_query_arg( array( 'edit_status' => $result['id'] ) );
				$label     = __( 'Edit', 'flow_notify_text' );

				return '<div class="zworkflowstatus_entry"><a href="' . $edit_link . '">' . $result['name'] . '</a><br/><a href="' . $edit_link . '" class="zworkflowmanager_display_link_on_hover">' . $label . '</a></div>';
			case 'slug':
				return '<span>' . esc_textarea( $result['slug'] ) . '</span>';
			case 'description':
				return '<span>' . esc_textarea( $result['description'] ) . '</span>';
			case 'label':
				return '<span class="zworkflowmanager_label" style="color:' . $result['text_color'] . '; background-color:' . $result['background_color'] . '">' . esc_textarea( $result['name'] ) . '</span>';
			case 'type':
				return '<span class="zworkflowmanager_label ' . $result['type'] . '">' . esc_textarea( ucfirst( $result['type'] ) ) . '</span>';
		}

		return '';
	}

	/**
	 * Display tablenav
	 *
	 * @param string $which which.
	 */
	public function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			echo '<div class="alignright" style="margin-bottom: 1rem;">';
			$this->pagination( 'top' );
			echo '</div>';
		}
	}

}



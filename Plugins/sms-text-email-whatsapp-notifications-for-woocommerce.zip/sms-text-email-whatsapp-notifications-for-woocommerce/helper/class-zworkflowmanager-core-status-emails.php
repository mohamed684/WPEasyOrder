<?php
/**
 * WooCommerce Status Email Settings
 *
 * @package WooCommerce/Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
}

/**
 * Class ZWORKFLOWMANAGER_Core_Status_Emails
 */
class ZWORKFLOWMANAGER_Core_Status_Emails extends WP_List_Table {

	/**
	 * ZWORKFLOWMANAGER_Core_Status_Emails constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'order_email',
				'plural'   => 'order_emails_table',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Print overview
	 */
	public function print_overview() {
		$this->prepare_items();
		echo '<div class="zworkflowmanager_overview_wrap" style="width: 95%;">';
		echo '<h2 class="screen-reader-text">Status Emails</h2>';
		if ( count( $this->items ) !== 0 ) {
			$this->display();
		} else {
			echo '<div style=" color:#000; padding:1px 12px; background: #fff; border-left: solid 4px #ffb900;margin-top:20px;">';
			echo '<p style="margin: .5em 0; padding: 2px;">Create custom notifications</p>';
			echo '</div>';
		}
		echo '</div>';
	}

	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( $current_page - 1 ) * $per_page : 0;

		/* Init column headers. */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$results = get_posts(
			array(
				'post_type'   => 'zworkflowemail',
				'numberposts' => $per_page,
				'offset'      => $offset,
			)
		);

		$items = array();

		foreach ( $results as $result ) {
			$custom_email         = new ZWORKFLOWMANAGER_Status_Email( $result->ID );
			$item['id']           = $result->ID;
			$item['name']         = $custom_email->get_name();
			$item['type']         = $custom_email->get_type();
			$item['sending_type'] = $custom_email->get_sending_type();
			$item['status']       = $custom_email->get_status();
			$item['trigger']      = $custom_email->get_trigger_status();

			array_push( $items, $item );
		}

		$this->items = $items;

		/* Pagination. */
		$total_results = $this->get_total_number_of_results();

		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	/**
	 * Get columns
	 *
	 * @return array|string[]
	 */
	public function get_columns() {
		$columns = array(
			'name'         => 'Name',
			'type'         => 'Recipient',
			'sending_type' => 'Type',
			'trigger'      => 'Trigger',
			'status'       => 'Enabled',
		);

		return $columns;
	}

	/**
	 * Get total number of results
	 *
	 * @return int|void
	 */
	public function get_total_number_of_results() {
		$results = get_posts(
			array(
				'post_type'   => 'zworkflowemail',
				'numberposts' => - 1,
			)
		);

		return count( $results );
	}

	/**
	 * Column default
	 *
	 * @param array|object $result result.
	 * @param string       $column_name column_name.
	 *
	 * @return string|void
	 */
	public function column_default( $result, $column_name ) {
		switch ( $column_name ) {
			case 'name':
				$edit_link = add_query_arg( array( 'edit_email' => $result['id'] ) );
				$label     = __( 'Edit', 'flow_notify_text' );

				return '<div class="zworkflowstatus_entry">
							<a href="' . $edit_link . '">' . $result['name'] . '</a>
							<br/>
							<a href="' . $edit_link . '"
							   class="zworkflowmanager_display_link_on_hover">' . $label . '</a>
						</div>';
			case 'type':
				return ( is_string( $result['type'] ) ) ? '<span>' . ucfirst( $result['type'] ) . '</span>' : implode( ', ', array_map( 'ucfirst', $result['type'] ) );
			case 'sending_type':
				if ( 'whatsapp' === $result['sending_type'] ) {
					return '<span>WhatsApp</span>';
				} else {
					return '<span>' . ucfirst( $result['sending_type'] ) . '</span>';
				}
			case 'trigger':
				$trigger = str_replace( '_', ' ', $result['trigger'] );

				return '<span style="text-transform: capitalize">' . $trigger . '</span>';
			case 'status':
				$checked = 'enabled' === $result['status'] ? 'checked' : '';

				return '<label class="zworkflowmanager_switch">
							<input type="checkbox" ' . $checked . '
								   class="zworkflowemail_status_toggle"
								   data-attr="' . $result['id'] . '">
							<span class="zworkflowmanager_slider round"></span>
						</label>';
		}

		return '';
	}

	/**
	 * Display tablenav
	 *
	 * @param string $which which.
	 */
	public function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			echo '<div class="alignright" style="margin-bottom: 1rem;">';
			$this->pagination( 'top' );
			echo '</div>';
		}
	}

}

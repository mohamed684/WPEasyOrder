<?php
/**
 * Flow-Notify functionality for Notification tab
 *
 * @package Flow-Notify/helper/class-zworkflowmanager-custom-email
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Custom_Email
 */
class ZWORKFLOWMANAGER_Custom_Email extends WC_Email {

	/**
	 * ZWORKFLOWMANAGER_Custom_Email constructor.
	 *
	 * @param object $custom_email get custom_email.
	 */
	public function __construct( $custom_email ) {
		$this->id = 'wc_' . $custom_email->get_slug();
		if ( 'customer' === $custom_email->get_type() ) {
			$this->customer_email = true;
			$this->template_base  = ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/';
			$this->template_html  = 'templates/customer-order-status-changed.php';
			$this->template_plain = 'templates/plain/customer-order-status-changed.php';
		} else {
			$this->customer_email                            = false;
			$this->template_base                             = ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/';
			$this->template_html                             = 'templates/admin-order-status-changed.php';
			$this->template_plain                            = 'templates/plain/admin-order-status-changed.php';
			$this->placeholders['{order_billing_full_name}'] = '';
			$this->recipient                                 = $this->get_option( 'recipient', get_option( 'admin_email' ) );

		}

		$this->title = $custom_email->get_name();

		$this->description = $custom_email->get_description();

		$this->heading = $custom_email->get_name();
		$this->subject = $custom_email->get_name();

		$this->placeholders = array(
			'{order_date}'   => '',
			'{order_number}' => '',
		);

		foreach ( $custom_email->get_dispatch_list() as $item ) {
			if ( strstr( $item, 'any_to_' ) ) {
				$status = substr( $item, 7 );
				add_action( 'woocommerce_order_status_' . $status, array( $this, 'trigger' ) );
			} elseif ( strstr( $item, '_to_any' ) ) {
				$status = substr( $item, 0, strlen( $item ) - 7 );
				add_action( 'woocommerce_order_status_' . $status, array( $this, 'trigger' ) );
			} else {
				add_action( 'woocommerce_order_status_' . $item, array( $this, 'trigger' ) );
			}
		}

		parent::__construct();
	}

	/**
	 * Trigger the sending of this email.
	 *
	 * @param string $order_id get order_id.
	 */
	public function trigger( $order_id ) {
		$this->setup_locale();

		if ( $order_id ) {
			$order = wc_get_order( $order_id );
		}

		if ( is_a( $order, 'WC_Order' ) ) {
			$this->object = $order;

			$this->placeholders['{order_date}']   = wc_format_datetime( $this->object->get_date_created() );
			$this->placeholders['{order_number}'] = $this->object->get_order_number();
			if ( ! $this->customer_email ) {
				$this->placeholders['{order_billing_full_name}'] = $this->object->get_formatted_billing_full_name();
			}
		}

		if ( $this->customer_email ) {
			$this->recipient = get_user_by( 'id', $order->get_customer_id() )->user_email;
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Get content html.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'order'              => $this->object,
				'email_heading'      => $this->get_heading(),
				'additional_content' => $this->get_additional_content(),
				'sent_to_admin'      => $this->customer_email ? false : true,
				'plain_text'         => false,
				'email'              => $this,
			),
			$this->template_base,
			$this->template_base
		);
	}

	/**
	 * Get content plain.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			array(
				'order'              => $this->object,
				'email_heading'      => $this->get_heading(),
				'additional_content' => $this->get_additional_content(),
				'sent_to_admin'      => $this->customer_email ? false : true,
				'plain_text'         => true,
				'email'              => $this,
			),
			$this->template_base,
			$this->template_base
		);
	}

	/**
	 * Init form fields
	 */
	public function init_form_fields() {
		/**
		 * Translators: %s: list of placeholders
		 */
		if ( ! $this->customer_email ) {
			$placeholder_text  = sprintf( esc_textarea( 'Available placeholders: %s' ), '<code>' . esc_textarea( implode( '</code>, <code>', array_keys( $this->placeholders ) ) ) . '</code>' );
			$this->form_fields = array(
				'enabled'            => array(
					'title'   => __( 'Enable/Disable', 'flow_notify_text' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable this email notification', 'flow_notify_text' ),
					'default' => 'yes',
				),
				'recipient'          => array(
					'title'       => __( 'Recipient(s)', 'flow_notify_text' ),
					'type'        => 'text',
					/* Translators: %s: admin email */
					'description' => sprintf( esc_textarea( 'Enter recipients (comma separated) for this email. Defaults to %s.' ), '<code>' . esc_attr( get_option( 'admin_email' ) ) . '</code>' ),
					'placeholder' => '',
					'default'     => '',
					'desc_tip'    => true,
				),
				'subject'            => array(
					'title'       => __( 'Subject', 'flow_notify_text' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
				),
				'heading'            => array(
					'title'       => __( 'Email heading', 'flow_notify_text' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
				),
				'additional_content' => array(
					'title'       => __( 'Additional content', 'flow_notify_text' ),
					'description' => __( 'Text to appear below the main email content.', 'flow_notify_text' ) . ' ' . $placeholder_text,
					'css'         => 'width:400px; height: 75px;',
					'placeholder' => __( 'N/A', 'flow_notify_text' ),
					'type'        => 'textarea',
					'default'     => $this->get_default_additional_content(),
					'desc_tip'    => true,
				),
				'email_type'         => array(
					'title'       => __( 'Email type', 'flow_notify_text' ),
					'type'        => 'select',
					'description' => __( 'Choose which format of email to send.', 'flow_notify_text' ),
					'default'     => 'html',
					'class'       => 'email_type wc-enhanced-select',
					'options'     => $this->get_email_type_options(),
					'desc_tip'    => true,
				),
			);
		} else {
			$placeholder_text  = sprintf( esc_textarea( 'Available placeholders: %s' ), '<code>' . esc_textarea( implode( '</code>, <code>', array_keys( $this->placeholders ) ) ) . '</code>' );
			$this->form_fields = array(
				'enabled'            => array(
					'title'   => __( 'Enable/Disable', 'flow_notify_text' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable this email notification', 'flow_notify_text' ),
					'default' => 'yes',
				),
				'subject'            => array(
					'title'       => __( 'Subject', 'flow_notify_text' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
				),
				'heading'            => array(
					'title'       => __( 'Email heading', 'flow_notify_text' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
				),
				'additional_content' => array(
					'title'       => __( 'Additional content', 'flow_notify_text' ),
					'description' => __( 'Text to appear below the main email content.', 'flow_notify_text' ) . ' ' . $placeholder_text,
					'css'         => 'width:400px; height: 75px;',
					'placeholder' => __( 'N/A', 'flow_notify_text' ),
					'type'        => 'textarea',
					'default'     => $this->get_default_additional_content(),
					'desc_tip'    => true,
				),
				'email_type'         => array(
					'title'       => __( 'Email type', 'flow_notify_text' ),
					'type'        => 'select',
					'description' => __( 'Choose which format of email to send.', 'flow_notify_text' ),
					'default'     => 'html',
					'class'       => 'email_type wc-enhanced-select',
					'options'     => $this->get_email_type_options(),
					'desc_tip'    => true,
				),
			);
		}
	}

}

<?php
/**
 * WooCommerce Status Settings
 *
 * @package WooCommerce/Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * ZWORKFLOWMANAGER_Settings_Status.
 */
class ZWORKFLOWMANAGER_Settings_Status {
	/**
	 * Setting page id.
	 *
	 * @var string
	 */
	protected $id = '';

	/**
	 * Setting page label.
	 *
	 * @var string
	 */
	protected $label = '';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = 'order_status';
		$this->label = __( 'Status', 'flow_notify_text' );

		add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 90 );
		add_action( 'woocommerce_sections_' . $this->id, array( $this, 'output_sections' ) );

		add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
	}

	/**
	 * Output
	 */
	public function output() {

		global $current_section;

		$settings = $this->get_settings( $current_section );

		WC_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Get settings
	 *
	 * @param string $current_section current_section.
	 *
	 * @return array
	 */
	public function get_settings( $current_section = '' ) {
		if ( 'emails' === $current_section ) {
			echo '<style>button.woocommerce-save-button{display: none !important;}</style>';

			?>
			<h2><?php esc_html_e( 'Emails', 'flow_notify_text' ); ?></h2>
			<?php
		} else {

			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/order-statuses/order-statuses.php';
		}

		return array();
	}

	/**
	 * Add settings page
	 *
	 * @param array $pages pages.
	 *
	 * @return mixed
	 */
	public function add_settings_page( $pages ) {
		$pages[ $this->id ] = $this->label;

		return $pages;
	}

	/**
	 * Output sections.
	 */
	public function output_sections() {
		global $current_section;

		$sections = $this->get_sections();

		if ( empty( $sections ) || 1 === count( $sections ) ) {
			return;
		}

		echo '<ul class="subsubsub">';

		$array_keys = array_keys( $sections );

		foreach ( $sections as $id => $label ) {
			echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=' . $this->id . '&section=' . sanitize_title( $id ) ) ) . '" class="' . esc_attr(
				( $current_section === $id
				? 'current' : '' )
			) . '">' . esc_html( $label ) . '</a> ' . ( end( $array_keys ) === $id ? ''
					: '|' ) . ' </li>';
		}

		echo '</ul><br class="clear" />';
	}

	/**
	 * Get sections
	 *
	 * @return array
	 */
	public function get_sections() {
		$sections = array(
			''       => __( 'Order Statuses', 'flow_notify_text' ),
			'emails' => __( 'Emails', 'flow_notify_text' ),
		);

		return $sections;
	}
}

return new ZWORKFLOWMANAGER_Settings_Status();

<?php
/**
 * Flow-Notify email manager functionality
 *
 * @package Flow-Notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Status_Email_Manager
 */
class ZWORKFLOWMANAGER_Status_Email_Manager {

	/**
	 * Get by from and to status
	 *
	 * @param string $from status from.
	 * @param string $to status to.
	 *
	 * @return array
	 */
	public function get_by_from_and_to_status( $from, $to ) {
		$custom_emails = new WP_Query(
			array(
				'post_type'  => 'zworkflowemail',
				'meta_key'   => 'zcustomemail_status',
				'meta_value' => 'enabled',
			)
		);

		$matches = array();

		if ( $custom_emails->have_posts() ) {
			while ( $custom_emails->have_posts() ) {
				$custom_emails->the_post();
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
				}
				$custom_email = new ZWORKFLOWMANAGER_Status_Email( get_the_ID() );
				if ( $this->is_triggerable( $from, $to, $custom_email->get_dispatch_list() ) ) {
					$matches[] = $custom_email;
				}
			}
		}

		return $matches;
	}

	/**
	 * Is triggerable
	 *
	 * @param string $from from.
	 * @param string $to to.
	 * @param array  $dispatch_list dispatch_list.
	 *
	 * @return bool
	 */
	public function is_triggerable( $from, $to, $dispatch_list ) {
		foreach ( $dispatch_list as $item ) {
			if ( strstr( $item, 'any_to_' ) ) {
				$status = substr( $item, 7 );
				if ( $status === $to ) {
					return true;
				}
			} elseif ( strstr( $item, '_to_any' ) ) {
				$status = substr( $item, 0, strlen( $item ) - 7 );
				if ( $status === $from ) {
					return true;
				}
			} else {
				if ( $item === $from . '_to_' . $to ) {
					return true;
				}
			}
		}

		return false;
	}
}

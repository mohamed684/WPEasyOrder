<?php
/**
 * Flow-Notify Core functionality
 *
 * @package Flow-Notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class ZWORKFLOWMANAGER_Core
 */
class ZWORKFLOWMANAGER_Core {

	/**
	 * Initiated
	 *
	 * @var bool
	 */
	private static $initiated = false;

	/**
	 * Init
	 */
	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
		self::create_custom_post_types();
		self::register_post_status();
	}


	/**
	 * Init hooks
	 */
	private static function init_hooks() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
		}
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Schedule_Time_Frame' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-schedule-time-frame.php';
		}
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Timing_Schedule' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-timing-schedule.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
		}

		$settings_status     = new ZWORKFLOWMANAGER_Settings();
		$schedule_time_frame = new ZWORKFLOWMANAGER_Schedule_Time_Frame();
		$whatsapp            = new ZWORKFLOWMANAGER_Whatsapp();
		$logger              = new ZWORKFLOWMANAGER_Logger();
		$settings_status->checkout_settings();
		$settings_status->product_settings();
		self::add_custom_tab_in_account();

		/* Schedule an action if it's not already scheduled */
		$schedule_time_frame->cron_settings();

		$whatsapp->init_hooks();
		$logger->init_hooks();
	}

	/**
	 * Add custom tab in account
	 */
	public static function add_custom_tab_in_account() {
		add_filter( 'woocommerce_account_menu_items', 'change_item_tab' );
		add_action( 'woocommerce_account_notification_endpoint', 'add_new_item_content' );

		/**
		 * Add New tab in my account page.
		 *
		 * @param array $items my account Items.
		 *
		 * @return array Items including New tab.
		 */
		function change_item_tab( $items ) {
			return array(
				'dashboard'       => __( 'Dashboard', 'flow_notify_text' ),
				'orders'          => __( 'Orders', 'flow_notify_text' ),
				'downloads'       => __( 'Downloads', 'flow_notify_text' ),
				'edit-address'    => __( 'Addresses', 'flow_notify_text' ),
				'edit-account'    => __( 'Account details', 'flow_notify_text' ),
				'notification'    => __( 'Notification', 'flow_notify_text' ),
				'customer-logout' => __( 'Logout', 'flow_notify_text' ),
			);
		}

		/**
		 * Add content to the new tab.
		 */
		function add_new_item_content() {
			$user_id               = get_current_user_id();
			$communication_methods = array();
			$settings              = get_option( 'notification_email_settings' );

			if ( isset( $settings['communication_methods_email'] ) ) {
				$communication_methods['email'] = 'Email';
			}

			if ( isset( $settings['communication_methods_sms'] ) ) {
				$communication_methods['sms'] = 'SMS';
			}

			if ( isset( $settings['communication_methods_whatsapp'] ) ) {
				$communication_methods['whatsapp'] = 'WhatsApp';
			}

			?>
			<div class="woocommerce-notification-content">
				<form method="POST" class="woocommerce-notificationForm notification js-woocommerce-notificationForm"
					action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>">
					<p for="communication_preference"><?php esc_html_e( 'Communication Preference', 'flow_notify_text' ); ?></p>
					<label for="communication_preference">
						<select name="communication_preference" id="communication_preference">
							<option selected
									value=""><?php esc_html_e( 'Select Preference...', 'flow_notify_text' ); ?></option>
							<?php
							foreach ( $communication_methods as $key => $method ) {
								$selected = selected( $key, get_user_meta( $user_id, 'communication_preference' )[0], false );
								?>
								<option <?php echo esc_attr( $selected ); ?>
										value="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $method ); ?></option>
							<?php } ?>
						</select>
					</label>
					<p for="notification_opt_ins"><?php esc_html_e( 'Notification Opt-ins', 'flow_notify_text' ); ?></p>
					<label for="product_notifications">
						<?php
						$checked = get_user_meta( $user_id, 'product_notifications', true ) ? 'checked' : '';
						?>
						<input type="checkbox" name="product_notifications"
							<?php echo esc_attr( $checked ); ?>
							id="product_notifications"
							value="true"><?php esc_html_e( 'Product notifications. Opted in notifications for specific products.', 'flow_notify_text' ); ?>
					</label>

					<label for="all_notifications">
						<?php
						$checked = get_user_meta( $user_id, 'all_notifications', true ) ? 'checked' : '';
						?>
						<input type="checkbox" name="all_notifications"
							<?php echo esc_attr( $checked ); ?>
							id="all_notifications"
							value="true"><?php esc_html_e( 'All notifications. Opted in notifications for all products, promotions and more.', 'flow_notify_text' ); ?>
					</label>
					<button type="submit" class="woocommerce-Button button" name="save_notification_details"
							value="Save changes">Save changes
					</button>
				</form>
			</div>
			<?php
		}
	}

	/**
	 * Create custom post types
	 */
	public static function create_custom_post_types() {
		register_post_type(
			'zworkflowstatus',
			array(
				'labels'              => array(
					'name'          => __( 'Order Statuses', 'flow_notify_text' ),
					'singular_name' => __( 'Order Status', 'flow_notify_text' ),
					'menu_name'     => __( 'Order Statuses', 'flow_notify_text' ),
					'add_new'       => __( 'Add Order Status', 'flow_notify_text' ),
				),
				'public'              => true,
				'show_ui'             => true,
				'capability_type'     => 'post',
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => false,
				'hierarchical'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array(
					'title',
					'custom-fields',
					'page-attributes',
				),
				'show_in_nav_menus'   => false,
				'has_archive'         => false,
				'menu_icon'           => 'dashicons-format-image',
			)
		);

		register_post_type(
			'zworkflowemail',
			array(
				'labels'              => array(
					'name'          => __( 'Order Status Emails', 'flow_notify_text' ),
					'singular_name' => __( 'Order Status Email', 'flow_notify_text' ),
					'menu_name'     => __( 'Order Status Emails', 'flow_notify_text' ),
					'add_new'       => __( 'Add Order Status Email', 'flow_notify_text' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'capability_type'     => 'post',
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => false,
				'hierarchical'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array(
					'title',
					'custom-fields',
					'page-attributes',
				),
				'show_in_nav_menus'   => false,
				'menu_icon'           => 'dashicons-format-image',
			)
		);

		register_post_type(
			'zworkflowsend',
			array(
				'labels'              => array(
					'name'          => __( 'Order Status Send', 'flow_notify_text' ),
					'singular_name' => __( 'Order Status Send', 'flow_notify_text' ),
					'menu_name'     => __( 'Order Status Sends', 'flow_notify_text' ),
					'add_new'       => __( 'Add Order Status Send', 'flow_notify_text' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'capability_type'     => 'post',
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => false,
				'hierarchical'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array(
					'title',
					'custom-fields',
					'page-attributes',
				),
				'show_in_nav_menus'   => false,
				'menu_icon'           => 'dashicons-format-image',
			)
		);

		register_post_type(
			'zworkflowtemplates',
			array(
				'labels'              => array(
					'name'          => __( 'Order Status Message Template', 'flow_notify_text' ),
					'singular_name' => __( 'Order Status Message Template', 'flow_notify_text' ),
					'menu_name'     => __( 'Order Status Message Templates', 'flow_notify_text' ),
					'add_new'       => __( 'Add Order Status Message Template', 'flow_notify_text' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'capability_type'     => 'post',
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => false,
				'hierarchical'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array(
					'title',
					'custom-fields',
					'page-attributes',
				),
				'show_in_nav_menus'   => false,
				'menu_icon'           => 'dashicons-format-image',
			)
		);
	}

	/**
	 * Register post status
	 */
	public static function register_post_status() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
		$adm_admin = new ZWORKFLOWMANAGER_Core_Admin();

		foreach ( wc_get_order_statuses() as $slug => $name ) {

			/* Don't register manually registered statuses */
			if ( $adm_admin->is_core_status( $slug ) ) {
				continue;
			}

			register_post_status(
				$slug,
				array(
					'label'                     => $name,
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* Translators: %s: posts count */
					'label_count'               => _n_noop( '$name <span class="count">(%s)</span>', '$name <span class="count">(%s)</span>', 'flow_notify_text' ),
				)
			);
		}
	}

	/**
	 * Plugin activation
	 */
	public static function plugin_activation() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Core_Admin' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
		}
		$adm = new ZWORKFLOWMANAGER_Core_Admin();
		$adm->insert_original_statuses();
	}

	/**
	 * Plugin deactivation
	 */
	public static function plugin_deactivation() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
		}

		$settings_status = new ZWORKFLOWMANAGER_Settings();
		$settings        = $settings_status->get_settings();

		if ( isset( $settings['delete_setting'] ) && 'on' === $settings['delete_setting'] ) {
			$orders = wc_get_orders( array( 'posts_per_page' => - 1 ) );

			foreach ( $orders as $order ) {
				$status = $order->get_status();
				switch ( $status ) {
					case 'pending':
					case 'processing':
					case 'on-hold':
					case 'completed':
					case 'cancelled':
					case 'refunded':
					case 'failed':
						break;
					default:
						$order_status   = new ZWORKFLOWMANAGER_Order_Status( 'wc-' . $status );
						$default_status = substr( $order_status->get_default_status(), 3 );
						$order->update_status( $default_status, 'Order status changed to ' . $order_status->get_status_title( $default_status ) . ' because Workflow Manager for WooCommerce plugin was deactivated' );
				}
			}

			// Delete settings
			delete_option( 'notification_email_settings' );
			delete_option( 'twilio_settings' );
			delete_option( 'whatsapp_settings' );

			// Delete CPT
			$post_types = array( 'zworkflowstatus', 'zworkflowsend', 'zworkflowtemplates', 'zworkflowemail' );

			$posts = get_posts(
				array(
					'post_type'   => $post_types,
					'numberposts' => -1,
				)
			);

			if ( $posts ) {
				foreach ( $posts as $post ) {
					wp_delete_post( $post->ID, true );
				}
			}
		}

	}

	/**
	 * Check field and return its value or return null
	 *
	 * @param array  $data_arr data.
	 * @param string $key key.
	 *
	 * @return mixed|null
	 */
	public static function get_field_value( $data_arr, $key ) {
		return ( isset( $data_arr[ $key ] ) ) ? $data_arr[ $key ] : null;
	}

	/**
	 * Replace in $str the characters starting from $first (0 first character) to $last, with $rep
	 *
	 * @param string $str string for replace.
	 * @param int    $first first.
	 * @param int    $last last.
	 * @param string $rep rep.
	 *
	 * @return string
	 */
	public static function character_string_replacer( $str, $first = 0, $last = 0, $rep = '*' ) {
		$begin  = substr( $str, 0, $first );
		$middle = str_repeat( $rep, strlen( substr( $str, $first, $last ) ) );
		$end    = substr( $str, $last );

		return $begin . $middle . $end;
	}

}

<?php
/**
 * Flow-Notify Timing functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-timing-schedule
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Core_Admin' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
}

/**
 * Class ZWORKFLOWMANAGER_Timing_Schedule
 */
class ZWORKFLOWMANAGER_Timing_Schedule {


	private $timing_type;

	private $timeframe_for_notification;

	private $schedule_timeframe_from;

	private $schedule_timeframe_to;

	private $current_time;

	private $communication_methods_schedule;

	private $timing_settings;

	private $message_timeframe_schedule;

	public function __construct( $id = null, $timing_type = null, $sending_method = null ) {
		$this->timing_type                = $timing_type;
		$this->current_time               = time();
		$this->timeframe_for_notification = ( get_post_meta( $id, 'zcustomemail_timeframe_enabled', true ) === 'on' ) ? true : false;
		$this->timing_settings            = get_post_meta( $id, 'zcustomemail_timing_settings', true );

		$settings_status = new ZWORKFLOWMANAGER_Settings();
		$settings        = $settings_status->get_settings();

		$this->message_timeframe_schedule = ( isset( $settings['message_timeframe_schedule'] ) && 'on' === $settings['message_timeframe_schedule'] ) ? true : false;
		$this->schedule_timeframe_from    = $settings['schedule_timeframe_from'] ?? '';
		$this->schedule_timeframe_to      = $settings['schedule_timeframe_to'] ?? '';

		if ( 'sms' === $sending_method ) {
			$this->communication_methods_schedule = $settings['communication_methods_schedule_sms'];
		} elseif ( 'email' === $sending_method ) {
			$this->communication_methods_schedule = $settings['communication_methods_schedule_email'];
		} elseif ( 'whatsapp' === $sending_method ) {
			$this->communication_methods_schedule = $settings['communication_methods_schedule_wa'];
		}

	}

	/**
	 * Checks whether the message can be sent now
	 */
	public function is_send_now_possible() {
		$result = false;

		if ( $this->timeframe_for_notification && $this->communication_methods_schedule ) {
			if ( $this->current_time < $this->schedule_timeframe_from || $this->current_time > $this->schedule_timeframe_to ) {
				$result = false;
			}
		} elseif ( 'delayed' === $this->timing_type ) {
			$result = false;
		} elseif ( 'fixed' === $this->timing_type ) {
			$result = $this->is_timing_for_type_fixed();
		} elseif ( 'scheduled' === $this->timing_type ) {
			$result = $this->is_timing_for_type_scheduled();
		}

		return $result;

	}

	private function is_timing_for_type_fixed() {
		$timing_datepicker = $this->timing_settings['timing_datepicker'];
		$fixed_time        = $this->timing_settings['fixed_time'];
		$date_sending      = strtotime( "+$timing_datepicker $fixed_time" );
		$current_datetime  = wp_date( 'F j, Y, h:i a' );
		$time_now          = strtotime( $current_datetime );

		if ( $date_sending == $time_now ) {
			return true;
		} else {
			return false;
		}
	}

	private function is_timing_for_type_scheduled() {
		$schedule_time   = $this->timing_settings['schedule_time'];
		$select_days_arr = $this->timing_settings['select_days'];
		$current_day     = current_time( 'N' );
		$current_time    = current_time( 'H:i' );

		if ( in_array( $current_day, $select_days_arr ) && $current_time === $schedule_time ) {
			return true;
		} else {
			return false;
		}
	}

	public function send_message_by_scheduled( $phone, $message, $id ) {
		$time_stamp = $this->get_time_stamp();

		return $this->wp_cron_schedule( $time_stamp, $phone, $message, $id );
	}

	public function send_email_by_scheduled( $email, $subject, $admin_email, $id ) {
		$time_stamp = $this->get_time_stamp();

		return $this->wp_cron_email_schedule( $time_stamp, $email, $subject, $admin_email, $id );
	}

	public function send_whatsapp_message_by_scheduled( $whatsapp_phone, $template_name, $template_lang, $parameters, $id ) {
		$time_stamp = $this->get_time_stamp();

		return $this->wp_cron_whatsapp_schedule( $time_stamp, $whatsapp_phone, $template_name, $template_lang, $parameters, $id );
	}

	public function get_time_stamp() {

		if ( 'delayed' === $this->timing_type ) {
			$delayed_time = $this->timing_settings['delayed_time'];
			$time_unit    = $this->timing_settings['time_unit'];

			$time_stamp = strtotime( "+$delayed_time $time_unit", $this->current_time );

			if ( $this->timeframe_for_notification && $this->communication_methods_schedule && $this->message_timeframe_schedule ) {
				$time_stamp = $this->get_timestamp_with_timeframe( $time_stamp );
			}

			return $time_stamp;

		} elseif ( 'scheduled' === $this->timing_type ) {
			$select_days_arr = $this->timing_settings['select_days'];
			$today           = wp_date( 'N' );
			$today_date      = wp_date( 'F j, Y' );
			$sending_time    = $this->timing_settings['schedule_time'];

			if ( is_array( $select_days_arr ) ) {
				if ( in_array( $today, $select_days_arr ) ) {
					$time_stamp = strtotime( "$today_date $sending_time" );
				} else {
					$sending_day = $this->get_next_day( $today, $select_days_arr );
					$time_stamp  = strtotime( "next $sending_day $sending_time" );
				}
			}

			if ( $this->timeframe_for_notification && $this->communication_methods_schedule && $this->message_timeframe_schedule ) {
				$time_stamp = $this->get_timestamp_with_timeframe( $time_stamp );
			}

			return $time_stamp;

		} elseif ( 'fixed' === $this->timing_type ) {
			$timing_datepicker = $this->timing_settings['timing_datepicker'];
			$fixed_time        = $this->timing_settings['fixed_time'];
			$time_stamp        = strtotime( "$timing_datepicker $fixed_time" );

			if ( $this->timeframe_for_notification && $this->communication_methods_schedule && $this->message_timeframe_schedule ) {
				$time_stamp = $this->get_timestamp_with_timeframe( $time_stamp );
			}

			return $time_stamp;
		}
	}

	private function get_next_day( $today, $days ) {
		$next_day = null;
		$weekdays = array(
			1 => 'Monday',
			2 => 'Tuesday',
			3 => 'Wednesday',
			4 => 'Thursday',
			5 => 'Friday',
			6 => 'Saturday',
			7 => 'Sunday',
		);

		if ( count( $days ) === 1 ) {
			$next_day = $days[0];
		} else {
			sort( $days );

			foreach ( $days as $day ) {
				if ( $day > $today ) {
					$next_day = $day;
					break;
				}
			}

			if ( ! $next_day ) {
				$next_day = $days[0];
			}
		}

		return $weekdays[ $next_day ];
	}

	private function get_timestamp_with_timeframe( $time_stamp ) {
		$schedule_timeframe_from = strtotime( $this->schedule_timeframe_from, $time_stamp );
		$schedule_timeframe_to   = strtotime( $this->schedule_timeframe_to, $time_stamp );

		if ( $time_stamp < $schedule_timeframe_from || $time_stamp > $schedule_timeframe_to ) {
			if ( $time_stamp < $schedule_timeframe_from ) {
				$time_stamp = $schedule_timeframe_from;
			} elseif ( $time_stamp > $schedule_timeframe_to ) {
				$time_stamp = strtotime( '+ 1 day', $schedule_timeframe_from );
			}
		}
		return $time_stamp;
	}

	public function wp_cron_schedule( $timestamp, $phone, $message, $id ) {
		if ( ! wp_next_scheduled( 'zwf_send_message_by_sms' ) ) {
			$result = wp_schedule_single_event( $timestamp, 'zwf_send_message_by_sms', array( $phone, $message, $id ) );
		}

		return $result;
	}

	public function wp_cron_email_schedule( $timestamp, $email, $subject, $admin_email, $id ) {
		if ( ! wp_next_scheduled( 'zwf_send_message_by_email' ) ) {
			$result = wp_schedule_single_event( $timestamp, 'zwf_send_message_by_email', array( $email, $subject, $admin_email, $id ) );
		}

		return $result;
	}

	public function wp_cron_whatsapp_schedule( $timestamp, $whatsapp_phone, $template_name, $template_lang, $parameters, $id ) {
		if ( ! wp_next_scheduled( 'zwf_send_message_by_whatsapp' ) ) {
			$result = wp_schedule_single_event( $timestamp, 'zwf_send_message_by_whatsapp', array( $whatsapp_phone, $template_name, $template_lang, $parameters, $id ) );
		}

		return $result;
	}

	public function init_hooks() {
		add_action( 'zwf_send_message_by_sms', array( $this, 'do_message_send' ), 10, 3 );
		add_action( 'zwf_send_message_by_email', array( $this, 'do_email_send' ), 10, 4 );
		add_action( 'zwf_send_message_by_whatsapp', array( $this, 'do_whatsapp_send' ), 10, 5 );
	}

	public function do_message_send( $phone, $message, $id ) {
		$adm_admin = new ZWORKFLOWMANAGER_Core_Admin();
		$result    = $adm_admin->twilio_sending_sms_to_customer( $phone, $message );

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		$send_status = new ZWORKFLOWMANAGER_Send( $id );

		if ( isset( $result['success'] ) ) {
			$send_status->set_data( 'send_status', 'Success' );
		} elseif ( isset( $result['error'] ) ) {
			$send_status->set_data( 'error_logs', $result['error'] );
			$send_status->set_data( 'send_status', 'Failed' );
		}

	}

	public function do_email_send( $email, $subject, $admin_email, $id ) {
		$adm_admin = new ZWORKFLOWMANAGER_Core_Admin();

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		$send_status = new ZWORKFLOWMANAGER_Send( $id );
		$result      = $adm_admin->email_send_helper( $email, $subject, $admin_email );

		if ( isset( $result['success'] ) ) {
			$send_status->set_data( 'send_status', 'Success' );
		} elseif ( isset( $result['error'] ) ) {
			$send_status->set_data( 'error_logs', $result['error'] );
			$send_status->set_data( 'send_status', 'Failed' );
		}
	}

	public function do_whatsapp_send( $whatsapp_phone, $template_name, $template_lang, $parameters, $id ) {
		$adm_admin = new ZWORKFLOWMANAGER_Core_Admin();

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
		}

		$whatsapp = new ZWORKFLOWMANAGER_Whatsapp();

		$send_status = new ZWORKFLOWMANAGER_Send( $id );
		$result      = $whatsapp->send_message( $whatsapp_phone, $template_name, $template_lang, $parameters );

		if ( isset( $result['error'] ) ) {
			$send_status->set_data( 'error_logs', $result['error'] );
			$send_status->set_data( 'send_status', 'Failed' );

			$logger = new ZWORKFLOWMANAGER_Logger();
			$logger->log( $result['error'] );
		} else {
			$send_status->set_data( 'send_status', 'Success' );
		}

	}

}


























<?php
/**
 * Flow-Notify Time Frame functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-shedule-timeFrame
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Core_Admin' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
}

/**
 * Class ZWORKFLOWMANAGER_Schedule_Time_Frame
 */
class ZWORKFLOWMANAGER_Schedule_Time_Frame {

	/**
	 * Save sms delayed send
	 *
	 * @param string $phone phone.
	 * @param string $message message.
	 * @param string $post_update_id post_update_id.
	 */
	public function save_sms_delayed_send( $phone, $message, $post_update_id ) {
		$save_sms_delayed = get_option( 'save_sms_delayed' );

		if ( empty( $save_sms_delayed ) ) {
			update_option( 'save_sms_delayed', array( array( $phone, $message, $post_update_id ) ) );
		} else {
			$save_sms_delayed[] = array( $phone, $message, $post_update_id );
			$save_sms_delayed   = array_map( 'unserialize', array_unique( array_map( 'serialize', $save_sms_delayed ) ) );
			update_option( 'save_sms_delayed', $save_sms_delayed );
		}
	}

	/**
	 * Save email delayed send
	 *
	 * @param string $email email.
	 * @param string $subject subject.
	 * @param string $admin_email admin_email.
	 * @param string $post_update_id post_update_id.
	 * @param string $message message.
	 */
	public function save_email_delayed_send( $email, $subject, $admin_email, $post_update_id, $message ) {
		$save_email_delayed = get_option( 'save_email_delayed' );

		if ( empty( $save_email_delayed ) ) {
			update_option(
				'save_email_delayed',
				array(
					array(
						$email,
						$subject,
						$admin_email,
						$post_update_id,
						$message,
					),
				)
			);
		} else {
			$save_email_delayed[] = array( $email, $subject, $admin_email, $post_update_id, $message );
			$save_email_delayed   = array_map( 'unserialize', array_unique( array_map( 'serialize', $save_email_delayed ) ) );
			update_option( 'save_email_delayed', $save_email_delayed );
		}
	}

	/**
	 * Setup for CRON job
	 */
	public function cron_settings() {

		/* interval registration */
		add_filter(
			'cron_schedules',
			function ( $schedules ) {

				$schedules['zworkflowmanager_every_five_minutes'] = array(
					'interval' => 60,
					'display'  => __( 'Every 5 Minutes', 'flow_notify_text' ),
				);

				return $schedules;
			}
		);

		/* Init cron */
		if ( ! wp_next_scheduled( 'send_delayed_every_five_minutes' ) ) {
			wp_schedule_event( time(), 'zworkflowmanager_every_five_minutes', 'send_delayed_every_five_minutes' );
		}

		/* Hook into that action that'll fire every five minutes */
		add_action( 'send_delayed_every_five_minutes', array( $this, 'send_delayed_sms_cron' ) );
		add_action( 'send_delayed_every_five_minutes', array( $this, 'send_delayed_email_cron' ) );
	}

	/**
	 * Send scheduled email with cron
	 */
	public function send_delayed_email_cron() {
		$adm_admin          = new ZWORKFLOWMANAGER_Core_Admin();
		$save_email_delayed = get_option( 'save_email_delayed' );
		if ( is_null( $save_email_delayed ) || empty( $save_email_delayed ) || is_null( get_option( 'notification_email_settings' )['communication_methods_schedule_sms'] ) || ! $this->check_schedule_time_frame() ) {
			return;
		}

		foreach ( $save_email_delayed as $key => $email ) {
			$email_send = $adm_admin->email_send_helper( $email[0], $email[1], $email[2] );

			if ( $email_send ) {
				unset( $save_email_delayed[ $key ] );
			}
			if ( $email_send ) {
				update_post_meta( $email[3], 'send_status', 'Success' );
			} else {
				update_post_meta( $email[3], 'send_status', 'Failed' );
			}
		}
		update_option( 'save_email_delayed', $save_email_delayed );
	}

	/**
	 * Check schedule timeFrame
	 *
	 * @return bool
	 */
	public function check_schedule_time_frame() {
		$settings_status = new ZWORKFLOWMANAGER_Settings();
		$settings        = $settings_status->get_settings();
		if ( is_null( $settings['message_timeframe_schedule'] ) ) {
			return true;
		}
		$current_time            = current_time( 'timestamp' );
		$schedule_timeframe_from = strtotime( gmdate( $settings['schedule_timeframe_from'] ) );
		$schedule_timeframe_to   = strtotime( gmdate( $settings['schedule_timeframe_to'] ) );

		return $schedule_timeframe_from <= $current_time && $current_time <= $schedule_timeframe_to;
	}

	/**
	 * Send scheduled sms with cron
	 */
	public function send_delayed_sms_cron() {
		$adm_admin        = new ZWORKFLOWMANAGER_Core_Admin();
		$save_sms_delayed = get_option( 'save_sms_delayed' );

		if ( is_null( $save_sms_delayed ) || empty( $save_sms_delayed ) || is_null( get_option( 'notification_email_settings' )['communication_methods_schedule_sms'] ) || ! $this->check_schedule_time_frame() ) {
			return;
		}
		foreach ( $save_sms_delayed as $key => $sms ) {
			$result   = $adm_admin->twilio_sending_sms_to_customer( $sms[0], $sms[1] );
			$sms_send = isset( $result['success'] );
			if ( $sms_send ) {
				unset( $save_sms_delayed[ $key ] );
			}
			if ( $sms_send ) {
				update_post_meta( $sms[2], 'send_status', 'Success' );
			} else {
				update_post_meta( $sms[2], 'send_status', 'Failed' );
			}
		}
		update_option( 'save_sms_delayed', $save_sms_delayed );
	}
}

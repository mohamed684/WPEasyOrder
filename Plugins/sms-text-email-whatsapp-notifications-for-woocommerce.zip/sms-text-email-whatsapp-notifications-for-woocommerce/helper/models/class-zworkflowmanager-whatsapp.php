<?php
/**
 * Flow-Notify WhatsApp functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-whatsapp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Whatsapp
 */
class ZWORKFLOWMANAGER_Whatsapp {

	/**
	 * Add message template
	 *
	 * @param string $id get template_id.
	 */
	public function add_message_template( $id ) {

		$text_template = get_post_meta( $id, 'zmessagetemplate_description', true );
		$name_template = get_post_meta( $id, 'zmessagetemplate_name', true );

		$text_template_format = $this->format_message( $text_template );

		$example = $this->get_parammetrs_for_template( $text_template );

		$result_template_create = $this->create_template_message( $text_template_format, $example, $name_template );
		$result_template_create = json_decode( $result_template_create, true );

		if ( $result_template_create['id'] ) {
			update_post_meta( $id, 'zapproval_status', 'Pending' );
			update_post_meta( $id, 'whatsapp_template_id', $result_template_create['id'] );

		}
	}

	/**
	 * Create template message
	 *
	 * @param string $body_text get body_text.
	 * @param string $example get example.
	 * @param string $template_name get template_name.
	 */
	private function create_template_message( $body_text, $example, $template_name ) {
		if ( ! isset( $_POST['zwf_template_message_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['zwf_template_message_nonce'] ), 'zwf_template_message_nonce' ) ) {
			return;
		}

		$existing_whatsapp_settings   = get_option( 'whatsapp_settings' );
		$access_token                 = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_token'] : $existing_whatsapp_settings['whatsapp_token_test'];
		$whatsapp_business_account_id = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_business_account_id'] : $existing_whatsapp_settings['whatsapp_business_account_id_test'];
		$template_language            = ( isset( $_POST['template_language'] ) ) ? sanitize_text_field( wp_unslash( $_POST['template_language'] ) ) : '';
		$template_category            = ( isset( $_POST['template_category'] ) ) ? sanitize_text_field( wp_unslash( $_POST['template_category'] ) ) : '';

		$url = "https://graph.facebook.com/v16.0/{$whatsapp_business_account_id}/message_templates";

		$components = array(
			array(
				'type' => 'BODY',
				'text' => $body_text,
			),
		);

		if ( is_array( $example ) && ! empty( $example ) ) {
			$components = array_map(
				function ( $item ) use ( $example ) {
					$item['example'] = array(
						'body_text' => array( $example ),
					);
					return $item;
				},
				$components
			);
		}

		$components = wp_json_encode( $components );

		$data = array(
			'name'         => $template_name,
			'language'     => $template_language,
			'category'     => $template_category,
			'components'   => $components,
			'access_token' => $access_token,

		);

		$url    = $url . '?' . http_build_query( $data );
		$result = wp_remote_request( $url, array( 'method' => 'POST' ) );

		if ( is_array( $result ) && isset( $result['body'] ) ) {
			$error_array = json_decode( $result['body'], true );

			if ( isset( $error_array['error']['message'] ) ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
				}

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( $error_array['error']['message'] );
			}

			return;
		}

		if ( is_wp_error( $result ) ) {
			$logger = new ZWORKFLOWMANAGER_Logger();
			$logger->log( $result->get_error_message() );

			return;
		}

		return $result['body'];

	}

	/**
	 * Send message
	 *
	 * @param string $phone get phone.
	 * @param string $template_name get template_name.
	 * @param string $template_lang get template_lang.
	 * @param string $parameters get parameters.
	 */
	public function send_message( $phone, $template_name, $template_lang, $parameters ) {
		$existing_whatsapp_settings = get_option( 'whatsapp_settings' );
		$access_token               = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_token'] : $existing_whatsapp_settings['whatsapp_token_test'];
		$whatsapp_phone_id          = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_phone_id'] : $existing_whatsapp_settings['whatsapp_phone_id_test'];

		$url = "https://graph.facebook.com/v16.0/{$whatsapp_phone_id}/messages";

		$data = array(
			'messaging_product' => 'whatsapp',
			'to'                => $phone,
			'type'              => 'template',
			'template'          => array(
				'name'       => $template_name,
				'language'   => array(
					'code' => $template_lang,
				),
				'components' => array(
					array(
						'type' => 'body',
					),
				),
			),
		);

		if ( is_array( $parameters ) ) {

			foreach ( $parameters as &$sub_array ) {
				if ( empty( $sub_array['text'] ) ) {
					$sub_array['text'] = 'n/a';
				}
			}
			$data['template']['components'][0]['parameters'] = $parameters;
		}

		$components = wp_json_encode( $data );

		$arr = array(
			'method'  => 'POST',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			),
			'body'    => $components,

		);

		$remote_request = wp_remote_request( $url, $arr );
		$result         = array();

		if ( 'OK' === $remote_request['response']['message'] ) {
			$result['success'] = 'The message was sent successfully';
		} else {
			$respond         = json_decode( $remote_request['body'], true );
			$result['error'] = $respond['error']['message'];
		}

		return $result;

	}

	/**
	 * Get template
	 *
	 * @param string $template_name get template_name.
	 * @param string $template_id get template_id.
	 * @param bool   $is_ajax get is_ajax.
	 */
	public function get_template( $template_name = null, $template_id = null, $is_ajax = true ) {

		if ( $is_ajax ) {
			$template_name = filter_input( INPUT_POST, 'template_name', FILTER_SANITIZE_STRING );
			$template_id   = filter_input( INPUT_POST, 'template_id', FILTER_SANITIZE_STRING );
		}

		if ( empty( $template_name ) ) {
			if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
				require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
			}

			$logger = new ZWORKFLOWMANAGER_Logger();
			$logger->log( 'Template name text not specified' );

			echo 'Template name text not specified';
		}

		$existing_whatsapp_settings = get_option( 'whatsapp_settings' );

		$access_token                 = '';
		$whatsapp_business_account_id = '';

		if ( isset( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ) {
			$access_token = $existing_whatsapp_settings['whatsapp_token'];
		} else {
			$access_token = $existing_whatsapp_settings['whatsapp_token_test'];
		}

		if ( isset( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ) {
			$whatsapp_business_account_id = $existing_whatsapp_settings['whatsapp_business_account_id'];
		} else {
			$whatsapp_business_account_id = $existing_whatsapp_settings['whatsapp_business_account_id_test'];
		}

		$url          = "https://graph.facebook.com/v16.0/{$whatsapp_business_account_id}/message_templates?access_token={$access_token}";
		$result       = wp_remote_request( $url );
		$template_arr = json_decode( $result['body'], true );
		$template_arr = ( isset( $template_arr['data'] ) ) ? $template_arr['data'] : '';
		$error_array  = json_decode( $result['body'], true );

		$template_status = 'n/a';

		if ( is_array( $template_arr ) ) {
			foreach ( $template_arr as $template ) {
				if ( $template_name === $template['name'] ) {
					update_post_meta( $template_id, 'zapproval_status', $template['status'] );
					$template_status = $template['status'];
				}
			}

			echo esc_attr( $template_status );
		}

		if ( isset( $error_array['error']['message'] ) ) {
			if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
				require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
			}

			$logger = new ZWORKFLOWMANAGER_Logger();
			$logger->log( $error_array['error']['message'] );
		}

		if ( $is_ajax ) {
			exit;
		}
	}

	/**
	 * Edit template WhatsApp
	 *
	 * @param string $id get id template.
	 * @param string $text_template get id text_template.
	 * @param string $template_category get id template_category.
	 */
	public function edit_template( $id, $text_template, $template_category ) {
		$existing_whatsapp_settings = get_option( 'whatsapp_settings' );
		$access_token               = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_token'] : $existing_whatsapp_settings['whatsapp_token_test'];
		$text_template_format       = $this->format_message( $text_template );
		$example                    = $this->get_parammetrs_for_template( $text_template );

		$components = array(
			array(
				'type' => 'body',
				'text' => $text_template_format,
			),
		);

		if ( is_array( $example ) && ! empty( $example ) ) {
			$components = array_map(
				function ( $item ) use ( $example ) {
					$item['example'] = array(
						'body_text' => array( $example ),
					);
					return $item;
				},
				$components
			);
		}

		$data = array(
			'category'   => $template_category,
			'components' => $components,
		);

		$components = wp_json_encode( $data );

		$arr = array(
			'method'  => 'POST',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			),
			'body'    => $components,

		);

		$url = "https://graph.facebook.com/v17.0/{$id}/";

		$result = wp_remote_request( $url, $arr );

		if ( isset( $result['body'] ) ) {
			$error_array = json_decode( $result['body'], true );

			if ( isset( $error_array['error']['message'] ) ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
				}

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( $error_array['error']['message'] );
			}
		}

		return $result;

	}

	/**
	 * Delete template WhatsApp
	 *
	 * @param string $whatsapp_template_id get id whatsapp_template_id.
	 * @param string $template_name get id template_name.
	 */
	public function delete_template( $whatsapp_template_id, $template_name ) {
		$existing_whatsapp_settings   = get_option( 'whatsapp_settings' );
		$access_token                 = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_token'] : $existing_whatsapp_settings['whatsapp_token_test'];
		$whatsapp_business_account_id = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_business_account_id'] : $existing_whatsapp_settings['whatsapp_business_account_id_test'];

		$url = "https://graph.facebook.com/v16.0/{$whatsapp_business_account_id}/message_templates?hsm_id={$whatsapp_template_id}&name={$template_name}";

		$args = array(
			'method'  => 'DELETE',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			),
		);

		$result = wp_remote_request( $url, $args );

		if ( isset( $result['body'] ) ) {
			$error_array = json_decode( $result['body'], true );

			if ( isset( $error_array['error']['message'] ) ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
				}

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( $error_array['error']['message'] );
			}
		}

		return $result;
	}

	/**
	 * Get parammetrs for template WhatsApp
	 *
	 * @param string $string get text.
	 */
	private function get_parammetrs_for_template( $string ) {
		$placeholders_arr = array();
		preg_match_all( '/\{([^}]*)\}/', $string, $placeholders_arr );

		$result = array_map(
			function( $match ) {

				if ( strpos( $match, '_' ) !== false ) {
					$match = str_replace( '_', ' ', $match );
				}
				return ucfirst( $match );
			},
			$placeholders_arr[1]
		);

		return $result;
	}

	/**
	 * Format message for template WhatsApp
	 *
	 * @param string $string get text.
	 */
	public function format_message( $string ) {
		$count = 0;
		return preg_replace_callback(
			'/\{([^}]*)\}/',
			function( $matches ) use ( &$count ) {
				$count++;
				return '{{' . $count . '}}';
			},
			$string
		);
	}

	/**
	 * Init hooks
	 */
	public function init_hooks() {
		add_action( 'wp_ajax_zworkflowmanager_get_template', array( $this, 'get_template' ) );
	}
}

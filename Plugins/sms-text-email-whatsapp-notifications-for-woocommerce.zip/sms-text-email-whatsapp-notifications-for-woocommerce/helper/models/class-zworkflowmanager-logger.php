<?php
/**
 * Flow-Notify Logger functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-logger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Logger
 */
class ZWORKFLOWMANAGER_Logger {

	const DIR_PATH            = ZWORKFLOWMANAGER_PLUGIN_DIR . 'logs/';
	const LOG_PATH            = ZWORKFLOWMANAGER_PLUGIN_DIR . 'logs/logs.log';
	const LOG_PATH_CONNECTION = ZWORKFLOWMANAGER_PLUGIN_DIR . 'logs/connetcion_logs.log';

	public function log( $message, $is_connection = false ) {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
		}

		self::create_dir();

		$settings_status = new ZWORKFLOWMANAGER_Settings();
		$settings        = $settings_status->get_settings();

		if ( ! isset( $settings['save_info_logs'] ) || 'on' !== $settings['save_info_logs'] ) {
			return;
		}

		$timestamp = wp_date( 'n/j/Y H:i:s' );
		$content   = "[$timestamp] $message\n";

		$log_path = $is_connection ? self::LOG_PATH_CONNECTION : self::LOG_PATH;

		error_log( $content, 3, $log_path );
	}

	private static function create_dir() {
		if ( is_dir( self::DIR_PATH ) ) {
			return;
		}

		mkdir( self::DIR_PATH, 0755, true );
	}

	public static function get_logs_filesize() {
		return ( file_exists( self::LOG_PATH ) ? ( round( filesize( self::LOG_PATH ) / 1024, 3 ) ) : 0 );
	}

	public static function get_connection_logs_filesize() {
		return ( file_exists( self::LOG_PATH_CONNECTION ) ? ( round( filesize( self::LOG_PATH_CONNECTION ) / 1024, 3 ) ) : 0 );
	}

	public static function clear_logs( $is_connection = false ) {
		$log_path = $is_connection ? self::LOG_PATH_CONNECTION : self::LOG_PATH;

		$file = fopen( $log_path, 'w+' );
		if ( $file ) {
			fclose( $file );
			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=settings&section=support' ) );
		}
	}

	public function copy_log_file() {
		if ( isset( $_POST['settings_notify_nonce_field'] ) && wp_verify_nonce( sanitize_text_field( $_POST['settings_notify_nonce_field'] ), 'settings_notify_action' ) ) {
			$is_connection = ( isset( $_POST['log_connection'] ) ) ? sanitize_text_field( wp_unslash( $_POST['log_connection'] ) ) : '';
			$log_path      = $is_connection ? self::LOG_PATH_CONNECTION : self::LOG_PATH;

			if ( file_exists( $log_path ) ) {
				$file = fopen( $log_path, 'r' );
				$data = fread( $file, filesize( $log_path ) );
				fclose( $file );

				echo esc_attr( $data );
			}
		}

		exit;
	}

	public function init_hooks() {
		add_action( 'wp_ajax_copy_log_file', array( $this, 'copy_log_file' ) );
	}


}

<?php
/**
 * Flow-Notify Notification functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-status-email
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Status_Email
 */
class ZWORKFLOWMANAGER_Status_Email {

	/**
	 * Post id
	 *
	 * @var int
	 */
	private $id;

	/**
	 * Post name
	 *
	 * @var string
	 */
	private $name;

	/**
	 * User type
	 * Type: customer | admin
	 *
	 * @var mixed
	 */
	private $type;

	/**
	 * Sending type
	 * Sending type: email | SMS | whatsapp
	 *
	 * @var mixed
	 */
	private $sending_type;

	/**
	 * Description
	 *
	 * @var mixed
	 */
	private $description;

	/**
	 * Email post
	 *
	 * @var array|int|WP_Post|null
	 */
	private $email_post;

	/**
	 * Dispatch list
	 *
	 * @var false|string[]
	 */
	private $dispatch_list;

	/**
	 * Slug
	 *
	 * @var false|string[]
	 */
	private $slug;

	/**
	 * ZWORKFLOWMANAGER_Status_Email constructor.
	 *
	 * @param string $id id.
	 */
	public function __construct( $id ) {

		if ( ! $id ) {
			return;
		}

		/* Get the order status post object */
		if ( is_numeric( $id ) ) {
			$this->email_post = get_post( $id );
		} elseif ( is_object( $id ) ) {
			$this->email_post = $id;
		} else {

			/* Try to get order status post object by slug */
			$posts = get_posts(
				array(
					'post_type'      => 'zworkflowemail',
					'meta_key'       => 'zcustomemail_slug',
					'meta_value'     => $id,
					'posts_per_page' => 1,
				)
			);

			if ( ! empty( $posts ) ) {
				$this->email_post = $posts[0];
			}
		}

		/* Load in post data */
		if ( $this->email_post ) {

			$this->id            = $this->email_post->ID;
			$this->name          = $this->email_post->post_title;
			$this->slug          = get_post_meta( $this->email_post->ID, 'zcustomemail_slug', true );
			$this->description   = get_post_meta( $this->email_post->ID, 'order_description', true );
			$this->dispatch_list = explode( ',', get_post_meta( $this->email_post->ID, 'zcustomemail_dispatch_list', true ) );
			$this->type          = get_post_meta( $this->email_post->ID, 'zcustomemail_type', true );
			$this->sending_type  = get_post_meta( $this->email_post->ID, 'zsending_type', true );
		}
	}

	/**
	 * Get id
	 *
	 * @return int
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Get name
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Set timing settings
	 */

	public function set_timing_settings() {
		if ( isset( $_POST['zwf_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['zwf_nonce'] ), 'zfn_operation_type' ) ) {
			$timing_type       = ( isset( $_POST['timing'] ) ) ? sanitize_text_field( wp_unslash( $_POST['timing'] ) ) : '';
			$delayed_time      = ( isset( $_POST['delayed_time'] ) ) ? sanitize_text_field( wp_unslash( $_POST['delayed_time'] ) ) : '';
			$time_unit         = ( isset( $_POST['time_unit'] ) ) ? sanitize_text_field( wp_unslash( $_POST['time_unit'] ) ) : '';
			$schedule_time     = ( isset( $_POST['schedule_time'] ) ) ? sanitize_text_field( wp_unslash( $_POST['schedule_time'] ) ) : '';
			$select_days       = ( isset( $_POST['select_days'] ) ) ? sanitize_text_field( wp_unslash( $_POST['select_days'] ) ) : '';
			$timing_datepicker = ( isset( $_POST['timing_datepicker'] ) ) ? sanitize_text_field( wp_unslash( $_POST['timing_datepicker'] ) ) : '';
			$fixed_time        = ( isset( $_POST['fixed_time'] ) ) ? sanitize_text_field( wp_unslash( $_POST['fixed_time'] ) ) : '';
		}

		$timing_settings = array();

		if ( 'delayed' === $timing_type ) {
			if ( empty( $time_unit ) || empty( $delayed_time ) ) {
				return;
			}

			$timing_settings['timing_type']  = $timing_type;
			$timing_settings['delayed_time'] = $delayed_time;
			$timing_settings['time_unit']    = $time_unit;

			update_post_meta( $this->id, 'zcustomemail_timing_settings', $timing_settings );
		}

		if ( 'scheduled' === $timing_type ) {
			if ( ! is_array( $select_days ) || empty( $schedule_time ) ) {
				return;
			}

			$timing_settings['timing_type']   = $timing_type;
			$timing_settings['schedule_time'] = $schedule_time;
			$timing_settings['select_days']   = $select_days;

			update_post_meta( $this->id, 'zcustomemail_timing_settings', $timing_settings );
		}

		if ( 'fixed' === $timing_type ) {
			$date_obj = DateTime::createFromFormat( 'Y-m-d', $timing_datepicker );

			if ( empty( $fixed_time ) || ! $date_obj ) {
				return;
			}

			$timing_settings['timing_type']       = $timing_type;
			$timing_settings['timing_datepicker'] = $timing_datepicker;
			$timing_settings['fixed_time']        = $fixed_time;

			update_post_meta( $this->id, 'zcustomemail_timing_settings', $timing_settings );
		}

	}

	/**
	 * Set name
	 *
	 * @param string $title title.
	 */
	public function set_name( $title ) {
		wp_update_post(
			array(
				'post_title' => trim( $title ),
				'ID'         => $this->id,
			)
		);
	}

	/**
	 * Get type
	 *
	 * @return mixed
	 */
	public function get_type() {
		return get_post_meta( $this->id, 'zcustomemail_type', true );
	}

	/**
	 * Set type
	 *
	 * @param string $type type.
	 */
	public function set_type( $type ) {
		update_post_meta( $this->id, 'zcustomemail_type', trim( $type ) );
	}

	/**
	 * Get sending type
	 *
	 * @return mixed
	 */
	public function get_sending_type() {
		return get_post_meta( $this->id, 'zsending_type', true );
	}

	/**
	 * Set sending type
	 *
	 * @param string $sending_type sending type.
	 */
	public function set_sending_type( $sending_type ) {
		update_post_meta( $this->id, 'zsending_type', trim( $sending_type ) );
	}

	/**
	 * Get slug
	 *
	 * @return mixed
	 */
	public function get_slug() {
		return get_post_meta( $this->id, 'zcustomemail_slug', true );
	}

	/**
	 * Get description
	 *
	 * @return mixed
	 */
	public function get_description() {
		return get_post_meta( $this->id, 'order_description', true );
	}

	/**
	 * Set description
	 *
	 * @param string $description description.
	 */
	public function set_description( $description ) {
		update_post_meta( $this->id, 'order_description', trim( $description ) );
	}

	public function set_message_template_id( $message_template_id ) {
		update_post_meta( $this->id, 'message_template_id', $message_template_id );
	}

	/**
	 * Get type preference
	 *
	 * @return mixed
	 */
	public function get_type_preference() {
		return get_post_meta( $this->id, 'type_preference_status_toggle', true );
	}

	/**
	 * Get subject
	 *
	 * @return mixed
	 */
	public function get_subject() {
		return get_post_meta( $this->id, 'zcustomemail_subject', true );
	}

	/**
	 * Get dispatch list
	 *
	 * @return mixed
	 */
	public function get_dispatch_list() {
		if ( isset( $this->email_post->ID ) ) {
			return get_post_meta( $this->email_post->ID, 'zcustomemail_dispatch_list', true );
		}
	}

	/**
	 * Set dispatch list
	 *
	 * @param array $list list.
	 */
	public function set_dispatch_list( $list ) {
		update_post_meta( $this->id, 'zcustomemail_dispatch_list', $list );
	}

	/**
	 * Get status
	 *
	 * @return mixed|string
	 */
	public function get_status() {
		$status = get_post_meta( $this->id, 'zcustomemail_status', true );

		return '' !== $status ? $status : 'disabled';
	}

	/**
	 * Set status
	 *
	 * @param string $status status.
	 */
	public function set_status( $status ) {
		update_post_meta( $this->id, 'zcustomemail_status', $status );
	}

	/**
	 * Set slug
	 *
	 * @param string $slug slug.
	 */
	public function set_slug( $slug ) {
		update_post_meta( $this->id, 'zcustomemail_slug', $slug );
	}

	/**
	 * Set subject
	 *
	 * @param string $subject subject.
	 */
	public function set_subject( $subject ) {
		update_post_meta( $this->id, 'zcustomemail_subject', $subject );
	}

	/**
	 * Set type preference
	 *
	 * @param string $type_preference type preference.
	 */
	public function set_type_preference( $type_preference ) {
		update_post_meta( $this->id, 'type_preference_status_toggle', $type_preference );
	}

	/**
	 * Set trigger status
	 *
	 * @param string $trigger_status trigger status.
	 */
	public function set_trigger_status( $trigger_status ) {
		update_post_meta( $this->id, 'trigger_status', $trigger_status );
	}

	/**
	 * Get trigger status
	 *
	 * @return mixed
	 */
	public function get_trigger_status() {
		return get_post_meta( $this->id, 'trigger_status', true );
	}

	/**
	 * Set total spend
	 *
	 * @param string $total_spend total spend.
	 */
	public function set_total_spend( $total_spend ) {
		update_post_meta( $this->id, 'total_spend', $total_spend );
	}

	/**
	 * Get total spend
	 *
	 * @return mixed
	 */
	public function get_total_spend() {
		return get_post_meta( $this->id, 'total_spend', true );
	}
}

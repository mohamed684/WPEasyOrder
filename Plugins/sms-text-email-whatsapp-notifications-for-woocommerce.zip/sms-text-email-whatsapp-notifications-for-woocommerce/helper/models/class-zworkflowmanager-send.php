<?php
/**
 * Flow-Notify Send functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-send
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Send
 */
class ZWORKFLOWMANAGER_Send {

	/**
	 * Send Id
	 *
	 * @var int
	 */
	private $id;

	/**
	 * Send post
	 *
	 * @var array|int|WP_Post|null
	 */
	private $post;

	/**
	 * ZWORKFLOWMANAGER_Send constructor.
	 *
	 * @param string $id id.
	 */
	public function __construct( $id ) {
		if ( ! $id ) {
			return;
		}

		/* Get the order status post object */
		if ( is_numeric( $id ) ) {
			$this->post = get_post( $id );
		} elseif ( is_object( $id ) ) {
			$this->post = $id;
		} else {
			/* Try to get order status post object by slug */
			$posts = get_posts(
				array(
					'post_type'      => 'zworkflowsend',
					'meta_key'       => 'zworkflowsend_slug',
					'meta_value'     => $id,
					'posts_per_page' => 1,
				)
			);

			if ( ! empty( $posts ) ) {
				$this->post = $posts[0];
			}
		}

		/* Load in post data */
		if ( $this->post ) {
			$this->id = $this->post->ID;

		}
	}

	/**
	 * Set data for selected key and value
	 *
	 * @param string $key key.
	 * @param string $value value.
	 *
	 * @return int
	 */
	public function set_data( $key, $value ) {
		return update_post_meta( $this->id, $key, $value );
	}

	/**
	 * Get data for selected key
	 *
	 * @param string $key key.
	 *
	 * @return mixed
	 */
	public function get_data( $key ) {
		return get_post_meta( $this->id, $key, true );
	}

	/**
	 * Get users notification
	 *
	 * @return array
	 */
	public function get_notification() {

		$response = array();

		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'zcustomemail_type',
					'value'   => 'customer',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type       = get_post_meta( $current_post->ID, 'zsending_type', true );
				$order_description   = get_post_meta( $current_post->ID, 'order_description', true );
				$message_template_id = get_post_meta( $current_post->ID, 'message_template_id', true );
				array_push(
					$response,
					array(
						'post_title'          => $current_post->post_title,
						'zsending_type'       => $zsending_type,
						'order_description'   => $order_description,
						'message_template_id' => $message_template_id,
						'notification_id'     => $current_post->ID,
					)
				);
			}
		}
		wp_reset_postdata();

		return $response;
	}

	/**
	 * Get checkbox value
	 *
	 * @return mixed
	 */
	public function get_checkbox_value() {
		$type_sms      = get_post_meta( $this->id, 'SMS', true );
		$type_email    = get_post_meta( $this->id, 'email', true );
		$type_whatsapp = get_post_meta( $this->id, 'whatsapp', true );

		return array_diff( array( strtolower( $type_sms ), $type_email, $type_whatsapp ), array( '' ) );
	}

	/**
	 * Get background color of status send
	 *
	 * @return string
	 */
	public function get_background_color() {
		$status = get_post_meta( $this->id, 'send_status', true );
		switch ( $status ) {
			case 'Success':
				$color = '#c5e1c5';
				break;
			case 'Failed':
				$color = '#eba3a3';
				break;
			case 'Scheduled':
				$color = '#e5e5e5';
				break;
			case 'On hold':
				$color = '#f8dea7';
				break;
			default:
				$color = '#eba3a3';
		}

		return $color;
	}

	/**
	 * Get text color of status send
	 *
	 * @return string
	 */
	public function get_text_color() {
		$status = get_post_meta( $this->id, 'send_status', true );
		switch ( $status ) {
			case 'Success':
				$color = '#7da155';
				break;
			case 'Failed':
				$color = '#a65555';
				break;
			case 'Scheduled':
				$color = '#8a8a8a';
				break;
			case 'On hold':
				$color = '#b48d42';
				break;
			default:
				$color = '#eba3a3';
		}

		return $color;
	}

	/**
	 * Get method of send
	 *
	 * @return string
	 */
	public function get_method() {
		$method = get_post_meta( $this->id, 'date', true );
		switch ( $method ) {
			case 'Instant':
				$text = 'Instant Send';
				break;
			case 'Scheduled':
				$text = 'Scheduled';
				break;
			case 'Any':
				$text = 'Status Trigger';
				break;
		}

		return $text;
	}

	/**
	 * Get users data with role "customer"
	 *
	 * @return array|object|stdClass[]|null
	 */
	public function get_users() {
		global $wpdb;

		$usermeta = $wpdb->prefix . 'usermeta';

		$request                      = array();
		$args                         = array( 'role__in' => array( 'customer', 'subscriber' ) );
		$wp_user_query                = new WP_User_Query( $args );
		$wp_user_query->query_orderby = str_replace( 'user_login', $usermeta . '.meta_value', $wp_user_query->query_orderby );
		$wp_user_query->query();
		$users = $wp_user_query->get_results();

		foreach ( $users as $u ) {
			array_push(
				$request,
				array(
					'ID'             => $u->ID,
					'user_email'     => $u->user_email,
					'first_name'     => get_user_meta( $u->ID, 'first_name', true ),
					'last_name'      => get_user_meta( $u->ID, 'last_name', true ),
					'billing_phone'  => get_user_meta( $u->ID, 'billing_phone', true ),
					'whatsapp_phone' => get_user_meta( $u->ID, 'whatsapp_phone', true ),
					'whatsapp_code'  => get_user_meta( $u->ID, 'zworkflow_whatsapp_code', true ),
				)
			);
		}

		return $request;
	}

	/**
	 * Get send name notification
	 *
	 * @return mixed
	 */
	public function get_notification_name() {
		$name = get_post_meta( $this->id, 'notification', true );

		return $name;
	}

	/**
	 * Get send user date
	 *
	 * @return string
	 */
	public function get_date() {
		$date = get_post_meta( $this->id, 'datepicker', true );
		$time = get_post_meta( $this->id, 'timepicker', true );
		if ( ! $date || ! $time ) {
			return '';
		}

		return $date . ', ' . $time;
	}

	/**
	 * Get send user phone
	 *
	 * @return array
	 */
	public function get_phone() {

		$user_recipient = get_post_meta( $this->id, 'user_recipient', true );
		$phone_arr      = array();

		if ( empty( $user_recipient ) ) {
			return $phone_arr;
		}

		if ( count( $user_recipient ) === 1 ) {
			array_push( $phone_arr, explode( ',', $user_recipient[0] )[1] );
		} elseif ( count( $user_recipient ) > 1 ) {
			if ( ! is_array( $user_recipient[0] ) ) {
				array_push( $phone_arr, 'Multiple customers' );
			} elseif ( array_key_exists( 'billing_phone', $user_recipient[0] ) ) {
				array_push( $phone_arr, 'All Customers' );
			}
		}

		return $phone_arr;
	}

	/**
	 * Get send user email
	 *
	 * @return array
	 */
	public function get_email() {
		$user_recipient = get_post_meta( $this->id, 'user_recipient', true );
		$email_arr      = array();

		if ( empty( $user_recipient ) ) {
			return $email_arr;
		}

		if ( count( $user_recipient ) === 1 ) {
			array_push( $email_arr, explode( ',', $user_recipient[0] )[0] );
		} elseif ( count( $user_recipient ) > 1 ) {
			if ( ! is_array( $user_recipient[0] ) ) {
				array_push( $email_arr, 'Multiple customers' );
			} elseif ( array_key_exists( 'user_email', $user_recipient[0] ) ) {
				array_push( $email_arr, 'All Customers' );
			}
		}

		return $email_arr;
	}

	/**
	 * Set send user email and phone
	 *
	 * @param string $user_recipient user recipient.
	 *
	 * @return bool|int
	 */
	public function set_user_recipient( $user_recipient ) {
		return update_post_meta( $this->id, 'user_recipient', $user_recipient );
	}

	/**
	 * Getting scheduled action status
	 *
	 * @return mixed
	 */
	public function get_status() {
		return get_post_meta( $this->id, 'send_status', true );
	}
}

<?php
/**
 * Flow-Notify order status functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-order-status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Order_Status
 */
class ZWORKFLOWMANAGER_Order_Status {

	/**
	 * Order Id
	 *
	 * @var int
	 */
	private $id;

	/**
	 * Order name
	 *
	 * @var string
	 */
	private $name;

	/**
	 * Order slug
	 *
	 * @var mixed
	 */
	private $slug;

	/**
	 * Description
	 *
	 * @var mixed
	 */
	private $description;

	/**
	 * Order post
	 *
	 * @var array|int|WP_Post|null
	 */
	private $order_post;

	/**
	 * ZWORKFLOWMANAGER_Order_Status constructor.
	 *
	 * @param string $id id.
	 */
	public function __construct( $id ) {

		if ( ! $id ) {
			return;
		}

		/* Get the order status post object */
		if ( is_numeric( $id ) ) {
			$this->order_post = get_post( $id );
		} elseif ( is_object( $id ) ) {
			$this->order_post = $id;
		} else {

			/* Try to get order status post object by slug */
			$posts = get_posts(
				array(
					'post_type'      => 'zworkflowstatus',
					'meta_key'       => 'zworkflowstatus_slug',
					'meta_value'     => $id,
					'posts_per_page' => 1,
				)
			);

			if ( ! empty( $posts ) ) {
				$this->order_post = $posts[0];
			}
		}

		/* Load in post data */
		if ( $this->order_post ) {

			$this->id          = $this->order_post->ID;
			$this->name        = $this->order_post->post_title;
			$this->slug        = get_post_meta( $this->order_post->ID, 'zworkflowstatus_slug', true );
			$this->description = get_post_meta( $this->order_post->ID, 'order_description', true );
		}
	}

	/**
	 * Get order status title
	 *
	 * @return array
	 */
	public function get_order_status_title() {
		global $post;

		$custom_order = array();

		$args = array(
			'post_type'              => array( 'zworkflowstatus' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$slug          = get_post_meta( $current_post->ID, 'zworkflowstatus_slug' );
				$custom_order += array( "$slug[0]" => $current_post->post_title );
			}
		}

		wp_reset_postdata();

		return $custom_order;

	}

	/**
	 * Get name
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Set name
	 *
	 * @param string $title title.
	 */
	public function set_name( $title ) {
		wp_update_post(
			array(
				'post_title' => $title,
				'ID'         => $this->id,
			)
		);
	}

	/**
	 * Get description
	 *
	 * @return mixed
	 */
	public function get_description() {
		return get_post_meta( $this->id, 'order_description', true );
	}

	/**
	 * Set description
	 *
	 * @param string $description description.
	 */
	public function set_description( $description ) {
		update_post_meta( $this->id, 'order_description', sanitize_text_field( $description ) );
	}

	/**
	 * Get background color
	 *
	 * @return mixed
	 */
	public function get_background_color() {
		return get_post_meta( $this->get_id(), 'background_color', true );
	}

	/**
	 * Get id
	 *
	 * @return int
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Set background color
	 *
	 * @param string $color color.
	 */
	public function set_background_color( $color ) {
		update_post_meta( $this->id, 'background_color', sanitize_text_field( $color ) );
	}

	/**
	 * Get text color
	 *
	 * @return mixed
	 */
	public function get_text_color() {
		return get_post_meta( $this->get_id(), 'text_color', true );
	}

	/**
	 * Set text color
	 *
	 * @param string $color color.
	 */
	public function set_text_color( $color ) {
		update_post_meta( $this->id, 'text_color', $color );
	}

	/**
	 * Set icon
	 *
	 * @param string $icon icon.
	 */
	public function set_icon( $icon ) {
		update_post_meta( $this->id, 'icon', $icon );
	}

	/**
	 * Set action icon
	 *
	 * @param string $icon action icon.
	 */
	public function set_action_icon( $icon ) {
		update_post_meta( $this->get_id(), 'action_icon', $icon );
	}

	/**
	 * Get status title
	 *
	 * @param null $slug slug.
	 *
	 * @return string
	 */
	public function get_status_title( $slug = null ) {
		if ( isset( $slug ) ) {
			$posts = get_posts(
				array(
					'post_type'      => 'zworkflowstatus',
					'meta_key'       => 'zworkflowstatus_slug',
					'meta_value'     => $slug,
					'posts_per_page' => 1,
				)
			);

			return $posts[0]->post_title;
		} else {
			$posts = get_posts(
				array(
					'post_type'      => 'zworkflowstatus',
					'meta_key'       => 'zworkflowstatus_slug',
					'meta_value'     => $this->slug,
					'posts_per_page' => 1,
				)
			);

			return $posts[0]->post_title;
		}

	}

	/**
	 * Get orders count
	 *
	 * @return int
	 */
	public function get_orders_count() {
		$posts = new WP_Query(
			array(
				'fields'         => 'ids',
				'post_type'      => 'shop_order',
				'post_status'    => $this->slug,
				'posts_per_page' => - 1,
			)
		);

		return $posts->post_count;
	}

	/**
	 * Get next statuses
	 *
	 * @return array
	 */
	public function get_next_statuses() {
		$status_arr      = array();
		$statuses_string = get_post_meta( $this->id, 'next_statuses', true );
		foreach ( explode( ',', $statuses_string ) as $status ) {
			$status_arr[ $status ] = $status;
		}

		return $status_arr;
	}

	/**
	 * Set next statuses
	 *
	 * @param array $statuses statuses.
	 */
	public function set_next_statuses( $statuses ) {
		update_post_meta( $this->id, 'next_statuses', sanitize_text_field( implode( ',', $statuses ) ) );
	}

	/**
	 * Get default status
	 *
	 * @return mixed
	 */
	public function get_default_status() {
		return get_post_meta( $this->id, 'default_status', true );
	}

	/**
	 * Set default status
	 *
	 * @param string $status status.
	 */
	public function set_default_status( $status ) {
		update_post_meta( $this->id, 'default_status', sanitize_text_field( $status ) );
	}

	/**
	 * Get core statuses
	 *
	 * @return array
	 */
	public function get_core_statuses() {
		return array(
			'wc-pending'    => _x( 'Pending payment', 'Order status', 'flow_notify_text' ),
			'wc-processing' => _x( 'Processing', 'Order status', 'flow_notify_text' ),
			'wc-on-hold'    => _x( 'On hold', 'Order status', 'flow_notify_text' ),
			'wc-completed'  => _x( 'Completed', 'Order status', 'flow_notify_text' ),
			'wc-cancelled'  => _x( 'Cancelled', 'Order status', 'flow_notify_text' ),
			'wc-refunded'   => _x( 'Refunded', 'Order status', 'flow_notify_text' ),
			'wc-failed'     => _x( 'Failed', 'Order status', 'flow_notify_text' ),
		);
	}

	/**
	 * Get type
	 *
	 * @return string|void
	 */
	public function get_type() {

		$type = __( 'Custom', 'flow_notify_text' );

		$wc_core_statuses = array(
			'wc-pending',
			'wc-processing',
			'wc-on-hold',
			'wc-completed',
			'wc-cancelled',
			'wc-refunded',
			'wc-failed',
		);

		if ( in_array( $this->get_slug(), $wc_core_statuses, true ) ) {
			$type = __( 'Core', 'flow_notify_text' );
		}

		return $type;
	}

	/**
	 * Get slug
	 *
	 * @return mixed
	 */
	public function get_slug() {
		return $this->slug;
	}

	/**
	 * Set slug
	 *
	 * @param string $slug slug.
	 */
	public function set_slug( $slug ) {
		if ( substr( $slug, 0, 3 ) === 'wc-' ) {
			update_post_meta( $this->id, 'zworkflowstatus_slug', sanitize_text_field( $slug ) );
		} else {
			update_post_meta( $this->id, 'zworkflowstatus_slug', sanitize_text_field( 'wc-' . $slug ) );
		}

	}

	/**
	 * Get is bulk action
	 *
	 * @return bool
	 */
	public function get_is_bulk_action() {
		return 'yes' === get_post_meta( $this->get_id(), 'bulk_action', true );
	}

	/**
	 * Set is bulk action
	 *
	 * @param string $is_bulk_action bulk_action.
	 */
	public function set_is_bulk_action( $is_bulk_action ) {
		update_post_meta( $this->id, 'bulk_action', sanitize_text_field( $is_bulk_action ) );
	}

	/**
	 * Get include in reports
	 *
	 * @return bool
	 */
	public function get_include_in_reports() {
		return 'yes' === get_post_meta( $this->get_id(), 'include_in_reports', true );
	}

	/**
	 * Set include in reports
	 *
	 * @param string $include_in_reports include in reports.
	 */
	public function set_include_in_reports( $include_in_reports ) {
		update_post_meta( $this->id, 'include_in_reports', $include_in_reports );
	}

	/**
	 * Check is paid status
	 *
	 * @return bool
	 */
	public function is_paid() {
		return 'yes' === get_post_meta( $this->get_id(), 'is_paid', true );
	}

	/**
	 * Needs payment
	 *
	 * @return bool
	 */
	public function needs_payment() {
		return 'needs_payment' === get_post_meta( $this->get_id(), 'is_paid', true );
	}

	/**
	 * Set is paid
	 *
	 * @param string $is_paid status.
	 */
	public function set_is_paid( $is_paid ) {
		update_post_meta( $this->id, 'is_paid', $is_paid );
	}

	/**
	 * Is core status
	 *
	 * @return bool
	 */
	public function is_core_status() {

		$core_statuses = array(
			'wc-pending',
			'wc-processing',
			'wc-on-hold',
			'wc-completed',
			'wc-cancelled',
			'wc-refunded',
			'wc-failed',
		);

		return in_array( $this->get_slug(), $core_statuses, true );
	}

	/**
	 * Has icon
	 *
	 * @return bool
	 */
	public function has_icon() {
		return (bool) $this->get_icon();
	}

	/**
	 * Get icon
	 *
	 * @return mixed
	 */
	public function get_icon() {
		return get_post_meta( $this->get_id(), 'icon', true );
	}

	/**
	 * Has action icon
	 *
	 * @return bool
	 */
	public function has_action_icon() {
		return (bool) $this->get_action_icon();
	}

	/**
	 * Get action icon
	 *
	 * @return mixed
	 */
	public function get_action_icon() {
		return get_post_meta( $this->get_id(), 'action_icon', true );
	}

	/**
	 * Has orders
	 *
	 * @param array $args get args.
	 *
	 * @return bool|int
	 */
	public function has_orders( $args = array() ) {

		$has_orders = false;

		$post_status = $this->get_slug();

		/* Check if status has been registered */
		if ( $this->get_slug() && get_post_status_object( $post_status ) ) {

			$posts = new WP_Query(
				wp_parse_args(
					$args,
					array(
						'fields'         => 'ids',
						'post_type'      => 'shop_order',
						'post_status'    => $post_status,
						'posts_per_page' => 1,
					)
				)
			);

			$has_orders = $posts->post_count;
		}

		return $has_orders;
	}
}

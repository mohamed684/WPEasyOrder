<?php
/**
 * Flow-Notify Setting functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Settings
 */
class ZWORKFLOWMANAGER_Settings {

	/**
	 * Set settings
	 *
	 * @param string $settings setting.
	 */
	public function set_settings( $settings ) {
		update_option( 'notification_email_settings', $settings );
	}

	/**
	 * Checkout settings
	 */
	public function checkout_settings() {
		add_action( 'woocommerce_after_checkout_billing_form', array( $this, 'select_field' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'save_field_values' ), 1 );
		add_action(
			'woocommerce_review_order_before_submit',
			array(
				$this,
				'add_notification_on_checkout_page',
			),
			10,
			0
		);
		add_action(
			'woocommerce_checkout_order_processed',
			array(
				$this,
				'global_subscribe_notification_func',
			),
			1,
			1
		);
	}

	/**
	 * Product settings
	 */
	public function product_settings() {
		add_action(
			'woocommerce_product_meta_start',
			array(
				$this,
				'add_notify_in_product_page',
			),
			10,
			0
		);
	}

	/**
	 * Add global subscribers to notifications
	 *
	 * @param string $order_id order id.
	 */
	public function global_subscribe_notification_func( $order_id ) {
		$adm                      = new ZWORKFLOWMANAGER_Core_Admin();
		$order                    = new WC_Order( $order_id );
		$opt_in_text              = $order->get_meta( 'opt-in_text' );
		$billing_email            = $order->get_billing_email();
		$billing_phone            = $order->get_billing_phone();
		$global_subscriber        = get_option( 'global_subscribe_notification' );
		$order_hash_email         = get_option( 'order_hash_email' );
		$communication_preference = $order->get_meta( 'opt-communication_preference' );
		$hash_email               = $adm->create_hash_key( $billing_email );

		if ( is_null( $opt_in_text ) ) {
			return;
		}

		if ( empty( $global_subscriber ) ) {
			update_option(
				'global_subscribe_notification',
				array(
					array(
						'user_name'             => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
						'user_email'            => $billing_email,
						'billing_phone'         => $billing_phone,
						'type'                  => $communication_preference . ' (guest)',
						'product_notifications' => '',
						'all_notifications'     => 'true',
					),
				)
			);
		} else {
			$global_subscriber[] = array(
				'user_name'             => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
				'user_email'            => $billing_email,
				'billing_phone'         => $billing_phone,
				'type'                  => $order->get_meta( 'opt-communication_preference' ) . ' (guest)',
				'product_notifications' => '',
				'all_notifications'     => 'true',
			);
			$global_subscriber   = array_map( 'unserialize', array_unique( array_map( 'serialize', $global_subscriber ) ) );
			update_option( 'global_subscribe_notification', $global_subscriber );
		}

		if ( empty( $order_hash_email ) ) {
			update_option(
				'order_hash_email',
				array(
					array(
						'email' => $hash_email,
						'type'  => 'order',
					),
				)
			);
		} else {
			$order_hash_email[] = array(
				'email' => $hash_email,
				'type'  => 'order',
			);
			$order_hash_email   = array_map( 'unserialize', array_unique( array_map( 'serialize', $order_hash_email ) ) );
			update_option( 'order_hash_email', $order_hash_email );
		}

		$adm->guest_opted_in( $billing_email, $billing_phone, $communication_preference );
	}

	/**
	 * Add notify in product page functional
	 */
	public function add_notify_in_product_page() {
		global $product;
		$settings_status         = new ZWORKFLOWMANAGER_Settings();
		$settings                = $settings_status->get_settings();
		$stock_quantity          = $product->get_stock_quantity();
		$get_stock_status        = $product->get_stock_status();
		$url                     = get_permalink( $product->get_id() );
		$user_id                 = get_current_user_id();
		$user                    = get_userdata( $user_id );
		$user_email              = $user->user_email;
		$subscribe_to_newsletter = get_post_meta( $product->get_id(), 'subscribe_to_newsletter' )[0];
		$btn                     = '';
		$get_cookie              = isset( $_COOKIE['Subscribed'] )
			? json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['Subscribed'] ) ) ), true )
			: array();

		if ( isset( $subscribe_to_newsletter ) ) {
			foreach ( $subscribe_to_newsletter as $item ) {
				if ( in_array( $user_email, $item ) ) {
					$btn = 'subscribed';
				}
			}
		}

		if ( ! isset( $settings['product_page'] ) ) {
			return;
		}

		if ( $stock_quantity && 'out_of_stock' === $settings['display_on_product_page'] ) {
			return;
		}

		if ( 'out_of_stock' === $settings['display_on_product_page'] && 'outofstock' !== $get_stock_status ) {
			return;
		}

		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$check = array_filter(
				$get_cookie,
				function ( $key ) {
					$request_uri = ( isset( $_SERVER['REQUEST_URI'] ) ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : null;

					return strripos( $request_uri, $key['url'] );
				}
			);
		}

		if ( is_user_logged_in() || ! empty( $check ) ) {
			?>
			<form method="POST" action="<?php echo esc_attr( $url ); ?>" id="subscribe_to_newsletter"
				  class="js-subscribe_to_newsletter">
				<?php $nonce = wp_create_nonce( 'zwf_notify_in_product' ); ?>
				<input type="hidden" name="zwf_notify_in_product" value="<?php echo esc_attr( $nonce ); ?>" id="zwf_notify_in_product">
				<div class="notify_opt_wrap">
					<input type="hidden" name="product_id" id="zworkwlof_product_id" value="<?php echo esc_attr( $product->get_id() ); ?>"/>
					<input type="hidden" name="product_url" value="<?php echo esc_attr( $url ); ?>"/>
					<div class="notify_button_text_wrap_default <?php echo esc_attr( $btn ); ?>">
						<p class="notify_opt_in_text">
							<?php esc_textarea( $settings['notify_opt_in_text'] ); ?>
						</p>
						<button type="submit" class="notify_button_text js-notify-button-text">
							<?php echo esc_textarea( $settings['notify_button_text'] ); ?>
						</button>
					</div>
					<div class="notify_button_text_wrap <?php echo esc_attr( $btn ); ?>">
						<button type="submit" disabled hidden class="notify_button_text js-notify-button-text">
							<?php echo esc_textarea( $settings['notify_button_text'] ); ?>
						</button>
						<p class="subscribed_to_notification"><?php esc_html_e( 'Subscribed to notification |', 'flow_notify_text' ); ?>
							<a href="" class="js-unsubscribe_to_notification">
								<span class="unsubscribe_to_notification"><?php esc_html_e( 'unsubscribe', 'flow_notify_text' ); ?></span>
							</a>
						</p>
					</div>
				</div>
			</form>
			<?php
		} else {
			$check_cookie = false;

			if ( isset( $_COOKIE['Subscribed'] ) ) {
				$cookie_arr = json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['Subscribed'] ) ) ) );

				foreach ( $cookie_arr as $cookie_obj ) {
					if ( $_SERVER['REQUEST_URI'] === $cookie_obj->url ) {
						$check_cookie = true;
						break;
					}
				}
			} else {
				$check_cookie = false;
			}
			?>
			<form method="POST" action="<?php echo esc_attr( $url ); ?>"
				  class="js-subscribe_to_newsletter" id="subscribe_to_newsletter">
				<?php $nonce = wp_create_nonce( 'zwf_notify_in_product' ); ?>
				<input type="hidden" name="zwf_notify_in_product" value="<?php echo esc_attr( $nonce ); ?>">
				<div class="notify_opt_wrap">
					<input type="hidden" name="product_url" value="<?php echo esc_attr( $url ); ?>"/>
					<input type="hidden" name="product_id" id="zworkwlof_product_id" value="<?php echo esc_attr( $product->get_id() ); ?>"/>
					<div class="notify_button_text_wrap_default<?php echo ( $check_cookie ) ? ' subscribed' : ''; ?>">
						<p class="notify_opt_in_text">
							<?php echo esc_textarea( $settings['notify_opt_in_text'] ); ?>
						</p>
						<label class="email_or_number-wrap" for="email_or_number">
							<input type="text" class="js-email_or_number"
								   name="email_or_number" placeholder="Email or Number">
							<span><?php esc_html_e( 'This field is required', 'flow_notify_text' ); ?></span>
						</label>
						<button type="submit" class="notify_button_text js-notify-button-text">
							<?php echo esc_textarea( $settings['notify_button_text'] ); ?>
						</button>
					</div>
					<div class="notify_button_text_wrap<?php echo ( $check_cookie ) ? ' subscribed' : ''; ?>">
						<p class="subscribed_to_notification"><?php esc_html_e( 'Subscribed to notification |', 'flow_notify_text' ); ?>
							<a href="" class="js-unsubscribe_to_notification">
								<span class="unsubscribe_to_notification"><?php esc_html_e( 'unsubscribe', 'flow_notify_text' ); ?></span>
							</a>
						</p>
					</div>
				</div>
			</form>
			<?php
		}
	}

	/**
	 * Get settings
	 *
	 * @return bool|mixed|void
	 */
	public function get_settings() {
		return get_option( 'notification_email_settings' );
	}

	/**
	 * Add notification on checkout page
	 */
	public function add_notification_on_checkout_page() {
		$settings_status = new ZWORKFLOWMANAGER_Settings();
		$settings        = $settings_status->get_settings();

		if ( ! isset( $settings['notification_opt-in'] ) ) {
			return;
		}

		?>
		<div class="notification_opt-in">
			<label for="opt-in_text">
				<input type="checkbox" class="opt-in_text" id="opt-in_text" name="opt-in_text">
				<span><?php echo esc_textarea( $settings['opt-in_text'] ); ?></span>
			</label>
		</div>
		<?php
	}

	/**
	 * Add select field
	 *
	 * @param object $checkout checkout.
	 */
	public function select_field( $checkout ) {
		if ( empty( $this->get_settings()['communication_preference'] ) ) {
			return;
		}

		echo '
                <input type="hidden" class="input-hidden" name="zworkflow_billing_code" id="zworkflow_billing_code" value="">
                <input type="hidden" name="zworkflow_billing_country" id="zworkflow_billing_country" value="">
            ';

		woocommerce_form_field(
			'communication_preference',
			array(
				'type'     => 'select',
				'required' => true,
				'class'    => array( 'form-row-wide' ),
				'label'    => 'Communication Preference',
				'options'  => $this->get_communication_methods(),
				'default'  => $this->get_settings()['default_communication_method'],
			),
			get_user_meta( get_current_user_id(), 'communication_preference', true )
		);

		$user_communication_methods = ( get_user_meta( get_current_user_id(), 'communication_preference', true ) ) ? get_user_meta( get_current_user_id(), 'communication_preference', true ) : $this->get_settings()['default_communication_method'];

		echo '<ul id="zworkflow-select-phone-type" class="' . ( 'whatsapp' === $user_communication_methods ? 'active' : '' ) . '"><li>
                <input type="radio" id="zworkflow-select-whatsapp" class="zworkflow-select-input" name="zworkflow_select_phone_type" value="whatsapp">
                <label class="zworkflow-select-phone-label" for="zworkflow-select-whatsapp">Use my WhatsApp number</label>
                <div class="zworkflow-select-cheque">';

		woocommerce_form_field(
			'whatsapp_phone',
			array(
				'type'        => 'tel',
				'required'    => false,
				'class'       => array( 'form-row-wide' ),
				'placeholder' => _x( 'Phone for WhatsApp', 'placeholder', 'woocommerce' ),
			),
			$checkout->get_value( 'whatsapp_phone' )
		);

		woocommerce_form_field(
			'zworkflow_whatsapp_code',
			array(
				'type'        => 'hidden',
				'required'    => false,
				'class'       => array( 'form-row-wide' ),
				'placeholder' => _x( 'Code for WhatsApp', 'placeholder', 'woocommerce' ),
			),
			$checkout->get_value( 'zworkflow_whatsapp_code' )
		);

		echo '</div></li><li class="active"><input type="radio" id="zworkflow-select-billing" class="zworkflow-select-input" name="zworkflow_select_phone_type" value="billing" checked>
                <label class="zworkflow-select-phone-label" for="zworkflow-select-billing">Use my billing phone number</label>
                </li>
                ';

	}

	/**
	 * Get user communication methods
	 *
	 * @return array
	 */
	private function get_user_communication_methods() {
		$communication_methods      = array();
		$user_id                    = get_current_user_id();
		$user_communication_methods = get_user_meta( $user_id, 'communication_preference', true );

		if ( 'email' === $user_communication_methods ) {
			$communication_methods['email'] = 'Email';
		}

		if ( 'sms' === $user_communication_methods ) {
			$communication_methods['sms'] = 'SMS';
		}

		if ( 'whatsapp' === $user_communication_methods ) {
			$communication_methods['whatsapp'] = 'WhatsApp';
		}

		return $communication_methods;
	}

	/**
	 * Get default communication methods
	 *
	 * @return array
	 */
	private function get_communication_methods() {
		$communication_methods = array();
		$settings              = $this->get_settings();
		if ( $settings['communication_methods_email'] ) {
			$communication_methods['email'] = 'Email';
		}

		if ( $settings['communication_methods_sms'] ) {
			$communication_methods['sms'] = 'SMS';
		}

		if ( $settings['communication_methods_whatsapp'] ) {
			$communication_methods['whatsapp'] = 'Whatsapp';
		}

		return $communication_methods;
	}

	/**
	 * Save field values
	 *
	 * @param string $order_id order id.
	 */
	public function save_field_values( $order_id ) {
		if ( isset( $_POST['woocommerce-process-checkout-nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['woocommerce-process-checkout-nonce'] ), 'woocommerce-process_checkout' ) ) {
			$communication_preference = ( isset( $_POST['communication_preference'] ) ) ? sanitize_text_field( wp_unslash( $_POST['communication_preference'] ) ) : '';
			$opt_in_text              = ( isset( $_POST['opt-in_text'] ) ) ? sanitize_text_field( wp_unslash( $_POST['opt-in_text'] ) ) : '';
			$whatsapp_phone           = ( isset( $_POST['whatsapp_phone'] ) ) ? sanitize_text_field( wp_unslash( $_POST['whatsapp_phone'] ) ) : '';
			$whatsapp_code            = ( isset( $_POST['zworkflow_whatsapp_code'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_whatsapp_code'] ) ) : '';
			$select_phone_type        = ( isset( $_POST['zworkflow_select_phone_type'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_select_phone_type'] ) ) : '';
			$billing_country          = ( isset( $_POST['zworkflow_billing_country'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_billing_country'] ) ) : '';
			$billing_code             = ( isset( $_POST['zworkflow_billing_code'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_billing_code'] ) ) : '';

			$phone_with_code = preg_replace( '/[^0-9]/', '', $whatsapp_code ) . $whatsapp_phone;
			$order           = new WC_Order( $order_id );

			if ( ! empty( $communication_preference ) ) {
				$order->update_meta_data( 'communication_preference', sanitize_text_field( $communication_preference ) );
				$order->save();
			}
			if ( ! empty( $opt_in_text ) ) {
				$order->update_meta_data( 'opt-in_text', sanitize_text_field( $opt_in_text ) );
				$order->save();
			}
			if ( ! empty( $whatsapp_phone ) && 'whatsapp' === $select_phone_type ) {
				$order->update_meta_data( 'billing_whatsapp_phone', $phone_with_code );
				$order->save();
			}
			if ( ! empty( $billing_country ) ) {
				update_user_meta( get_current_user_id(), 'zworkflow_billing_country', $billing_country );
			}
			if ( ! empty( $billing_code ) ) {
				update_user_meta( get_current_user_id(), 'zworkflow_billing_code', preg_replace( '/[^0-9]/', '', $billing_code ) );
			}
			if ( ! empty( $billing_code ) ) {
				$order->update_meta_data( 'zworkflow_billing_code', preg_replace( '/[^0-9]/', '', $billing_code ) );
				$order->save();
			}
			if ( ! empty( $select_phone_type ) ) {
				$order->update_meta_data( 'zworkflow_select_phone_type', sanitize_text_field( $select_phone_type ) );
				$order->save();
			}
		}
	}
}

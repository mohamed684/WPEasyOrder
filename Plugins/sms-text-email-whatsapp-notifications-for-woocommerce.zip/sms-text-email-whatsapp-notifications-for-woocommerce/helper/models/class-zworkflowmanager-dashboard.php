<?php
/**
 * Flow-Notify dashboard functionality
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-dashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Dashboard
 */
class ZWORKFLOWMANAGER_Dashboard {

	/**
	 * Get send posts
	 */
	public function get_send_posts() {
		global $wpdb;

		$sms_arr      = array();
		$email_arr    = array();
		$whatsapp_arr = array();

		$result_query = array_map(
			'unserialize',
			array_unique(
				array_map(
					'serialize',
					$wpdb->get_results(
						"
            SELECT ID FROM $wpdb->posts
            LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type = 'zworkflowsend'
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->postmeta.meta_key = 'send_status'
          	AND $wpdb->postmeta.meta_value = 'Success';
			"
					)
				)
			)
		);

		foreach ( $result_query as $key => $s_post ) {
			$sms      = get_post_meta( $s_post->ID, 'SMS', true );
			$email    = get_post_meta( $s_post->ID, 'email', true );
			$whatsapp = get_post_meta( $s_post->ID, 'whatsapp', true );
			if ( $sms ) {
				array_push( $sms_arr, $sms );
			}
			if ( $email ) {
				array_push( $email_arr, $email );
			}
			if ( $whatsapp ) {
				array_push( $whatsapp_arr, $whatsapp );
			}
		}

		return array(
			'Messages sent' => count( $result_query ),
			'Email'         => count( $email_arr ),
			'SMS'           => count( $sms_arr ),
			'Whatsapp'      => count( $whatsapp_arr ),
		);
	}

	/**
	 * Get send posts from data
	 *
	 * @return array[]
	 */
	public function get_send_posts_from_data() {
		global $wpdb;

		$all_date_arr      = array();
		$sms_date_arr      = array();
		$email_date_arr    = array();
		$whatsapp_date_arr = array();

		$result_query = array_map(
			'unserialize',
			array_unique(
				array_map(
					'serialize',
					$wpdb->get_results(
						"
            SELECT ID FROM $wpdb->posts
            LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type = 'zworkflowsend'
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->postmeta.meta_key = 'send_status'
          	AND $wpdb->postmeta.meta_value = 'Success';
			"
					)
				)
			)
		);

		foreach ( $result_query as $key => $s_post ) {
			$sms      = get_post_meta( $s_post->ID, 'SMS', true );
			$email    = get_post_meta( $s_post->ID, 'email', true );
			$whatsapp = get_post_meta( $s_post->ID, 'whatsapp', true );

			array_push( $all_date_arr, $this->get_month_and_day( $s_post ) );

			if ( $sms ) {
				array_push( $sms_date_arr, $this->get_month_and_day( $s_post ) );
			}

			if ( $email ) {
				array_push( $email_date_arr, $this->get_month_and_day( $s_post ) );
			}

			if ( $whatsapp ) {
				array_push( $whatsapp_date_arr, $this->get_month_and_day( $s_post ) );
			}
		}

		$all_date      = $this->get_count_message_help_func( $all_date_arr );
		$email_date    = $this->get_count_message_help_func( $email_date_arr, $all_date );
		$sms_date      = $this->get_count_message_help_func( $sms_date_arr, $all_date );
		$whatsapp_date = $this->get_count_message_help_func( $whatsapp_date_arr, $all_date );

		return array( $all_date, $email_date, $sms_date, $whatsapp_date );
	}

	/**
	 * Help function get month and day
	 *
	 * @param object $send_post send post.
	 *
	 * @return mixed
	 */
	public function get_month_and_day( $send_post ) {
		$timestamp_chedule = intval( get_post_meta( $send_post->ID, 'timestamp_chedule', true ) );

		return gmdate( 'F j', $timestamp_chedule );
	}


	/**
	 * Get count message help function
	 *
	 * @param array $arr arr.
	 *
	 * @param array $all_date all_date.
	 *
	 * @return array
	 */
	public function get_count_message_help_func( $arr, $all_date = array() ) {
		$date      = array();
		$count_arr = array_count_values( $arr );

		if ( $all_date ) {
			foreach ( $all_date as $all_key => $all_value ) {
				$all_date[ $all_key ][1] = ( ( isset( $count_arr[ $all_value[0] ] ) ) ? $count_arr[ $all_value[0] ] : 0 );
			}

			usort( $all_date, array( $this, 'cmp' ) );

			return $all_date;
		} else {
			foreach ( $count_arr as $key => $value ) {
				array_push( $date, array( $key, $value ) );
			}
			usort( $date, array( $this, 'cmp' ) );

			return $date;
		}
	}

	/**
	 * Help function for sort date
	 *
	 * @param array $a first elem.
	 * @param array $b second elem.
	 *
	 * @return int
	 */
	public function cmp( $a, $b ) {
		if ( $a[0] === $b[0] ) {
			return 0;
		}

		return ( strtotime( $a[0] ) < strtotime( $b[0] ) ) ? - 1 : 1;
	}

	/**
	 * Get timeframe schedule message
	 *
	 * @return bool|string
	 */
	public function get_timeframe_schedule_message() {
		$email_settings             = get_option( 'notification_email_settings' );
		$message_timeframe_schedule = $email_settings['message_timeframe_schedule'] ?? '';
		$schedule_timeframe_from    = $email_settings['schedule_timeframe_from'] ?? '';
		$schedule_timeframe_to      = $email_settings['schedule_timeframe_to'] ?? '';
		$schedule_timeframe         = $schedule_timeframe_from . ' to ' . $schedule_timeframe_to;

		if ( is_null( $message_timeframe_schedule ) ) {
			return false;
		}

		return $schedule_timeframe;
	}

	/**
	 * Get count of scheduled posts
	 *
	 * @return int|void
	 */
	public function get_count_of_scheduled_posts() {
		global $wpdb;
		$result_query = $wpdb->get_results(
			"
            SELECT ID FROM $wpdb->posts
            LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type = 'zworkflowsend'
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->postmeta.meta_key = 'send_status'
          	AND $wpdb->postmeta.meta_value = 'Scheduled';
			"
		);

		return count( $result_query );
	}

	/**
	 * Get count of order status posts
	 *
	 * @return int|void
	 */
	public function get_count_of_order_status_posts() {
		global $wpdb;
		$result_query = array_map(
			'unserialize',
			array_unique(
				array_map(
					'serialize',
					$wpdb->get_results(
						"
            SELECT ID FROM $wpdb->posts
            LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type = 'zworkflowstatus'
            AND $wpdb->posts.post_status = 'publish';
			"
					)
				)
			)
		);

		return count( $result_query );
	}

	/**
	 * Get count of notifications posts
	 *
	 * @return int|void
	 */
	public function get_count_of_notifications_posts() {
		global $wpdb;
		$result_query = array_map(
			'unserialize',
			array_unique(
				array_map(
					'serialize',
					$wpdb->get_results(
						"
            SELECT ID FROM $wpdb->posts
            LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type = 'zworkflowemail'
            AND $wpdb->posts.post_status = 'publish';
			"
					)
				)
			)
		);

		return count( $result_query );
	}

	/**
	 * Get activity posts
	 *
	 * @return array
	 */
	public function get_activity_posts() {
		$items = array();

		$args = array(
			'post_type'              => array( 'zworkflowsend' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '10',
			'posts_per_archive_page' => '10',
			'numberposts'            => 10,
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$custom_status  = new ZWORKFLOWMANAGER_Send( $current_post->ID );
				$item['id']     = $current_post->ID;
				$item['email']  = get_post_meta( $current_post->ID, 'notification_email', true )
					? get_post_meta( $current_post->ID, 'notification_email', true ) : $custom_status->get_email()[0];
				$item['data']   = $custom_status->get_date();
				$item['method'] = get_post_meta( $current_post->ID, 'notification_method', true )
					? get_post_meta( $current_post->ID, 'notification_method', true ) : $custom_status->get_method();
				$item['sent']   = get_post_meta( $current_post->ID, 'timestamp_chedule', true );
				array_push( $items, $item );
			}
		}

		wp_reset_postdata();

		return $items;
	}
}

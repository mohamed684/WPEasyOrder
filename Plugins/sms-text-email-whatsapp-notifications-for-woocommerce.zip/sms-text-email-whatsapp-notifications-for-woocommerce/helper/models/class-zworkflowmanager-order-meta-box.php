<?php
/**
 * Flow-Notify order metaBox
 *
 * @package Flow-Notify/helper/models/class-zworkflowmanager-order-metaBox
 */
use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Order_Meta_Box
 */
class ZWORKFLOWMANAGER_Order_Meta_Box {

	/**
	 * Order meta-box actions
	 */
	public function order_meta_box_actions() {
		add_action( 'add_meta_boxes', array( $this, 'mv_add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_order_notifications_fields' ), 10, 1 );
	}

	/**
	 * Adding Meta container admin shop_order pages
	 */
	public function mv_add_meta_boxes() {
		$screen = wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
			? wc_get_page_screen_id( 'shop-order' )
			: 'shop_order';

		add_meta_box(
			'order_notification',
			__( 'Order Notification', 'flow_notify_text' ),
			array(
				$this,
				'add_fields_for_order_notification',
			),
			$screen,
			'side',
			'core'
		);
	}

	/**
	 * Adding Meta field in the meta container admin shop_order pages
	 *
	 * @param string $post_id post_id.
	 */
	public function save_order_notifications_fields( $post_id ) {
		if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'update-post_' . $post_id ) ) {
			$notifications            = ( isset( $_POST['notification'] ) ) ? sanitize_text_field( wp_unslash( $_POST['notification'] ) ) : '';
			$description              = ( isset( $_POST['description'] ) ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
			$communication_preference = ( isset( $_POST['communication_preference'] ) ) ? sanitize_text_field( wp_unslash( $_POST['communication_preference'] ) ) : '';

			if ( 'shop_order' === get_post_type( $post_id ) ) {
				$order = new WC_Order( $post_id );

				/* Sanitize user input  and update the meta field in the database. */
				if ( isset( $notifications ) && ! empty( $notifications ) ) {
					$order->update_meta_data( 'notification', $notifications );
					$order->save();
				}
				if ( isset( $description ) && ! empty( $description ) ) {
					$order->update_meta_data( 'description', $description );
					$order->save();
				}
				if ( isset( $communication_preference ) && ! empty( $communication_preference ) ) {
					$order->update_meta_data( 'communication_preference', $communication_preference );
					$order->save();
				}
			} else {
				if ( isset( $notifications ) && ! empty( $notifications ) ) {
					update_post_meta( $post_id, 'notification', $notifications );
				}
				if ( isset( $description ) && ! empty( $description ) ) {
					update_post_meta( $post_id, 'description', $description );
				}
				if ( isset( $communication_preference ) && ! empty( $communication_preference ) ) {
					update_post_meta( $post_id, 'communication_preference', $communication_preference );
				}
			}
		}
	}

	/**
	 * Save the data of the Meta field
	 */
	public function add_fields_for_order_notification( $post ) {
		$status_send           = new ZWORKFLOWMANAGER_Send( 1 );
		$communication_methods = array();
		$settings              = get_option( 'notification_email_settings' );
		$order_id              = $post instanceof \WC_Order ? $post->get_id() : $post->ID;

		$order = new WC_Order( $order_id );

		$send_order_notification = $order->get_meta( 'send_order_notification' );

		if ( isset( $settings['communication_methods_sms'] ) ) {
			$communication_methods['sms'] = 'SMS';
		}

		if ( isset( $settings['communication_methods_email'] ) ) {
			$communication_methods['email'] = 'Email';
		}

		if ( isset( $settings['communication_methods_whatsapp'] ) ) {
			$communication_methods['whatsapp'] = 'Whatsapp';
		}
		?>
		<?php $nonce = wp_create_nonce( 'zwf_send_order_nonce' ); ?>
		<input type="hidden" id="zwf_send_order_nonce" name="zwf_send_order_nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<ul class="order_notes">
			<?php
			if ( is_array( $send_order_notification ) ) {
				foreach ( $send_order_notification as $key => $item ) {
					?>
				<li rel="<?php echo esc_attr( $key + 1 ); ?>" class="note system-note">
					<div class="note_content">
						<p><?php echo esc_textarea( $item[0] ); ?></p>
					</div>
					<p class="meta">
						<abbr class="exact-date"><?php echo esc_textarea( $item[2] ); ?></abbr>
						<span class="communication_methods"><?php echo esc_textarea( $item[1] ); ?></span>
					</p>
				</li>
					<?php
				}
			}
			?>
		</ul>
		<div class="add_note">
			<p><input type="hidden" name="order_id" class="js-order-id" value="<?php echo esc_attr( $order_id ); ?>"/>
				<input type="hidden" name="send_status" class="js-send-status" value="Success"/>
			</p>
			<p>
				<label for="notifications"><?php esc_html_e( 'Message', 'flow_notify_text' ); ?></label>
				<select class="js-select-notification" id="notification" name="notification_select">
					<option value="Instant Send"><?php esc_html_e( 'Instant Send', 'flow_notify_text' ); ?></option>
					<?php
					foreach ( $status_send->get_notification() as $n_title ) {
						echo '<option value="' . esc_attr( $n_title['post_title'] ) . '">' . esc_textarea( ucfirst( $n_title['post_title'] ) ) . '</option>';
					}
					?>
				</select>
			</p>
			<p class="communication-preference-inputs js-notification-type">
				<input type="hidden" id="message_template_id" name="message_template_id" value="">
				<label for="communication_preference"><?php esc_html_e( 'Type', 'flow_notify_text' ); ?></label>
				<input type="hidden" class="js-communication-preference">
					<?php
					foreach ( $communication_methods as $key => $method ) {
						?>
						<input type="checkbox"
							   class="js-sending-type js-sending-required js-notification-communication-preference"
							   data-role="disabled-btn"
							   id="<?php echo esc_textarea( ( 'SMS' !== $key ) ? strtolower( $key ) : $key ); ?>"
							   value="<?php echo esc_textarea( ( 'SMS' !== $key ) ? strtolower( $key ) : $key ); ?>"
							   name="<?php echo esc_textarea( ( 'SMS' !== $key ) ? strtolower( $key ) : $key ); ?>"
							<?php echo ( 'whatsapp' === $key ) ? ' onclick="return false;" readonly' : ''; ?>>
						<span><?php echo esc_attr( $method ); ?></span>
					<?php } ?>
			</p>
			<p class="zcustomemail_subject-wrap">
				<label for="subject"><?php esc_html_e( 'Subject', 'flow_notify_text' ); ?></label>
				<input type="text"
					class="short js-subject"
					name="subject"
					id="subject"
					value="<?php echo esc_attr( $status_send->get_data( 'subject' ) ); ?>"
					maxlength="35">
			</p>
			<p>
			<textarea class="js-message-input js-zwf-message "
					data-role="disabled-btn"
					name="description"
					id="message"
					spellcheck="false"></textarea>
			</p>
			<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/supported-data-types.php'; ?>
			<p class="button_wrap">
				<button type="submit" class="button button-primary button-submit js-send-order-notification">
					<?php esc_html_e( 'Send Now', 'flow_notify_text' ); ?>
				</button>
			</p>
		</div>
		<?php
	}
}

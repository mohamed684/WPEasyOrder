<?php
/**
 * Flow-Notify admin functionality
 *
 * @package Flow-Notify/helper/class-zworkflowmanager-core-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ZWORKFLOWMANAGER_Core_Admin
 */
class ZWORKFLOWMANAGER_Core_Admin {

	/**
	 * ZWORKFLOWMANAGER_Core_Admin constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init_hooks' ), 10 );
	}

	/**
	 * Init hooks
	 */
	public function init_hooks() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'Flow Notify requires WooCommerce to be activated. Please activate WooCommerce.', 'flow_notify_text' ); ?></p></div>
					<?php
				}
			);
			return;
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Dashboard' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-dashboard.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Schedule_Time_Frame' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-schedule-time-frame.php';
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Meta_Box' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-meta-box.php';
		}

		/* Include Corporate Page header to Setting page */
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Page_Header_Admin' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-page-header-admin.php';
		}

		/* Include main "send" functionality class */
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		/* Include timing functionality class */
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Timing_Schedule' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-timing-schedule.php';
		}

		/* Include logger functionality class */
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
		}

		add_action(
			'admin_enqueue_scripts',
			function () {
				global $post;

				wp_enqueue_script( 'media-upload' );
				wp_enqueue_script( 'thickbox' );
				wp_enqueue_style( 'thickbox' );

				if ( isset( $post->ID ) ) {
					wp_enqueue_media(
						array(
							'post' => $post->ID,
						)
					);
				}
			}
		);
		add_action( 'admin_enqueue_scripts', array( $this, 'load_resources' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'load_resources' ) );

		add_action( 'admin_init', array( $this, 'admin_init' ) );

		/* Ajax Post */
		add_action( 'wp_ajax_zworkflowmanager_wc_notice_dismissed', array( $this, 'zworkflowmanager_wc_notice_dismissed' ) );
		add_action( 'wp_ajax_change_custom_email_status', array( $this, 'change_custom_email_status' ) );
		add_action( 'wp_ajax_change_message_template_status', array( $this, 'change_message_template_status' ) );
		add_action( 'wp_ajax_add_whatsapp_message_template', array( $this, 'add_whatsapp_message_template' ) );
		add_action( 'wp_ajax_reassign_orders_statuses', array( $this, 'reassign_orders_statuses' ) );
		add_action( 'wp_ajax_delete_status_directly', array( $this, 'delete_order_status_directly' ) );
		add_action( 'wp_ajax_select_notification_type', array( $this, 'select_notification_type' ) );
		add_action( 'wp_ajax_workflow_change_order_status', array( $this, 'workflow_change_order_status' ) );
		add_action( 'wp_ajax_nopriv_subscribe_to_newsletter', array( $this, 'subscribe_to_newsletter' ) );
		add_action( 'wp_ajax_subscribe_to_newsletter', array( $this, 'subscribe_to_newsletter' ) );
		add_action( 'wp_ajax_nopriv_unsubscribe_to_newsletter', array( $this, 'unsubscribe_to_newsletter' ) );
		add_action( 'wp_ajax_unsubscribe_to_newsletter', array( $this, 'unsubscribe_to_newsletter' ) );
		add_action( 'wp_ajax_nopriv_new_guest_capture_action', array( $this, 'new_guest_capture_action' ) );
		add_action( 'wp_ajax_new_guest_capture_action', array( $this, 'new_guest_capture_action' ) );
		add_action( 'wp_ajax_save_notification_details', array( $this, 'save_notification_details' ) );
		add_action( 'wp_ajax_send_order_notification', array( $this, 'send_order_notification' ) );
		add_action( 'wp_ajax_check_subscription_user', array( $this, 'check_subscription_user' ) );
		add_action( 'wp_ajax_nopriv_check_subscription_user', array( $this, 'check_subscription_user' ) );
		add_action( 'wp_ajax_get_product_for_placeholder', array( $this, 'get_product_for_placeholder' ) );
		add_action( 'wp_ajax_nopriv_get_product_for_placeholder', array( $this, 'get_product_for_placeholder' ) );
		add_action( 'wp_ajax_get_variations_for_placeholder', array( $this, 'get_variations_for_placeholder' ) );
		add_action( 'wp_ajax_nopriv_get_variations_for_placeholder', array( $this, 'get_variations_for_placeholder' ) );

		/* Send twilio test message */
		add_action( 'wp_ajax_twilio_test_message', array( $this, 'twilio_test_message' ) );

		/* Send twilio Quick SMS message */
		add_action( 'wp_ajax_twilio_quick_send', array( $this, 'twilio_quick_send' ) );

		/* Save setting for "Twilio Gateway" */
		add_action( 'admin_post_zwf_twilio_gateway_save_changes', array( $this, 'zwf_twilio_gateway_save_changes' ) );
		add_action( 'admin_post_zwf_whatsapp_gateway_save_changes', array( $this, 'zwf_whatsapp_gateway_save_changes' ) );

		add_action( 'admin_menu', array( $this, 'add_menu_pages' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_media_files' ) );
		add_action( 'personal_options_update', array( $this, 'update_extra_profile_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'update_extra_profile_fields' ) );

		add_action( 'admin_post_zworkflowmanager_edit_status', array( $this, 'edit_order_status' ) );
		add_action( 'admin_post_zworkflowmanager_email_template', array( $this, 'save_email_template' ) );
		add_action( 'admin_post_zworkflowmanager_settings_template', array( $this, 'save_settings_template' ) );
		add_action( 'admin_post_zworkflowmanager_new_status', array( $this, 'new_order_status' ) );
		add_action( 'admin_post_zworkflowmanager_new_email', array( $this, 'new_email_status' ) );
		add_action( 'admin_post_zworkflowmanager_new_message_template', array( $this, 'new_message_template' ) );
		add_action( 'admin_post_zworkflowmanager_edit_email', array( $this, 'edit_email_status' ) );
		add_action( 'admin_post_zworkflowmanager_edit_message_template', array( $this, 'edit_message_template' ) );
		add_action( 'admin_post_zworkflowmanager_edit_send', array( $this, 'edit_send' ) );
		add_action( 'admin_post_zworkflowmanager_new_send', array( $this, 'new_send_from_admin' ) );
		add_action( 'admin_post_opt_ins_table_action', array( $this, 'opt_ins_table_action' ) );
		add_action( 'woocommerce_order_status_changed', array( $this, 'so_order_status_changed' ), 10, 3 );
		add_action( 'woocommerce_new_order', array( $this, 'so_order_created' ), 10, 2 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'so_order_paid' ) );
		add_action( 'woocommerce_order_status_completed', array( $this, 'order_total_reaches' ) );

		add_action( 'user_register', array( $this, 'so_user_registered' ), 10, 1 );
		add_action( 'profile_update', array( $this, 'so_user_opted_in' ), 10, 2 );
		add_action( 'profile_update', array( $this, 'so_user_opted_out' ), 10, 2 );

		add_filter( 'posts_where', array( $this, 'order_status_like' ), 10, 2 );

		/* WooCommerce */
		add_filter( 'wc_order_statuses', array( $this, 'get_order_statuses' ) );
		add_filter( 'woocommerce_order_is_paid_statuses', array( $this, 'order_paid_statuses' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_payment', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_cancel', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_order_is_pending_statuses', array( $this, 'order_needs_payment_statuses' ) );
		add_filter( 'woocommerce_admin_order_actions', array( $this, 'admin_order_actions_overwrite' ) );
		add_action( 'woocommerce_admin_order_actions_start', array( $this, 'admin_order_actions_start' ) );
		add_filter( 'bulk_actions-edit-shop_order', array( $this, 'register_my_bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'my_bulk_action_handler' ), 10, 3 );
		add_filter( 'manage_shop_order_posts_custom_column', array( $this, 'order_status_column_display' ), 10 );
		add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_order_column_header' ), 20 );
		/* First Register the Tab by hooking into the 'woocommerce_product_data_tabs' filter */
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_my_custom_product_data_tab' ) );
		/* functions you can call to output text boxes, select boxes, etc. */
		add_action( 'woocommerce_product_data_panels', array( $this, 'add_my_custom_product_data_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'on_product_save' ) );
		add_action( 'woocommerce_product_before_set_stock', array( $this, 'stock_changed' ) );
		add_action( 'woocommerce_variation_before_set_stock', array( $this, 'stock_changed' ) );
		add_action( 'show_user_profile', array( $this, 'filter_custom_user_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'filter_custom_user_fields' ) );
		add_action( 'show_user_profile', array( $this, 'extra_contact_info' ) );
		add_action( 'edit_user_profile', array( $this, 'extra_contact_info' ) );
		add_action( 'personal_options_update', array( $this, 'save_custom_user_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_custom_user_fields' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'display_custom_field_order_details' ), 10, 1 );
		add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'custom_variation_fields' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'variations_save_fields' ), 10, 2 );
		add_action( 'wp_mail_failed', array( $this, 'on_mail_error' ), 10, 1 );

		$order_meta_box = new ZWORKFLOWMANAGER_Order_Meta_Box();
		$order_meta_box->order_meta_box_actions();
	}

	public function get_product_for_placeholder() {
		$request         = ( isset( $_GET['request'] ) ) ? sanitize_text_field( wp_unslash( $_GET['request'] ) ) : '';
		$offset          = ( isset( $_GET['offset'] ) ) ? sanitize_text_field( wp_unslash( $_GET['offset'] ) ) : 0;
		$select_products = ( isset( $_GET['select_products'] ) ) ? sanitize_text_field( wp_unslash( $_GET['select_products'] ) ) : 0;
		$limit           = 20;

		if ( ! empty( $request ) ) {
			global $wpdb;

			$results = $wpdb->get_results(
				$wpdb->prepare(
					"
                    SELECT `ID`, `post_title` FROM $wpdb->posts
                    WHERE post_type = 'product'
                    AND post_status = 'publish'
                    AND post_title LIKE %s
                    LIMIT %d OFFSET %d
                    ",
					$wpdb->esc_like( $request ) . '%',
					$limit,
					$offset
				),
				ARRAY_A
			);

			$array_response = array();

			if ( is_array( $results ) ) {
				foreach ( $results as &$product ) {
					$product_obj = wc_get_product( $product['ID'] );
					if ( is_a( $product_obj, 'WC_Product' ) && $product_obj->is_type( 'variable' ) ) {
						$product['variations'] = 1;
					}
					if ( $offset ) {
						$product['offset'] = $offset;
					}
				}

				$array_response['items'] = $results;

				if ( $offset ) {
					$array_response['offset'] = $offset;
				}

				if ( $select_products ) {
					$array_response['select_products'] = $select_products;
				}

				echo wp_json_encode( $array_response );
			}
		}

		wp_die();
	}

	public function get_variations_for_placeholder() {
		$product_id = ( isset( $_GET['product_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['product_id'] ) ) : '';

		if ( ! empty( $product_id ) ) {
			global $wpdb;

			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID, post_title
                    FROM $wpdb->posts
                    WHERE post_type = 'product_variation' AND post_status = 'publish' AND post_parent = %d",
					$product_id
				),
				ARRAY_A
			);

			echo wp_json_encode( $results );

		}
		wp_die();
	}

	public function on_mail_error( $errors ) {
		if ( is_wp_error( $errors ) ) {
			$logger = new ZWORKFLOWMANAGER_Logger();
			$logger->log( $errors->get_error_message() );
		}
	}

	/**
	 * Display custom field_order details
	 *
	 * @param string $order get order id.
	 */
	public function display_custom_field_order_details( $order ) {
		$order              = new WC_Order( $order->get_id() );
		$custom_field_value = $order->get_meta( 'billing_whatsapp_phone' );
		echo wp_kses_post( '<p><strong>WhatsApp phone:</strong> ' . $custom_field_value . '</p>' );
	}

	/**
	 * Filter custom user fields
	 */
	public function filter_custom_user_fields( $user ) {
		$user_id = $user->ID;
		?>
		<h2><?php esc_html_e( 'WhatsApp Phone', 'flow_notify_text' ); ?></h2>
		<table class="form-table">
			<tr>
				<th><label for="whatsapp_phone"><?php esc_html_e( 'WhatsApp Phone', 'flow_notify_text' ); ?></label></th>
				<td>
					<input type="text" name="whatsapp_phone" id="whatsapp_phone" value="<?php echo esc_attr( get_the_author_meta( 'whatsapp_phone', $user_id ) ); ?>" class="regular-text">
					<input type="hidden" name="zworkflow_whatsapp_code" id="zworkflow_whatsapp_code" value="<?php echo esc_attr( get_the_author_meta( 'zworkflow_whatsapp_code', $user_id ) ); ?>">
					<input type="hidden" name="zworkflow_whatsapp_country" id="zworkflow_whatsapp_country" value="<?php echo esc_attr( get_the_author_meta( 'zworkflow_whatsapp_country', $user_id ) ); ?>">
				</td>
			</tr>
			<tr>
			<input type="hidden" name="zworkflow_billing_code" id="zworkflow_billing_code" value="<?php echo esc_attr( get_the_author_meta( 'zworkflow_billing_code', $user_id ) ); ?>">
			<input type="hidden" name="zworkflow_billing_country" id="zworkflow_billing_country" value="<?php echo esc_attr( get_the_author_meta( 'zworkflow_billing_country', $user_id ) ); ?>">
			</tr>
		</table>
		<?php
	}

	/**
	 * Save custom user fields
	 *
	 * @param string $user_id get user_id.
	 */
	public function save_custom_user_fields( $user_id ) {
		if ( current_user_can( 'edit_user', $user_id ) ) {
			if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'update-user_' . $user_id ) ) {
				$whatsapp_phone             = ( isset( $_POST['whatsapp_phone'] ) ) ? sanitize_text_field( wp_unslash( $_POST['whatsapp_phone'] ) ) : '';
				$zworkflow_whatsapp_code    = ( isset( $_POST['zworkflow_whatsapp_code'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_whatsapp_code'] ) ) : '';
				$zworkflow_whatsapp_country = ( isset( $_POST['zworkflow_whatsapp_country'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_whatsapp_country'] ) ) : '';
				$zworkflow_billing_country  = ( isset( $_POST['zworkflow_billing_country'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_billing_country'] ) ) : '';
				$zworkflow_billing_code     = ( isset( $_POST['zworkflow_billing_code'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zworkflow_billing_code'] ) ) : '';

				if ( isset( $whatsapp_phone ) ) {
					update_user_meta( $user_id, 'whatsapp_phone', $whatsapp_phone );
				}
				if ( isset( $zworkflow_whatsapp_code ) ) {
					update_user_meta( $user_id, 'zworkflow_whatsapp_code', $zworkflow_whatsapp_code );
				}
				if ( isset( $zworkflow_whatsapp_country ) ) {
					update_user_meta( $user_id, 'zworkflow_whatsapp_country', $zworkflow_whatsapp_country );
				}
				if ( isset( $zworkflow_billing_country ) ) {
					update_user_meta( $user_id, 'zworkflow_billing_country', $zworkflow_billing_country );
				}
				if ( isset( $zworkflow_billing_code ) ) {
					update_user_meta( $user_id, 'zworkflow_billing_code', $zworkflow_billing_code );
				}
			}
		}
	}

	/**
	 * Opt out selected user in Opt-ins Notifications tab
	 */
	public function opt_ins_table_action() {

		if ( ( isset( $_POST['zwf_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['zwf_nonce'] ), 'zwf_opt_nonce' ) ) ) {
			$bulk_actions                   = ( isset( $_GET['bulk_actions'] ) ) ? sanitize_text_field( wp_unslash( $_GET['bulk_actions'] ) ) : '';
			$user_ids                       = ( isset( $_GET['user_ids'] ) && is_array( $_GET['user_ids'] ) ) ? array_map( 'sanitize_text_field', $_GET['user_ids'] ) : '';
			$global_subscriber              = get_option( 'global_subscribe_notification' );
			$subscribe_to_newsletter_option = get_option( 'subscribe_to_newsletter' );

			/* Check whether action that user wants to perform is our custom action */
			if ( 'opted_out_both' === $bulk_actions ) {
				foreach ( $user_ids as $user_id ) {
					update_user_meta( $user_id, 'product_notifications', false );
					update_user_meta( $user_id, 'all_notifications', false );

					foreach ( $global_subscriber as $key => $item ) {
						$check = in_array( $user_id, $item, true );

						if ( ! $check ) {
							continue;
						}
						unset( $global_subscriber[ $key ] );
					}
					foreach ( $subscribe_to_newsletter_option as $key => $item ) {
						$check = in_array( $user_id, $item, true );

						if ( ! $check ) {
							continue;
						}
						unset( $subscribe_to_newsletter_option[ $key ] );
					}
					update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );
					update_option( 'global_subscribe_notification', $global_subscriber );
				}
			}

			if ( 'opted_out_order' === $bulk_actions ) {
				foreach ( $user_ids as $user_id ) {
					update_user_meta( $user_id, 'all_notifications', false );

					foreach ( $global_subscriber as $key => $item ) {
						$check = in_array( $user_id, $item, true );

						if ( ! $check ) {
							continue;
						}
						unset( $global_subscriber[ $key ] );
					}
					update_option( 'global_subscribe_notification', $global_subscriber );
				}
			}

			if ( 'opted_out_product' === $bulk_actions ) {
				foreach ( $user_ids as $user_id ) {
					update_user_meta( $user_id, 'product_notifications', false );

					foreach ( $subscribe_to_newsletter_option as $key => $item ) {
						$check = in_array( $user_id, $item, true );

						if ( ! $check ) {
							continue;
						}
						unset( $subscribe_to_newsletter_option[ $key ] );
					}
					update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );
				}
			}

			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=activities&section=opt-ins' ) );
			exit;
		}
	}

	/**
	 * Update extra profile fields
	 *
	 * @param string $user_id get user_id.
	 */
	public function update_extra_profile_fields( $user_id ) {
		if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'update-user_' . $user_id ) ) {
			$communication_preference = ( isset( $_POST['communication_preference'] ) ) ? sanitize_text_field( wp_unslash( $_POST['communication_preference'] ) ) : '';
			$product_notifications    = ( isset( $_POST['product_notifications'] ) ) ? sanitize_text_field( wp_unslash( $_POST['product_notifications'] ) ) : '';
			$all_notifications        = ( isset( $_POST['all_notifications'] ) ) ? sanitize_text_field( wp_unslash( $_POST['all_notifications'] ) ) : '';

			if ( isset( $communication_preference ) ) {
				update_user_meta( $user_id, 'communication_preference', $communication_preference );
			}
			if ( isset( $product_notifications ) || is_null( $product_notifications ) ) {
				update_user_meta( $user_id, 'product_notifications', $product_notifications );
			}
			if ( isset( $all_notifications ) || is_null( $all_notifications ) ) {
				update_user_meta( $user_id, 'all_notifications', $all_notifications );
			}
		}
	}

	/**
	 * Add custom fields in user contact info tab
	 *
	 * @param array $user user object.
	 *
	 * @return mixed
	 */
	public function extra_contact_info( $user ) {
		$user_id               = $user->ID;
		$communication_methods = array();
		$settings              = get_option( 'notification_email_settings' );

		if ( $settings['communication_methods_email'] ) {
			$communication_methods['email'] = 'Email';
		}

		if ( $settings['communication_methods_sms'] ) {
			$communication_methods['sms'] = 'SMS';
		}

		if ( $settings['communication_methods_whatsapp'] ) {
			$communication_methods['whatsapp'] = 'WhatsApp';
		}

		?>
		<table class="form-table">
			<tr>
				<th>
					<label for="communication_preference"><?php esc_html_e( 'Communication Preference', 'flow_notify_text' ); ?></label>
				</th>
				<td>
					<select name="communication_preference" id="communication_preference">
					<option selected value=""><?php esc_html_e( 'Select Preference...', 'flow_notify_text' ); ?></option>
						<?php
						foreach ( $communication_methods as $key => $method ) {
							$selected = selected( $key, get_user_meta( $user_id, 'communication_preference' )[0], false );
							?>
							<option <?php echo esc_attr( $selected ); ?> value="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $method ); ?></option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<th>
					<label for="notification_opt_ins"><?php esc_html_e( 'Notification Opt-ins', 'flow_notify_text' ); ?></label>
				</th>
				<td>
					<label for="product_notifications">
					<?php
					$checked = get_user_meta( $user_id, 'product_notifications', true ) ? 'checked' : '';
					?>
						<input type="checkbox" name="product_notifications"
						<?php echo esc_attr( $checked ); ?>
							id="product_notifications" value="true"><?php esc_html_e( 'Product notifications. Opted in notifications for specific products.', 'flow_notify_text' ); ?></label>
				</td>
			</tr>
			<tr>
				<th></th>
				<td>
					<label for="all_notifications">
					<?php
					$checked = get_user_meta( $user_id, 'all_notifications', true ) ? 'checked' : '';
					?>
						<input type="checkbox" name="all_notifications"
						<?php echo esc_attr( $checked ); ?>
						id="all_notifications" value="true"><?php esc_html_e( 'All notifications. Opted in notifications for all products, promotions and more.', 'flow_notify_text' ); ?>
					</label>
				</td>
			</tr>
		<?php
	}

	/**
	 * Includes all files required to use the WordPress media API (upload and select files window).
	 */
	public function load_media_files() {
		wp_enqueue_media();
	}

	/**
	 * Subscribe to newsletter
	 */
	public function subscribe_to_newsletter() {
		if ( ! isset( $_POST['zwf_notify_in_product'] ) && ! wp_verify_nonce( sanitize_key( $_POST['zwf_notify_in_product'] ), 'zwf_notify_in_product' ) ) {
			return;
		}
		$product_id                     = ( isset( $_POST['product_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['product_id'] ) ) : '';
		$email_or_number                = ( isset( $_POST['email_or_number'] ) ) ? sanitize_text_field( wp_unslash( $_POST['email_or_number'] ) ) : '';
		$subscribe_to_newsletter        = get_post_meta( $product_id, 'subscribe_to_newsletter' )[0];
		$subscribe_to_newsletter_option = get_option( 'subscribe_to_newsletter' );
		$order_hash_email               = get_option( 'order_hash_email' );
		$user_id                        = get_current_user_id();
		$user                           = get_userdata( $user_id );
		$check_email                    = preg_match( '/^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/', $email_or_number );
		$check_phone                    = preg_match( '/^[0-9\+]{11,15}$/', $email_or_number );
		$product                        = wc_get_product( $product_id );
		$product_url                    = $product->get_permalink();
		$product_url                    = str_replace( get_site_url(), '', htmlspecialchars( sanitize_text_field( wp_unslash( $product_url ) ) ) );
		$get_cookie                     = isset( $_COOKIE['Subscribed'] )
			? json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['Subscribed'] ) ) ), true ) : array();

		if ( is_user_logged_in() ) {
			$user_email          = $user->user_email;
			$user_phone          = get_user_meta( $user_id, 'billing_phone', true );
			$user_whatsapp_phone = get_user_meta( $user_id, 'whatsapp_phone', true );
			$user_whatsapp_code  = get_user_meta( $user_id, 'zworkflow_whatsapp_code', true );
			$billing_phone_code  = get_user_meta( $user_id, 'zworkflow_billing_code', true );
		} else {
			$user_email = ( $check_email ) ? $email_or_number : '';
			$user_phone = ( $check_phone ) ? $email_or_number : '';

			if ( empty( $get_cookie ) ) {
				$set_cookie = $user_email ? array(
					array(
						'contacts' => $user_email,
						'url'      => $product_url,
					),
				) : array(
					array(
						'contacts' => $user_phone,
						'url'      => $product_url,
					),
				);
				setcookie( 'Subscribed', wp_json_encode( $set_cookie ), strtotime( '+1 year' ), '/' );
			} else {
				$set_cookie   = $user_email ? array(
					'contacts' => $user_email,
					'url'      => $product_url,
				) : array(
					'contacts' => $user_phone,
					'url'      => $product_url,
				);
				$get_cookie[] = $set_cookie;
				$get_cookie   = array_map( 'unserialize', array_unique( array_map( 'serialize', $get_cookie ) ) );
				setcookie( 'Subscribed', wp_json_encode( $get_cookie ), strtotime( '+1 year' ), '/' );
			}
		}

		if ( $user_email ) {
			$hash_email = $this->create_hash_key( $user_email );

			if ( empty( $order_hash_email ) ) {
				update_option(
					'order_hash_email',
					array(
						array(
							'email' => $hash_email,
							'type'  => 'product',
						),
					)
				);
			} else {
				$order_hash_email[] = array(
					'email' => $hash_email,
					'type'  => 'product',
				);
				$order_hash_email   = array_map( 'unserialize', array_unique( array_map( 'serialize', $order_hash_email ) ) );
				update_option( 'order_hash_email', $order_hash_email );
			}
		}

		if ( $user_email || $user_phone ) {
			$type = $user_email ? 'email' : 'sms';
			if ( empty( $subscribe_to_newsletter ) ) {
				update_post_meta(
					$product_id,
					'subscribe_to_newsletter',
					array(
						array(
							'user_email'         => $user_email,
							'billing_phone'      => $user_phone,
							'billing_phone_code' => $billing_phone_code,
							'whatsapp_phone'     => $user_whatsapp_phone,
							'whatsapp_code'      => $user_whatsapp_code,
						),
					)
				);

				if ( empty( get_option( 'subscribe_to_newsletter' ) ) ) {

					update_option(
						'subscribe_to_newsletter',
						array(
							'user_email'            => $user_email,
							'billing_phone'         => $user_phone,
							'billing_phone_code'    => $billing_phone_code,
							'whatsapp_phone'        => $user_whatsapp_phone,
							'whatsapp_code'         => $user_whatsapp_code,
							'product_notifications' => 'true',
							'all_notifications'     => '',
							'url'                   => $product_url,
						)
					);

				} else {

					$subscribe_to_newsletter_option[] = array(
						'user_email'            => $user_email,
						'billing_phone'         => $user_phone,
						'billing_phone_code'    => $billing_phone_code,
						'whatsapp_phone'        => $user_whatsapp_phone,
						'whatsapp_code'         => $user_whatsapp_code,
						'product_notifications' => 'true',
						'all_notifications'     => '',
						'url'                   => $product_url,
					);
					$subscribe_to_newsletter_option   = array_map( 'unserialize', array_unique( array_map( 'serialize', $subscribe_to_newsletter_option ) ) );
					update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );

				}
			} else {
				$subscribe_to_newsletter[] = array(
					'user_email'         => $user_email,
					'billing_phone'      => $user_phone,
					'billing_phone_code' => $billing_phone_code,
					'whatsapp_phone'     => $user_whatsapp_phone,
					'whatsapp_code'      => $user_whatsapp_code,
				);
				$subscribe_to_newsletter   = array_map( 'unserialize', array_unique( array_map( 'serialize', $subscribe_to_newsletter ) ) );

				$subscribe_to_newsletter_option[] = array(
					'user_email'            => $user_email,
					'billing_phone'         => $user_phone,
					'billing_phone_code'    => $billing_phone_code,
					'whatsapp_phone'        => $user_whatsapp_phone,
					'whatsapp_code'         => $user_whatsapp_code,
					'product_notifications' => 'true',
					'all_notifications'     => '',
					'url'                   => $product_url,
				);
				$subscribe_to_newsletter_option   = array_map( 'unserialize', array_unique( array_map( 'serialize', $subscribe_to_newsletter_option ) ) );
				update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );
				update_post_meta( $product_id, 'subscribe_to_newsletter', $subscribe_to_newsletter );
			}

			$this->guest_opted_in( $user_email, $user_phone, $type );
		}

		wp_send_json_success();

		exit;
	}

	public function check_subscription_user() {
		if ( ! isset( $_POST['zwf_notify_in_product'] ) || ! wp_verify_nonce( sanitize_key( $_POST['zwf_notify_in_product'] ), 'zwf_notify_in_product' ) ) {
			return;
		}
		$variation_id = ( isset( $_POST['variation_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['variation_id'] ) ) : '';

		if ( ! empty( $variation_id ) ) {
			$result           = array();
			$result['status'] = false;
			if ( is_user_logged_in() ) {
				$user_id                 = get_current_user_id();
				$user                    = get_userdata( $user_id );
				$user_email              = $user->user_email;
				$subscribe_to_newsletter = get_post_meta( $variation_id, 'subscribe_to_newsletter', true );

				if ( is_array( $subscribe_to_newsletter ) ) {
					foreach ( $subscribe_to_newsletter as $item ) {
						if ( in_array( $user_email, $item ) ) {
							 $result['status'] = true;
							break;
						}
					}
				}
			} else {
				$product     = wc_get_product( $variation_id );
				$product_url = $product->get_permalink();
				$product_url = str_replace( get_site_url(), '', htmlspecialchars( sanitize_text_field( wp_unslash( $product_url ) ) ) );

				if ( isset( $_COOKIE['Subscribed'] ) ) {
					$cookie_arr = json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['Subscribed'] ) ) ) );
				}

				if ( is_array( $cookie_arr ) ) {
					foreach ( $cookie_arr as $cookie_obj ) {
						if ( $product_url === $cookie_obj->url ) {
							$result['status'] = true;
							break;
						}
					}
				}
			}
		}
		echo json_encode( $result );
		exit;
	}

	/**
	 * Create hash_key
	 *
	 * @param string $email get email.
	 *
	 * @return false|string
	 */
	public function create_hash_key( $email ) {
		$hash  = md5( $this->generate_random_string( 2 ) );
		$hash .= $email;
		$hash .= md5( $this->generate_random_string( 2 ) );

		return $hash;
	}

	/**
	 * Get random string
	 *
	 * @param int $length get length.
	 *
	 * @return string
	 */
	public function generate_random_string( $length = 10 ) {
		$characters        = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$characters_length = strlen( $characters );
		$random_string     = '';

		for ( $i = 0; $i < $length; $i ++ ) {
			$random_string .= $characters[ wp_rand( 0, $characters_length - 1 ) ];
		}

		return $random_string;
	}

	/**
	 * Guest opt-ins
	 *
	 * @param string $email email.
	 * @param string $phone phone.
	 * @param string $communication_preference communication_preference.
	 *
	 * @return array|string[]
	 */
	public function guest_opted_in( $email, $phone, $communication_preference ) {

		$data  = array();
		$users = array( $email . ',' . $phone );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_opted_in',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $communication_preference || 'sms' === $communication_preference )
							? $communication_preference : '',
						'email'           => ( 'email' === $communication_preference ) ? $communication_preference : '',
						'whatsapp'        => ( 'whatsapp' === $communication_preference ) ? $communication_preference : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $communication_preference,
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $users, null, $data, null );
	}

	/**
	 * Send to users from admin
	 *
	 * @param array       $users users.
	 * @param null|string $sending_type sending_type.
	 * @param null|array  $data data.
	 * @param null|string $id id.
	 * @param null|string $order_id order_id.
	 *
	 * @return array|string[]
	 */
	public function send_from_admin( $users, $sending_type = null, $data = null, $id = null, $order_id = null ) {
		$result          = array();
		$admin_email     = get_option( 'admin_email' );
		$post_update_id  = ( $id ) ? $id : 0;
		$placeholder_arr = $this->get_information_by_order( $order_id );
		$order           = new WC_Order( $order_id );

		if ( ! is_null( $sending_type ) ) {
			$type_sms      = $sending_type;
			$type_email    = $sending_type;
			$type_whatsapp = $sending_type;
		}

		if ( is_array( $data ) ) {
			foreach ( $data as $item ) {
				$type_sms        = ( isset( $item['sms'] ) ) ? $item['sms'] : '';
				$type_email      = ( isset( $item['email'] ) ) ? $item['email'] : '';
				$type_whatsapp   = ( isset( $item['whatsapp'] ) ) ? $item['whatsapp'] : '';
				$message         = ( isset( $item['description'] ) ) ? $item['description'] : '';
				$subject         = ( isset( $item['subject'] ) ) ? $item['subject'] : '';
				$post_update_id  = ( isset( $item['post_id'] ) ) ? $item['post_id'] : '';
				$template_name   = ( isset( $item['template_name'] ) ) ? $item['template_name'] : '';
				$template_lang   = ( isset( $item['template_lang'] ) ) ? $item['template_lang'] : '';
				$whatsapp_phone  = ( isset( $item['whatsapp_phone'] ) ) ? $item['whatsapp_phone'] : '';
				$notification_id = ( isset( $item['notification_id'] ) ) ? $item['notification_id'] : '';

				array_push( $result, $this->send_message_helper( $users, $type_sms, $type_whatsapp, $type_email, $admin_email, $placeholder_arr, $message, $subject, $post_update_id, false, $template_name, $template_lang, $whatsapp_phone, $notification_id ) );
			}

			return $result;
		}

		if ( isset( $_POST['zwf_nonce_send'] ) && wp_verify_nonce( sanitize_key( $_POST['zwf_nonce_send'] ), 'zwf_nonce_send' ) ) {
			$type_sms       = ( isset( $_POST['SMS'] ) ) ? sanitize_text_field( wp_unslash( $_POST['SMS'] ) ) : '';
			$type_email     = ( isset( $_POST['email'] ) ) ? sanitize_text_field( wp_unslash( $_POST['email'] ) ) : '';
			$type_whatsapp  = ( isset( $_POST['whatsapp'] ) ) ? sanitize_text_field( wp_unslash( $_POST['whatsapp'] ) ) : '';
			$message        = ( isset( $_POST['description'] ) ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
			$subject        = ( isset( $_POST['subject'] ) ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
			$product_values = ( isset( $_POST['product-values'] ) ) ? sanitize_text_field( wp_unslash( $_POST['product-values'] ) ) : '';
			$notification   = ( isset( $_POST['notification'] ) ) ? sanitize_text_field( wp_unslash( $_POST['notification'] ) ) : '';
			$products_info  = $this->get_information_by_product( $product_values );

			$status_send = new ZWORKFLOWMANAGER_Send( 1 );
			foreach ( $status_send->get_notification() as $item ) {
				if ( $item['post_title'] === $notification ) {
					$message_template_id = $item['message_template_id'];

					$template_name  = get_post_meta( $message_template_id, 'zmessagetemplate_name', true );
					$template_lang  = get_post_meta( $message_template_id, 'zmessagetemplate_language', true );
					$whatsapp_phone = ( 'billing' === $order->get_meta( 'zworkflow_select_phone_type' ) ) ? $order->get_meta( 'zworkflow_billing_code' ) . $order->get_billing_phone() : $order->get_meta( 'billing_whatsapp_phone' );
				}
			}

			return $this->send_message_helper( $users, $type_sms, $type_whatsapp, $type_email, $admin_email, $placeholder_arr, $message, $subject, $post_update_id, $products_info, $template_name, $template_lang, $whatsapp_phone );
		}
	}

	/**
	 * Get information by order for send
	 *
	 * @param null|string $order_id order_id.
	 *
	 * @return array
	 */
	public function get_information_by_order( $order_id = null ) {

		if ( is_null( $order_id ) ) {
			return array(
				'order_id'        => '',
				'date'            => '',
				'status'          => '',
				'payment_method'  => '',
				'shipping_method' => '',
				'transaction_id'  => '',
				'billing_name'    => '',
				'billing_email'   => '',
				'order_total'     => '',
				'shipping_total'  => '',
				'tax_total'       => '',
				'site_name'       => get_bloginfo(),
				'site_url'        => get_site_url(),
				'order_status'    => '',
			);
		}

		$order             = wc_get_order( $order_id );
		$order_status_name = wc_get_order_status_name( $order->get_status() );

		$placeholder_arr = array(
			'order_id'        => $order_id,
			'date'            => $order->get_date_created(),
			'status'          => $order_status_name,
			'payment_method'  => $order->get_payment_method(),
			'shipping_method' => $order->get_shipping_method(),
			'transaction_id'  => $order->get_transaction_id(),
			'billing_name'    => $order->get_formatted_billing_full_name(),
			'billing_email'   => $order->get_billing_email(),
			'order_total'     => $order->get_total(),
			'shipping_total'  => $order->get_shipping_total(),
			'tax_total'       => $order->get_total_tax(),
			'site_name'       => get_bloginfo(),
			'site_url'        => get_site_url(),
			'order_status'    => $order_status_name,
		);

		return $placeholder_arr;
	}

	/**
	 * Get information by product for send
	 *
	 * @param string $message message.
	 *
	 * @return array
	 */
	public function get_information_by_product( $message ) {
		$product_ids = array();
		$variant_ids = array();
		$products    = array();
		$replace     = array( '{', '}' );
		$new_str     = str_replace( $replace, '', $message );
		$new_str     = explode( ' ', $new_str );

		foreach ( $new_str as $item ) {
			if ( ! $item ) {
				continue;
			}

			if ( stripos( $item, 'variation' ) !== false ) {
				array_push( $variant_ids, substr( strrchr( $item, '_' ), 1 ) );
			} else {
				array_push( $product_ids, substr( strrchr( $item, '_' ), 1 ) );
			}
		}

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );

			array_push(
				$products,
				array(
					'coupon_' . $product_id => $product_id,
				)
			);

			if ( ! $product ) {
				continue; }

			array_push(
				$products,
				array(
					'product_' . $product_id              => $product->get_name(),
					'product_permalink_' . $product_id    => $product->get_slug(),
					'product_sku_' . $product_id          => $product->get_sku(),
					'product_sale_price_' . $product_id   => $product->get_sale_price(),
					'product_date_on_sale_from_' . $product_id => $product->get_date_on_sale_from(),
					'product_date_on_sale_to_' . $product_id => $product->get_date_on_sale_to(),
					'product_stock_status_' . $product_id => $product->get_stock_status(),
					'product_stock_quantity_' . $product_id => $product->get_stock_quantity(),
					'product_average_rating_' . $product_id => $product->get_average_rating(),
				)
			);
		}

		foreach ( $variant_ids as $variant_id ) {
			$product = new WC_Product_Variation( $variant_id );

			if ( ! $product ) {
				continue; }

			array_push(
				$products,
				array(
					'product_variation_' . $variant_id     => $product->get_name(),
					'product_permalink_variation_' . $variant_id => $product->get_slug(),
					'product_sku_variation_' . $variant_id => $product->get_sku(),
					'product_sale_price_variation_' . $variant_id => $product->get_sale_price(),
					'product_date_on_sale_from_variation_' . $variant_id => $product->get_date_on_sale_from(),
					'product_date_on_sale_to_variation_' . $variant_id => $product->get_date_on_sale_to(),
					'product_stock_status_variation_' . $variant_id => $product->get_stock_status(),
					'product_stock_quantity_variation_' . $variant_id => $product->get_stock_quantity(),
					'product_average_rating_variation_' . $variant_id => $product->get_average_rating(),
				)
			);
		}

		return array_map( 'unserialize', array_unique( array_map( 'serialize', $products ) ) );
	}

	public function extract_product_placeholders( $text ) {
		if ( null === $text ) {
			return '';
		}
		preg_match_all( '/{product_[^}]+}/', $text, $matches );
		return implode( ' ', $matches[0] );
	}

	/**
	 * Replacing tags with real values from the order and sending a letter
	 *
	 * @param string $users users.
	 * @param string $type_sms type_sms.
	 * @param string $type_whatsapp type_whatsapp.
	 * @param string $type_email type_email.
	 * @param string $admin_email admin_email.
	 * @param string $placeholder_arr placeholder_arr.
	 * @param string $message message.
	 * @param null   $subject subject.
	 * @param null   $post_update_id post_update_id.
	 * @param null   $products_info products_info.
	 *
	 * @return string[]
	 */
	public function send_message_helper(
		$users, $type_sms, $type_whatsapp, $type_email, $admin_email, $placeholder_arr, $message, $subject = null, $post_update_id = null, $products_info = null, $template_name = null, $template_lang = null, $whatsapp_phone = null, $notification_id = null
		) {
		if ( get_option( 'zworkflowmanager_backward' ) ) {
			if ( isset( $post_update_id ) && is_numeric( $post_update_id ) ) {
				update_post_meta( $post_update_id, 'error_logs', 'Update is required to the new templates. Notifications paused until templates are created.' );
				$this->status_post_update( $post_update_id, false, false, false, false );

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( 'Update is required to the new templates. Notifications paused until templates are created.' );
			}
			return;
		}

		$settings_status     = new ZWORKFLOWMANAGER_Settings();
		$schedule_time_frame = new ZWORKFLOWMANAGER_Schedule_Time_Frame();
		$settings            = $settings_status->get_settings();
		$on_hold_check       = false;
		$text_message        = $message;
		$parameters          = array();

		$product_placeholders = $this->extract_product_placeholders( $text_message );

		if ( ! empty( $product_placeholders ) ) {
			$product_values = $this->get_information_by_product( $product_placeholders );
		}

		if ( isset( $message ) ) {
			foreach ( $placeholder_arr as $key => $value ) {
					$message = str_replace( '{' . $key . '}', $value, $message );

				if ( $type_whatsapp && strpos( $text_message, '{' . $key . '}' ) !== false ) {
					$item         = array(
						'type' => 'text',
						'text' => ( $value ) ? $value : 'n/a',
					);
					$parameters[] = $item;
				}
			}
		}

		if ( $products_info ) {
			foreach ( $products_info as $product ) {
				foreach ( $product as $key => $value ) {
					$message = str_replace( '{' . $key . '}', $value, $message );
					if ( $type_whatsapp && strpos( $text_message, '{' . $key . '}' ) !== false ) {
						$item         = array(
							'type' => 'text',
							'text' => ( $value ) ? $value : 'n/a',
						);
						$parameters[] = $item;
					}
				}
			}
		}

		if ( isset( $product_values ) ) {
			foreach ( $product_values as $product ) {
				foreach ( $product as $key => $value ) {
					$message = str_replace( '{' . $key . '}', $value, $message );
					if ( $type_whatsapp && strpos( $text_message, '{' . $key . '}' ) !== false ) {
						$item         = array(
							'type' => 'text',
							'text' => ( $value ) ? $value : 'n/a',
						);
						$parameters[] = $item;
					}
				}
			}
		}

		foreach ( $users as $user ) {
			$phone = null;
			$email = null;
			if ( ! is_array( $user ) ) {
				$phone = explode( ',', $user )[1];
			} else {
				$phone = $user['billing_phone'];
			}

			if ( ! is_array( $user ) ) {
				$email = explode( ',', $user )[0];
			} else {
				$email = $user['user_email'];
			}

			if ( $type_whatsapp && ! $whatsapp_phone && isset( $user['whatsapp_code'] ) && isset( $user['whatsapp_phone'] ) ) {
				$whatsapp_phone = $user['whatsapp_code'] . $user['whatsapp_phone'];
			}

			$sms_send      = false;
			$email_send    = false;
			$whatsapp_send = false;

			if ( $type_sms ) {
				$timing_settings = get_post_meta( $notification_id, 'zcustomemail_timing_settings', true );
				if ( $timing_settings ) { // if this notification has timing settings
					$timing_schedule   = new ZWORKFLOWMANAGER_Timing_Schedule( $notification_id, $timing_settings['timing_type'], 'sms' );
					$send_now_possible = $timing_schedule->is_send_now_possible();

					if ( $send_now_possible ) {
						$result   = $this->twilio_sending_sms_to_customer( $phone, $message );
						$sms_send = isset( $result['success'] );
						if ( isset( $result['error'] ) ) {
							update_post_meta( $post_update_id, 'error_logs', $result['error'] );
							$logger = new ZWORKFLOWMANAGER_Logger();
							$logger->log( $result['error'] );
						}
					} else {
						$result        = $timing_schedule->send_message_by_scheduled( $phone, $message, $post_update_id );
						$on_hold_check = true;
					}
				} else {
					if ( ! is_null( $settings['communication_methods_schedule_sms'] ) && ! $schedule_time_frame->check_schedule_time_frame() ) {
						$schedule_time_frame->save_sms_delayed_send( $phone, $message, $post_update_id );
						$on_hold_check = true;
					} else {
						$result   = $this->twilio_sending_sms_to_customer( $phone, $message );
						$sms_send = isset( $result['success'] );
						if ( isset( $result['error'] ) ) {
							update_post_meta( $post_update_id, 'error_logs', $result['error'] );
							$logger = new ZWORKFLOWMANAGER_Logger();
							$logger->log( $result['error'] );
						}
					}
				}
			}

			if ( $type_whatsapp ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
				}
				$whatsapp        = new ZWORKFLOWMANAGER_Whatsapp();
				$timing_settings = get_post_meta( $post_update_id, 'zcustomemail_timing_settings', true );
				$whatsapp_phone  = str_replace( '+', '', $whatsapp_phone );

				if ( $timing_settings ) {
					$timing_schedule   = new ZWORKFLOWMANAGER_Timing_Schedule( $notification_id, $timing_settings['timing_type'], 'whatsapp' );
					$send_now_possible = $timing_schedule->is_send_now_possible();

					if ( $send_now_possible ) {
						$result        = $whatsapp->send_message( $whatsapp_phone, $template_name, $template_lang, $parameters );
						$whatsapp_send = isset( $result['success'] );
						if ( isset( $result['error'] ) ) {
							update_post_meta( $post_update_id, 'error_logs', $result['error'] );
							$logger = new ZWORKFLOWMANAGER_Logger();
							$logger->log( $result['error'] );
						}
					} else {
						$result        = $timing_schedule->send_whatsapp_message_by_scheduled( $whatsapp_phone, $template_name, $template_lang, $parameters, $post_update_id );
						$on_hold_check = true;
					}
				} else {
					if ( ! is_null( $settings['communication_methods_schedule_wa'] ) && ! $schedule_time_frame->check_schedule_time_frame() ) {
						$whatsapp->send_message( $whatsapp_phone, $template_name, $template_lang, $parameters );
						$on_hold_check = true;
					} else {
						$result        = $whatsapp->send_message( $whatsapp_phone, $template_name, $template_lang, $parameters );
						$whatsapp_send = isset( $result['success'] );
						if ( isset( $result['error'] ) ) {
							update_post_meta( $post_update_id, 'error_logs', $result['error'] );
							$logger = new ZWORKFLOWMANAGER_Logger();
							$logger->log( $result['error'] );
						}
					}
				}
			}

			if ( $type_email ) {
				$timing_settings = get_post_meta( $notification_id, 'zcustomemail_timing_settings', true );
				if ( $timing_settings ) { // if this notification has timing settings
					$timing_schedule   = new ZWORKFLOWMANAGER_Timing_Schedule( $notification_id, $timing_settings['timing_type'], 'email' );
					$send_now_possible = $timing_schedule->is_send_now_possible();

					if ( $send_now_possible ) {
						$result     = $this->email_send_helper( $email, $subject, $admin_email, $message );
						$email_send = isset( $result['success'] );
						if ( isset( $result['error'] ) ) {
							update_post_meta( $post_update_id, 'error_logs', $result['error'] );
							$logger = new ZWORKFLOWMANAGER_Logger();
							$logger->log( $result['error'] );
						}
					} else {
						$result        = $timing_schedule->send_email_by_scheduled( $email, $subject, $admin_email, $post_update_id );
						$on_hold_check = true;
					}
				} else {
					if ( ! is_null( $settings['communication_methods_schedule_email'] ) && ! $schedule_time_frame->check_schedule_time_frame() ) {
						$schedule_time_frame->save_email_delayed_send( $email, $subject, $admin_email, $post_update_id, $message );
						$on_hold_check = true;
					} else {
						$result     = $this->email_send_helper( $email, $subject, $admin_email, $message );
						$email_send = $result;
					}
				}
			}

			if ( isset( $post_update_id ) && is_numeric( $post_update_id ) ) {
				$this->status_post_update( $post_update_id, $email_send, $whatsapp_send, $sms_send, $on_hold_check );
			}
		}

		return $result;
	}

	/**
	 * Twilio Sending SMS to Customer
	 *
	 * @param null    $phone phone.
	 * @param string  $message message.
	 * @param boolean $test - Use this parameter if you want to check connection to Twilio service.
	 *
	 * @return string[]
	 */
	public function twilio_sending_sms_to_customer( $phone = null, $message = 'Test SMS', $test = false ) {
		try {
			$curl = curl_init();

			/* Getting saved Twilio connection settings */
			$twilio_settings  = get_option( 'twilio_settings' );
			$connection_check = get_option( 'twilio_connection' );

			/* Set connection in "true" for testing and check "connection status" for real requests */
			$connection_check = ( $test ) ? true : $connection_check;

			/* Send error message if we can't send SMS */
			if ( ! isset( $twilio_settings ) || empty( $twilio_settings ) || ! $connection_check ) {
				return array( 'error' => "Connection to Twilio service can't be established. <br> Not all required data is present." );
			}

			$account_sid        = $twilio_settings['account_credentials'] ? $twilio_settings['account_sid'] : $twilio_settings['account_sid_test'];
			$auth_token         = $twilio_settings['account_credentials'] ? $twilio_settings['auth_token'] : $twilio_settings['auth_token_test'];
			$user_account_phone = $twilio_settings['account_credentials'] ? $twilio_settings['from_number'] : $twilio_settings['from_number_test'];
			$phone              = ( ! is_null( $phone ) ) ? $phone : ( $twilio_settings['account_credentials'] ? $twilio_settings['to_number'] : $twilio_settings['to_number_test'] );
			$status_sender_id   = $twilio_settings['status_sender_id'];
			$sender_id          = $twilio_settings['sender_id'];
			$basic_auth         = base64_encode( $account_sid . ':' . $auth_token );
			$message            = str_replace( '&#39;', '\'', $message );
			$message            = str_replace( '&#34;', '"', $message );
			$from               = is_null( $status_sender_id ) ? $user_account_phone : $sender_id;

			/* Return error if phone doesn't provided */
			if ( is_null( $phone ) ) {
				return array( 'error' => 'Phone number wasn\'t provided' );
			}

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL            => "https://api.twilio.com/2010-04-01/Accounts/$account_sid/Messages.json",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING       => '',
					CURLOPT_MAXREDIRS      => 10,
					CURLOPT_TIMEOUT        => 30,
					CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST  => 'POST',
					CURLOPT_POSTFIELDS     => "From=$from&To=$phone&Body=$message",
					CURLOPT_HTTPHEADER     => array(
						"Authorization: Basic $basic_auth",
						'Content-Type : application/x-www-form-urlencoded',
					),
				)
			);

			$response         = curl_exec( $curl );
			$err              = curl_error( $curl );
			$decoded_response = json_decode( $response );

			curl_close( $curl );

			if ( $err ) {
				return array( 'error' => 'cURL Error #:' . $err );
			}

			if ( $decoded_response->code ) {
				return array( 'error' => 'Code:' . $decoded_response->code . ' - ' . $decoded_response->message );
			}

			return array( 'success' => 'SMS was successfully sent' );
		} catch ( Exception $e ) {
			return array( 'error' => 'Exception : ' . $e->getMessage() );
		}
	}

	/**
	 * Sending email from admin functionality
	 *
	 * @param string $email email.
	 * @param string $subject subject.
	 * @param string $admin_email admin_email.
	 *
	 * @return bool|mixed|void
	 */
	public function email_send_helper( $email, $subject, $admin_email, $message ) {
		$email_settings = get_option( 'notification_email_settings' );
		$from_email     = ( $email_settings['address'] ) ? $email_settings['address'] : $admin_email;
		$name           = ( $email_settings['name'] ) ? $email_settings['name'] : '';
		$headers        = array(
			'From: ' . $name . ' <' . $from_email . '>',
			'content-type: text/html',
		);
		ob_start();
		require ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/templates/plain/email-form.php';
		$msg = ob_get_clean();
		$msg = str_replace( '&#39;', '\'', $msg );
		$msg = str_replace( '&#34;', '"', $msg );

		return wp_mail( $email, $subject, $msg, $headers );
	}

	/**
	 *
	 * Updated meta_value status notice
	 *
	 * @param string $post_update_id post_update_id.
	 * @param string $email_send email_send.
	 * @param string $whatsapp_send whatsapp_send.
	 * @param string $sms_send sms_send.
	 * @param string $on_hold_check on_hold_check.
	 *
	 * @return void
	 */
	public function status_post_update( $post_update_id, $email_send, $whatsapp_send, $sms_send, $on_hold_check ) {

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		$send_status = new ZWORKFLOWMANAGER_Send( $post_update_id );

		if ( $email_send || $whatsapp_send || $sms_send ) {
			$send_status->set_data( 'send_status', 'Success' );
		} elseif ( $on_hold_check ) {
			$send_status->set_data( 'send_status', 'On hold' );
		} else {
			$send_status->set_data( 'send_status', 'Failed' );
		}

	}

	/**
	 * Unsubscribe to newsletter
	 */
	public function unsubscribe_to_newsletter() {
		if ( ! isset( $_POST['zwf_notify_in_product'] ) && ! wp_verify_nonce( sanitize_key( $_POST['zwf_notify_in_product'] ), 'zwf_notify_in_product' ) ) {
			return;
		}
		$product_id                     = ( isset( $_POST['product_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['product_id'] ) ) : '';
		$subscribe_to_newsletter        = get_post_meta( $product_id, 'subscribe_to_newsletter' )[0];
		$subscribe_to_newsletter_option = get_option( 'subscribe_to_newsletter' );
		$user_id                        = get_current_user_id();
		$user                           = get_userdata( $user_id );
		$get_cookie                     = isset( $_COOKIE['Subscribed'] )
			? json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['Subscribed'] ) ) ), true ) : array();

		if ( is_user_logged_in() ) {
			$user_email = $user->user_email;

			foreach ( $subscribe_to_newsletter as $key => $item ) {
				$check = in_array( $user_email, $item, true );
				if ( ! $check ) {
					continue;
				}
				unset( $subscribe_to_newsletter[ $key ] );
			}

			foreach ( $subscribe_to_newsletter_option as $key => $item ) {

				if ( isset( $_REQUEST['product_url'] ) && isset( $item['url'] ) && ! strripos( sanitize_text_field( wp_unslash( $_REQUEST['product_url'] ) ), $item['url'] ) ) {
					continue;}
				unset( $subscribe_to_newsletter_option[ $key ] );
			}
			update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );

			update_post_meta( $product_id, 'subscribe_to_newsletter', $subscribe_to_newsletter );
		} else {
			$product     = wc_get_product( $product_id );
			$product_url = $product->get_permalink();
			$product_url = str_replace( get_site_url(), '', htmlspecialchars( sanitize_text_field( wp_unslash( $product_url ) ) ) );
			foreach ( $get_cookie as $c_key => $cookie ) {
				$check_email = preg_match( '/^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/', $cookie['contacts'] );
				$check_phone = preg_match( '/^[0-9\+]{11,15}$/', $cookie['contacts'] );
				$user_email  = ( $check_email ) ? $cookie['contacts'] : '';
				$user_phone  = ( $check_phone ) ? $cookie['contacts'] : '';

				$type = $user_email ? 'email' : 'sms';

				$this->guest_opted_out( $user_email, $user_phone, $type );

				foreach ( $subscribe_to_newsletter_option as $key => $item ) {
					if ( $product_url !== $item['url'] ) {
						continue;}
					unset( $subscribe_to_newsletter_option[ $key ] );
				}

				if ( $product_url !== $cookie['url'] ) {
					continue;}

				unset( $get_cookie[ $c_key ] );
			}

			update_option( 'subscribe_to_newsletter', $subscribe_to_newsletter_option );
			setcookie( 'Subscribed', wp_json_encode( $get_cookie ), strtotime( '+1 year' ), '/' );
		}
		wp_send_json_success();

		exit;

	}

	/**
	 * Guest opt-out
	 *
	 * @param string $email email.
	 * @param string $phone phone.
	 * @param string $communication_preference communication_preference.
	 *
	 * @return array|string[]
	 */
	public function guest_opted_out( $email, $phone, $communication_preference ) {

		$data  = array();
		$users = array( $email . ',' . $phone );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_opted_out',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $communication_preference || 'sms' === $communication_preference )
							? $communication_preference : '',
						'email'           => ( 'email' === $communication_preference ) ? $communication_preference : '',
						'whatsapp'        => ( 'whatsapp' === $communication_preference ) ? $communication_preference : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $communication_preference,
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $users, null, $data, null );
	}

	/**
	 * Update flow notify fields in product tab
	 *
	 * @param string $product_id product_id.
	 */
	public function on_product_save( $product_id ) {
		$on_sale                 = get_post_meta( $product_id, 'on_sale_notification_field', true );
		$_on_sale                = get_post_meta( $product_id, '_on_sale_select', true );
		$_sale_price             = filter_input( INPUT_POST, '_sale_price', FILTER_SANITIZE_STRING );
		$subscribe_to_newsletter = get_post_meta( $product_id, 'subscribe_to_newsletter' );
		$global_subscriber       = get_option( 'global_subscribe_notification' );

		$user_id               = get_current_user_id();
		$all_notifications     = get_user_meta( $user_id, 'all_notifications', true );
		$product_notifications = get_user_meta( $user_id, 'product_notifications', true );

		$fields_checkbox_arr = array(
			'out_of_stock_notification_field',
			'in_stock_notification_field',
			'on_sale_notification_field',
			'enable_notifications_for_variations',
		);

		$fields_select_arr = array(
			'_out_of_stock_select',
			'_in_stock_select',
			'_on_sale_select',
		);

		/* update checkbox value */
		foreach ( $fields_checkbox_arr as $item ) {
			$option = filter_input( INPUT_POST, $item, FILTER_SANITIZE_STRING ) ? 'yes' : 'no';
			update_post_meta( $product_id, $item, esc_attr( $option ) );
		}

		/* update select value */
		foreach ( $fields_select_arr as $item ) {
			$option = filter_input( INPUT_POST, $item, FILTER_SANITIZE_STRING );
			update_post_meta( $product_id, $item, $option );
		}

		/* update sale_price value */
		update_post_meta( $product_id, '_sale_price', $option );

		/* if the product is on_sale, then we send a message to customers */
		if ( is_user_logged_in() && ! is_null( $product_notifications ) && $_sale_price && 'yes' === $on_sale ) {
			$this->send_notify_to_subscribers( $_on_sale, $subscribe_to_newsletter[0] );
		}
		if ( ! is_user_logged_in() && $_sale_price && 'yes' === $on_sale ) {
			$this->send_notify_to_subscribers( $_on_sale, $subscribe_to_newsletter[0] );
		}

		/* if the product is on_sale, then we send a message to global subscribers */
		if ( is_user_logged_in() && ! is_null( $all_notifications ) && $_sale_price && 'yes' === $on_sale && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_on_sale, $global_subscriber );
		}
		if ( ! is_user_logged_in() && $_sale_price && 'yes' === $on_sale && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_on_sale, $global_subscriber );
		}
	}

	public function custom_variation_fields( $loop, $variation_data, $variation ) {
		$post_pparent_id      = $variation->post_parent;
		$enable_notifications = get_post_meta( $post_pparent_id, 'enable_notifications_for_variations', true );
		if ( 'no' === $enable_notifications ) {
			return; }

		$out_of_stock_notification_field = get_post_meta( $variation->ID, 'out_of_stock_notification_field', true );
		$in_stock_notification_field     = get_post_meta( $variation->ID, 'in_stock_notification_field', true );
		$on_sale_notification_field      = get_post_meta( $variation->ID, 'on_sale_notification_field', true );
		$_out_of_stock                   = get_post_meta( $variation->ID, '_out_of_stock_select', true );
		$_in_stock                       = get_post_meta( $variation->ID, '_in_stock_select', true );
		$_on_sale                        = get_post_meta( $variation->ID, '_on_sale_select', true );
		$status_send                     = new ZWORKFLOWMANAGER_Send( 0 );
		$notification_arr['']            = __( 'None', 'flow_notify_text' );
		$notification                    = $status_send->get_notification();

		foreach ( $notification as $item ) {
			$post_title                      = $item['post_title'];
			$notification_arr[ $post_title ] = $post_title;
		}

		$nonce = wp_create_nonce( 'save_custom_variation_fields' );
		?>
		<div id="flow_notify_variation_data">
		<input type="hidden" name="nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<?php

			woocommerce_wp_checkbox(
				array(
					'id'            => 'out_of_stock_notification_field[' . $loop . ']',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'Out of Stock Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
					'value'         => $out_of_stock_notification_field,
				)
			);

			woocommerce_wp_select(
				array(
					'id'       => '_out_of_stock_select[' . $loop . ']',
					'desc_tip' => false,
					'style'    => '',
					'label'    => false,
					'value'    => $_out_of_stock,
					'options'  => $notification_arr,
				)
			);

			woocommerce_wp_checkbox(
				array(
					'id'            => 'in_stock_notification_field[' . $loop . ']',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'In Stock Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
					'value'         => $in_stock_notification_field,
				)
			);
			woocommerce_wp_select(
				array(
					'id'       => '_in_stock_select[' . $loop . ']',
					'desc_tip' => false,
					'style'    => '',
					'label'    => false,
					'value'    => $_in_stock,
					'options'  => $notification_arr,
				)
			);

			woocommerce_wp_checkbox(
				array(
					'id'            => 'on_sale_notification_field[' . $loop . ']',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'On Sale Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
					'value'         => $on_sale_notification_field,
				)
			);
			woocommerce_wp_select(
				array(
					'id'       => '_on_sale_select[' . $loop . ']',
					'desc_tip' => false,
					'style'    => '',
					'label'    => false,
					'value'    => $_on_sale,
					'options'  => $notification_arr,
				)
			);
		?>
			</div>
			<?php
	}

	public function variations_save_fields( $variation_id, $loop ) {

		if ( isset( $_POST['nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['nonce'] ), 'save_custom_variation_fields' ) ) {

			if ( isset( $_POST['out_of_stock_notification_field'][ $loop ] ) ) {
				update_post_meta( $variation_id, 'out_of_stock_notification_field', 'yes' );
			} else {
				update_post_meta( $variation_id, 'out_of_stock_notification_field', 'no' );
			}

			if ( isset( $_POST['in_stock_notification_field'][ $loop ] ) ) {
				update_post_meta( $variation_id, 'in_stock_notification_field', 'yes' );
			} else {
				update_post_meta( $variation_id, 'in_stock_notification_field', 'no' );
			}

			if ( isset( $_POST['on_sale_notification_field'][ $loop ] ) ) {
				update_post_meta( $variation_id, 'on_sale_notification_field', 'yes' );
			} else {
				update_post_meta( $variation_id, 'on_sale_notification_field', 'no' );
			}

			if ( isset( $_POST['_out_of_stock_select'][ $loop ] ) ) {
				update_post_meta( $variation_id, '_out_of_stock_select', sanitize_text_field( wp_unslash( $_POST['_out_of_stock_select'][ $loop ] ) ) );
			} else {
				delete_post_meta( $variation_id, '_out_of_stock_select' );
			}

			if ( isset( $_POST['_in_stock_select'][ $loop ] ) ) {
				update_post_meta( $variation_id, '_in_stock_select', sanitize_text_field( wp_unslash( $_POST['_in_stock_select'][ $loop ] ) ) );
			} else {
				delete_post_meta( $variation_id, '_in_stock_select' );
			}

			if ( isset( $_POST['_on_sale_select'][ $loop ] ) ) {
				update_post_meta( $variation_id, '_on_sale_select', sanitize_text_field( wp_unslash( $_POST['_on_sale_select'][ $loop ] ) ) );
			} else {
				delete_post_meta( $variation_id, '_on_sale_select' );
			}
		}

	}

	/**
	 * Send notify to subscribers
	 *
	 * @param string $post_name post_name.
	 * @param string $users users.
	 *
	 * @return array|string[]
	 */
	public function send_notify_to_subscribers( $post_name, $users ) {
		global $post;
		$data = array();

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				if ( '' === $post_name ) {
					return $data;
				}
				if ( $post_name && $current_post->post_title !== $post_name ) {
					continue;
				}
				$zsending_type       = get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id = get_post_meta( $current_post->ID, 'message_template_id', true );
				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),

					)
				);
			}
		}
		/* Restore original Post Data */
		wp_reset_postdata();
		return $this->send_from_admin( $users, null, $data, null, null );
	}

	/**
	 * Change stock of product
	 *
	 * @param object $product product.
	 */
	public function stock_changed( $product ) {
		$stock_quantity          = $product->stock_quantity;
		$global_subscriber       = get_option( 'global_subscribe_notification' );
		$subscribe_to_newsletter = get_post_meta( $product->get_id(), 'subscribe_to_newsletter', true );
		$in_stock                = get_post_meta( $product->get_id(), 'in_stock_notification_field', true );
		$out_of_stock            = get_post_meta( $product->get_id(), 'out_of_stock_notification_field', true );
		$_out_of_stock           = get_post_meta( $product->get_id(), '_out_of_stock_select', true );
		$_in_stock               = get_post_meta( $product->get_id(), '_in_stock_select', true );

		$user_id               = get_current_user_id();
		$all_notifications     = get_user_meta( $user_id, 'all_notifications' )[0];
		$product_notifications = get_user_meta( $user_id, 'product_notifications' )[0];

		/* if the product is in_stock, then we send a message to customers */
		if ( is_user_logged_in() && ! is_null( $product_notifications ) && $stock_quantity && 'yes' === $in_stock ) {
			$this->send_notify_to_subscribers( $_in_stock, $subscribe_to_newsletter );
		}
		if ( ! is_user_logged_in() && $stock_quantity && 'yes' === $in_stock ) {
			$this->send_notify_to_subscribers( $_in_stock, $subscribe_to_newsletter );
		}

		/* if the product is out_of_stock, then we send a message to customers */
		if ( is_user_logged_in() && ! is_null( $product_notifications ) && ! $stock_quantity && 'yes' === $out_of_stock ) {
			$this->send_notify_to_subscribers( $_out_of_stock, $subscribe_to_newsletter );
		}
		if ( ! is_user_logged_in() && ! $stock_quantity && 'yes' === $out_of_stock ) {
			$this->send_notify_to_subscribers( $_out_of_stock, $subscribe_to_newsletter );
		}

		/* if the product is out_of_stock, then we send a message to global subscribers */
		if ( is_user_logged_in() && ! is_null( $all_notifications ) && ! $stock_quantity && 'yes' === $out_of_stock && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_out_of_stock, $global_subscriber );
		}
		if ( ! is_user_logged_in() && ! $stock_quantity && 'yes' === $out_of_stock && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_out_of_stock, $global_subscriber );
		}

		/* if the product is in_stock, then we send a message to global subscribers */
		if ( is_user_logged_in() && ! is_null( $all_notifications ) && $stock_quantity && 'yes' === $in_stock && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_in_stock, $global_subscriber );
		}
		if ( ! is_user_logged_in() && $stock_quantity && 'yes' === $in_stock && $global_subscriber ) {
			$this->send_notify_to_subscribers( $_in_stock, $global_subscriber );
		}
	}

	/**
	 * Add custom product_data tab
	 *
	 * @param array $product_data_tabs product_data_tabs.
	 *
	 * @return mixed
	 */
	public function add_my_custom_product_data_tab( $product_data_tabs ) {
		$product_data_tabs['flow_notify'] = array(
			'label'  => __( 'Flow Notify', 'flow_notify_text' ),
			'target' => 'flow_notify_product_data',
		);

		return $product_data_tabs;
	}

	/**
	 * Add custom product_data fields
	 */
	public function add_my_custom_product_data_fields() {
		global $post;
		$_out_of_stock        = get_post_meta( $post->ID, '_out_of_stock_select', true );
		$_in_stock            = get_post_meta( $post->ID, '_in_stock_select', true );
		$_on_sale             = get_post_meta( $post->ID, '_on_sale_select', true );
		$status_send          = new ZWORKFLOWMANAGER_Send( 0 );
		$notification_arr[''] = __( 'None', 'flow_notify_text' );
		$notification         = $status_send->get_notification();

		foreach ( $notification as $item ) {
			$post_title                      = $item['post_title'];
			$notification_arr[ $post_title ] = $post_title;
		}
		?>

		<div id="flow_notify_product_data" class="panel woocommerce_options_panel hidden">
			<?php

			woocommerce_wp_checkbox(
				array(
					'id'            => 'enable_notifications_for_variations',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'Enable notifications to all variations', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
				)
			);

			echo '<p class="empty-field"></p>';

			woocommerce_wp_checkbox(
				array(
					'id'            => 'out_of_stock_notification_field',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'Out of Stock Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
				)
			);

			woocommerce_wp_select(
				array(
					'id'       => '_out_of_stock_select',
					'desc_tip' => false,
					'style'    => '',
					'value'    => $_out_of_stock,
					'options'  => $notification_arr,
				)
			);

			woocommerce_wp_checkbox(
				array(
					'id'            => 'in_stock_notification_field',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'In Stock Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
				)
			);
			woocommerce_wp_select(
				array(
					'id'       => '_in_stock_select',
					'desc_tip' => false,
					'style'    => '',
					'value'    => $_in_stock,
					'options'  => $notification_arr,
				)
			);

			woocommerce_wp_checkbox(
				array(
					'id'            => 'on_sale_notification_field',
					'wrapper_class' => false,
					'label'         => false,
					'description'   => __( 'On Sale Notification', 'flow_notify_text' ),
					'default'       => '0',
					'desc_tip'      => false,
				)
			);
			woocommerce_wp_select(
				array(
					'id'       => '_on_sale_select',
					'desc_tip' => false,
					'style'    => '',
					'value'    => $_on_sale,
					'options'  => $notification_arr,
				)
			);
			?>
		</div>
		<?php
	}

	/**
	 * Workflow change order status
	 */
	public function workflow_change_order_status() {
		if ( current_user_can( 'edit_shop_orders' ) ) {
			$status = filter_input( INPUT_GET, 'status', FILTER_SANITIZE_STRING );
			$order  = filter_input( INPUT_GET, 'order_id', FILTER_SANITIZE_STRING );

			$current_status = $order->get_status();

			if ( wc_is_order_status( 'wc-' . $status ) && $order ) {
				// Initialize payment gateways in case order has hooked status transition actions.
				$order->update_status( $status );

				if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email_Manager' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-status-email-manager.php';
				}

				if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
				}

				$manager       = new ZWORKFLOWMANAGER_Status_Email_Manager();
				$custom_emails = $manager->get_by_from_and_to_status( $current_status, $status );

				if ( count( $custom_emails ) !== 0 ) {
					$mailer = WC()->mailer();
					$mails  = $mailer->get_emails();
					if ( ! empty( $mails ) ) {
						foreach ( $mails as $mail ) {
							foreach ( $custom_emails as $custom_email ) {
								if ( 'wc_' . $custom_email->get_slug() === $mail->id ) {
									$mail->trigger( $order->get_id() );
								}
							}
						}
					}
				}
			}
		}

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php?post_type=shop_order' ) );
		exit;
	}

	/**
	 * Reassign orders statuses
	 */
	public function reassign_orders_statuses() {

		if ( ! isset( $_POST['zwf_order_status'] ) || ! wp_verify_nonce( sanitize_key( $_POST['zwf_order_status'] ), 'zwf_order_status-process_checkout' ) ) {
			return;
		}

		$order_status_id = ( isset( $_POST['order_status_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['order_status_id'] ) ) : '';
		$new_slug        = ( isset( $_POST['slug'] ) ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';
		$next_slug       = substr( $new_slug, 3 );
		$order_status    = new ZWORKFLOWMANAGER_Order_Status( $order_status_id );
		$current_slug    = $order_status->get_slug();

		if ( isset( $current_slug ) ) {

			$orders = wc_get_orders(
				array(
					'posts_per_page' => - 1,
					'post_status'    => $current_slug,
				)
			);

			$i = 0;
			foreach ( $orders as $order ) {
				$order->update_status( $next_slug, 'Order status changed to ' . $order_status->get_status_title( $new_slug ) . ' from ' . $order_status->get_status_title( $current_slug ) . ' because the ' . $order_status->get_status_title( $current_slug ) . ' status was deleted.' );
				$i ++;
			}

			$to   = $order_status->get_status_title( $new_slug );
			$from = $order_status->get_status_title( $current_slug );

			wp_delete_post( $order_status_id, true );

			wp_send_json_success( admin_url( 'admin.php?page=wc-workflows&tab=order_status' ) . '&notification=status_deleted&number=' . $i . '&from=' . $from . '&to=' . $to );
			exit;
		}
	}

	/**
	 * Delete order status directly
	 */
	public function delete_order_status_directly() {
		$order_status_id = filter_input( INPUT_POST, 'order_status_id', FILTER_SANITIZE_NUMBER_INT );
		$order_status    = new ZWORKFLOWMANAGER_Order_Status( $order_status_id );
		$current_slug    = $order_status->get_slug();

		if ( isset( $current_slug ) ) {
			$orders = wc_get_orders(
				array(
					'posts_per_page' => - 1,
					'post_status'    => $current_slug,
				)
			);

			$i = 0;
			foreach ( $orders as $order ) {
				$order->update_status( 'on-hold', 'Order status changed to On hold from ' . $order_status->get_status_title( $current_slug ) . ' because the ' . $order_status->get_status_title( $current_slug ) . ' status was deleted.' );
				$i ++;
			}

			$to   = 'On hold';
			$from = $order_status->get_status_title( $current_slug );

			wp_delete_post( $order_status_id, true );

			wp_send_json_success( admin_url( 'admin.php?page=wc-workflows&tab=order_status' ) . '&notification=status_deleted&number=' . $i . '&from=' . $from . '&to=' . $to );
			exit;
		}
	}

	/**
	 * Select notification type
	 */
	public function select_notification_type() {
		$status_send = new ZWORKFLOWMANAGER_Send( 1 );
		$name        = filter_input( INPUT_POST, 'name', FILTER_SANITIZE_STRING );
		$response    = array();
		foreach ( $status_send->get_notification() as $item ) {
			if ( $item['post_title'] === $name ) {
				$template_description = get_post_meta( $item['message_template_id'], 'zmessagetemplate_description', true );
				$message_template_id  = get_post_meta( $item['notification_id'], 'message_template_id', true );

				$response = array( $item['zsending_type'], $template_description, $message_template_id );
			}
		}
		wp_send_json_success( $response );
		exit;
	}

	/**
	 * Change custom email status
	 */
	public function change_custom_email_status() {
		$email_id = filter_input( INPUT_POST, 'email_id', FILTER_SANITIZE_NUMBER_INT );
		$checked  = filter_input( INPUT_POST, 'checked', FILTER_SANITIZE_STRING );

		if ( ! isset( $email_id ) ) {
			return;
		}

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
		}

		$custom_email = new ZWORKFLOWMANAGER_Status_Email( $email_id );

		if ( isset( $checked ) && 'checked' === $checked ) {
			$custom_email->set_status( 'enabled' );
		} else {
			$custom_email->set_status( 'disabled' );
		}

	}

	/**
	 * Change message template status
	 */
	public function change_message_template_status() {
		$message_template_id = filter_input( INPUT_POST, 'message_template_id', FILTER_SANITIZE_NUMBER_INT );
		$checked             = filter_input( INPUT_POST, 'checked', FILTER_SANITIZE_STRING );

		if ( ! isset( $message_template_id ) ) {
			return;
		}

		if ( isset( $checked ) && 'checked' === $checked ) {
			update_post_meta( $message_template_id, 'zmessagetemplate_status', 'enabled' );
		} else {
			update_post_meta( $message_template_id, 'zmessagetemplate_status', 'disabled' );
		}

	}

	/**
	 * Add order column header
	 *
	 * @param array $columns columns.
	 *
	 * @return array
	 */
	public function add_order_column_header( $columns ) {
		$new_columns = array();

		foreach ( $columns as $column_name => $column_info ) {
			if ( 'order_status' === $column_name ) {
				$new_columns['custom_order_status'] = __( 'Status', 'flow_notify_text' );
			} else {
				$new_columns[ $column_name ] = $column_info;
			}
		}

		return $new_columns;
	}

	/**
	 * Order status column display
	 *
	 * @param string $column column name.
	 */
	public function order_status_column_display( $column ) {
		global $post;

		if ( 'custom_order_status' === $column ) {
			if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
				require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
			}

			$order            = wc_get_order( $post->ID );
			$custom_status    = new ZWORKFLOWMANAGER_Order_Status( 'wc-' . $order->get_status() );
			$text_color       = $custom_status->get_text_color();
			$background_color = $custom_status->get_background_color();

			$tooltip                 = '';
			$comment_count           = get_comment_count( $order->get_id() );
			$approved_comments_count = absint( $comment_count['approved'] );

			if ( $approved_comments_count ) {
				$latest_notes = wc_get_order_notes(
					array(
						'order_id' => $order->get_id(),
						'limit'    => 1,
						'orderby'  => 'date_created_gmt',
					)
				);

				$latest_note = current( $latest_notes );

				if ( isset( $latest_note->content ) && 1 === $approved_comments_count ) {
					$tooltip = wc_sanitize_tooltip( $latest_note->content );
				} elseif ( isset( $latest_note->content ) ) {
					/* translators: %d: notes count */
					$tooltip = wc_sanitize_tooltip( $latest_note->content . '<br/><small style="display:block">' . sprintf( _n( 'Plus %d other note', 'Plus %d other notes', ( $approved_comments_count - 1 ), 'flow_notify_text' ), $approved_comments_count - 1 ) . '</small>' );
				} else {
					/* translators: %d: notes count */
					$tooltip = wc_sanitize_tooltip( sprintf( _n( '%d note', '%d notes', $approved_comments_count, 'flow_notify_text' ), $approved_comments_count ) );
				}
			}

			if ( $tooltip ) {
				printf( '<span class="zworkflowmanager_label %s tips" style="color:%s; background-color:%s" data-tip="%s"><span>%s</span></span>', esc_attr( sanitize_html_class( 'status-' . $order->get_status() ) ), esc_attr( $text_color ), esc_attr( $background_color ), wp_kses_post( $tooltip ), esc_textarea( wc_get_order_status_name( $order->get_status() ) ) );
			} else {
				printf( '<span class="zworkflowmanager_label %s" style="color:%s; background-color:%s"><span>%s</span></span>', esc_attr( sanitize_html_class( 'status-' . $order->get_status() ) ), esc_attr( $text_color ), esc_attr( $background_color ), esc_textarea( wc_get_order_status_name( $order->get_status() ) ) );
			}
		}
	}

	/**
	 * Register my bulk actions
	 *
	 * @return array
	 */
	public function register_my_bulk_actions( $bulk_actions ) {
		$custom_statuses_query = new WP_Query(
			array(
				'post_type'  => 'zworkflowstatus',
				'meta_key'   => 'bulk_action',
				'meta_value' => 'yes',
			)
		);

		if ( $custom_statuses_query->have_posts() ) {
			foreach ( $custom_statuses_query->posts as $order_status ) {
				$custom_order_status             = new ZWORKFLOWMANAGER_Order_Status( $order_status->ID );
				$slug                            = substr( $custom_order_status->get_slug(), 3 );
				$bulk_actions[ 'mark_' . $slug ] = esc_textarea( 'Change status to ' . $slug );
			}
		}

		return $bulk_actions;
	}

	/**
	 * My bulk action handler
	 *
	 * @param string $redirect_to redirect_to.
	 * @param string $doaction doaction.
	 * @param array  $post_ids post_ids.
	 *
	 * @return string
	 */
	public function my_bulk_action_handler( $redirect_to, $doaction, $post_ids ) {
		if ( ! strstr( $doaction, 'mark_' ) ) {
			return $redirect_to;
		}
		foreach ( $post_ids as $post_id ) {
			$order = wc_get_order( $post_id );
			$order->set_status( substr( $doaction, 5 ) );
		}
		$redirect_to = add_query_arg( 'changed', count( $post_ids ), $redirect_to );

		return $redirect_to;
	}

	/**
	 * Admin order actions overwrite
	 *
	 * @return array
	 */
	public function admin_order_actions_overwrite() {
		return array();
	}

	/**
	 * Admin order actions start
	 *
	 * @param object $order get order.
	 */
	public function admin_order_actions_start( $order ) {
		$actions = array();

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}
		$order_status = new ZWORKFLOWMANAGER_Order_Status( 'wc-' . $order->get_status() );

		$next_statuses = $order_status->get_next_statuses();

		foreach ( $next_statuses as $next_status ) {
			if ( '' === $next_status ) {
				continue;
			}

			if ( 'wc-completed' === $next_status ) {
				$actions['complete'] = array(
					'url'         => wp_nonce_url( admin_url( 'admin-ajax.php?action=workflow_change_order_status&status=completed&order_id=' . $order->get_id() ), 'woocommerce-mark-order-status' ),
					'name'        => __( 'Complete', 'flow_notify_text' ),
					'action'      => 'complete',
					'core_status' => true,
				);
			}

			if ( 'wc-processing' === $next_status ) {
				$actions['processing'] = array(
					'url'         => wp_nonce_url( admin_url( 'admin-ajax.php?action=workflow_change_order_status&status=processing&order_id=' . $order->get_id() ), 'woocommerce-mark-order-status' ),
					'name'        => __( 'Processing', 'flow_notify_text' ),
					'action'      => 'processing',
					'core_status' => true,
				);
			}

			$custom_status = new ZWORKFLOWMANAGER_Order_Status( $next_status );
			if ( ! $custom_status->is_core_status() ) {
				$slug = substr( $next_status, 3 );
				$name = $custom_status->get_name();

				$actions[ $slug ] = array(
					'url'         => wp_nonce_url( admin_url( 'admin-ajax.php?action=workflow_change_order_status&status=' . $slug . '&order_id=' . $order->get_id() ), 'woocommerce-mark-order-status' ),
					'name'        => esc_textarea( $name ),
					'icon'        => $custom_status->get_action_icon(),
					'core_status' => false,
				);
			}
		}

		foreach ( $actions as $action ) {
			if ( $action['core_status'] ) {
				if ( isset( $action['group'] ) ) {
					echo '<div class="wc-action-button-group"><label>' . esc_textarea( $action['group'] ) . '</label> <span class="wc-action-button-group__items">' . esc_textarea( wc_render_action_buttons( $action['actions'] ) ) . '</span></div>';
				} elseif ( isset( $action['action'], $action['url'], $action['name'] ) ) {
					echo sprintf(
						'<a class="button wc-action-button wc-action-button-%1$s %1$s" href="%2$s" aria-label="%3$s" title="%3$s">%4$s</a>',
						esc_attr( $action['action'] ),
						esc_url( $action['url'] ),
						esc_attr( isset( $action['title'] ) ? $action['title'] : $action['name'] ),
						esc_textarea( $action['name'] )
					);
				}
			} else {
				echo sprintf(
					'<a class="button" style="text-indent: 0!important;" href="%1$s" aria-label="%2$s" title="%2$s"><i class="%3$s" style=" font-size: 13px !important; padding-top: 8px; padding-right: 2px;"></i></a>',
					esc_url( $action['url'] ),
					esc_attr( isset( $action['title'] ) ? $action['title'] : $action['name'] ),
					esc_attr( $action['icon'] )
				);
			}
		}
	}

	/**
	 * Order needs payment statuses
	 *
	 * @return array
	 */
	public function order_needs_payment_statuses() {
		$custom_needs_payment_statuses = array();
		$custom_statuses               = wc_get_order_statuses();

		foreach ( $custom_statuses as $order_status_slug => $order_status_name ) {
			$custom_status = new ZWORKFLOWMANAGER_Order_Status( $order_status_slug );

			if ( $custom_status->needs_payment() ) {
				$custom_needs_payment_statuses[] = substr( $order_status_slug, 3 );
			}
		}

		return $custom_needs_payment_statuses;
	}

	/**
	 * Order paid statuses
	 *
	 * @return array
	 */
	public function order_paid_statuses() {
		$custom_paid_statuses = array();
		$custom_statuses      = wc_get_order_statuses();

		foreach ( $custom_statuses as $order_status_slug => $order_status_name ) {
			$custom_status = new ZWORKFLOWMANAGER_Order_Status( $order_status_slug );

			if ( $custom_status->is_paid() ) {
				$custom_paid_statuses[] = substr( $order_status_slug, 3 );
			}
		}

		return $custom_paid_statuses;
	}

	/**
	 * Add menu pages
	 */
	public function add_menu_pages() {

		add_menu_page(
			'',
			'Flow Notify',
			'manage_options',
			'wc-workflows',
			array(
				$this,
				'show_order_status_page',
			),
			'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGZpbGw9InJnYmEoMjQwLCAyNDYsIDI1MiwgMC42KSIgdmlld0JveD0iMCAwIDUxMiA1MTIiPjxwYXRoIGQ9Ik0yNTYgMzEuMWMtMTQxLjQgMC0yNTUuMSA5My4xMy0yNTUuMSAyMDhjMCA0OS42MiAyMS4zNSA5NC45OCA1Ni45NyAxMzAuN2MtMTIuNSA1MC4zOC01NC4yNyA5NS4yNy01NC43NyA5NS43N2MtMi4yNSAyLjI1LTIuODc1IDUuNzM0LTEuNSA4LjczNGMxLjI1IDMgNC4wMjEgNC43NjYgNy4yNzEgNC43NjZjNjYuMjUgMCAxMTUuMS0zMS43NiAxNDAuNi01MS4zOWMzMi42MyAxMi4yNSA2OS4wMiAxOS4zOSAxMDcuNCAxOS4zOWMxNDEuNCAwIDI1NS4xLTkzLjEzIDI1NS4xLTIwNy4xUzM5Ny40IDMxLjEgMjU2IDMxLjF6TTI2NCAzMjBoLTExMkMxMzguOCAzMjAgMTI4IDMwOS4zIDEyOCAyOTZTMTM4LjggMjcyIDE1MiAyNzJoMTEyQzI3Ny4zIDI3MiAyODggMjgyLjggMjg4IDI5NlMyNzcuMyAzMjAgMjY0IDMyMHpNMzYwIDIyNGgtMjA4QzEzOC44IDIyNCAxMjggMjEzLjMgMTI4IDIwMFMxMzguOCAxNzYgMTUyIDE3NmgyMDhDMzczLjMgMTc2IDM4NCAxODYuOCAzODQgMjAwUzM3My4zIDIyNCAzNjAgMjI0eiIvPjwvc3ZnPg=='
		);

		add_submenu_page(
			'wc-workflows',
			'Dashboard',
			'Dashboard',
			'manage_options',
			'wc-workflows&tab=dashboard',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Send',
			'Send',
			'manage_options',
			'wc-workflows&tab=send',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Order Status',
			'Order Status',
			'manage_options',
			'wc-workflows&tab=order_status',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Notifications',
			'Notifications',
			'manage_options',
			'wc-workflows&tab=emails',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Activity',
			'Activity',
			'manage_options',
			'wc-workflows&tab=activities',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Connection',
			'Connection',
			'manage_options',
			'wc-workflows&tab=connection',
			array(
				$this,
				'show_order_status_page',
			)
		);

		add_submenu_page(
			'wc-workflows',
			'Settings',
			'Settings',
			'manage_options',
			'wc-workflows&tab=settings',
			array(
				$this,
				'show_order_status_page',
			)
		);

		/*
		We remove the unecessary links from the left menu
		 * while keeping the plugin menu selected
		 */
		add_action(
			'admin_head',
			function () {
				remove_submenu_page( 'wc-workflows', 'wc-workflows' );
			}
		);
	}

	/**
	 * Order status like
	 *
	 * @param string $where where.
	 * @param object $wp_query wp_query.
	 *
	 * @return string
	 */
	public function order_status_like( $where, $wp_query ) {
		global $wpdb;
		$order_status_title       = $wp_query->get( 'order_status_title' );
		$order_status_title_exact = $wp_query->get( 'order_status_title_exact' );

		if ( $order_status_title ) {
			$where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'' . esc_sql( $wpdb->esc_like( $order_status_title ) ) . '%\'';
		}

		if ( $order_status_title_exact ) {
			$where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'' . esc_sql( $wpdb->esc_like( $order_status_title_exact ) ) . '\'';
		}

		return $where;
	}

	/**
	 * Edit order status
	 */
	public function edit_order_status() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}

		$order_status_id = filter_input( INPUT_POST, 'status_id', FILTER_SANITIZE_NUMBER_INT );
		$order_status_id = sanitize_text_field( $order_status_id );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		$this->update_order_status( $order_status_id );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=order_status&edit_status=' . $order_status_id ) );
		exit;
	}

	/**
	 * Update order status
	 *
	 * @param string $order_status_id order_status_id.
	 */
	public function update_order_status( $order_status_id ) {
		$order_status = new ZWORKFLOWMANAGER_Order_Status( $order_status_id );

		$text_color                   = filter_input( INPUT_POST, 'text_color', FILTER_SANITIZE_STRING );
		$background_color             = filter_input( INPUT_POST, 'background_color', FILTER_SANITIZE_STRING );
		$order_description            = filter_input( INPUT_POST, 'order_description', FILTER_SANITIZE_STRING );
		$next_statuses                = filter_input( INPUT_POST, 'next_statuses', FILTER_SANITIZE_STRING, FILTER_FORCE_ARRAY );
		$post_title                   = filter_input( INPUT_POST, 'post_title', FILTER_SANITIZE_STRING );
		$slug                         = filter_input( INPUT_POST, 'slug', FILTER_SANITIZE_STRING );
		$zworkflowmanager_action_icon = filter_input( INPUT_POST, 'zworkflowmanager_action_icon', FILTER_SANITIZE_STRING );
		$default_status               = filter_input( INPUT_POST, 'default_status', FILTER_SANITIZE_STRING );
		$bulk_action                  = filter_input( INPUT_POST, 'bulk_action', FILTER_SANITIZE_STRING );
		$include_in_reports           = filter_input( INPUT_POST, 'include_in_reports', FILTER_SANITIZE_STRING );
		$is_paid                      = filter_input( INPUT_POST, 'is_paid', FILTER_SANITIZE_STRING );

		if ( $order_status->is_core_status() ) {
			if ( isset( $text_color ) ) {
				$order_status->set_text_color( $text_color );
			}

			if ( isset( $background_color ) ) {
				$order_status->set_background_color( $background_color );
			}

			if ( isset( $order_description ) ) {
				$order_status->set_description( $order_description );
			}

			if ( isset( $next_statuses ) ) {
				$order_status->set_next_statuses( $next_statuses );
			}
		} else {
			if ( isset( $post_title ) ) {
				$order_status->set_name( $post_title );
			}

			if ( isset( $slug ) ) {
				$order_status->set_slug( $slug );
			}

			if ( isset( $order_description ) ) {
				$order_status->set_description( $order_description );
			}

			if ( isset( $text_color ) ) {
				$order_status->set_text_color( $text_color );
			}

			if ( isset( $background_color ) ) {
				$order_status->set_background_color( $background_color );
			}

			if ( isset( $zworkflowmanager_action_icon ) ) {
				$order_status->set_action_icon( $zworkflowmanager_action_icon );
			}

			if ( isset( $next_statuses ) ) {
				$order_status->set_next_statuses( $next_statuses );
			}

			if ( isset( $default_status ) && '' !== $default_status ) {
				$order_status->set_default_status( $default_status );
			}

			if ( isset( $bulk_action ) ) {
				$order_status->set_is_bulk_action( 'yes' );
			} else {
				$order_status->set_is_bulk_action( 'no' );
			}

			if ( isset( $include_in_reports ) ) {
				$order_status->set_include_in_reports( 'yes' );
			} else {
				$order_status->set_include_in_reports( 'no' );
			}

			if ( isset( $is_paid ) ) {
				$order_status->set_is_paid( $is_paid );
			}
		}
	}

	/**
	 * Save emails options for notification template
	 */
	public function save_email_template() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
		}

		$names_arr['name']             = filter_input( INPUT_POST, 'name', FILTER_DEFAULT, FILTER_SANITIZE_STRING );
		$names_arr['address']          = filter_input( INPUT_POST, 'address', FILTER_SANITIZE_STRING );
		$names_arr['aw_custom_image']  = filter_input( INPUT_POST, 'aw_custom_image', FILTER_SANITIZE_STRING );
		$names_arr['footer_text']      = filter_input( INPUT_POST, 'footer_text', FILTER_SANITIZE_STRING );
		$names_arr['base_color']       = filter_input( INPUT_POST, 'base_color', FILTER_SANITIZE_STRING );
		$names_arr['background_color'] = filter_input( INPUT_POST, 'background_color', FILTER_SANITIZE_STRING );
		$names_arr['body_bg_color']    = filter_input( INPUT_POST, 'body_bg_color', FILTER_SANITIZE_STRING );
		$names_arr['body_text_color']  = filter_input( INPUT_POST, 'body_text_color', FILTER_SANITIZE_STRING );

		/* Getting Last updated settings */
		update_option( 'notification_email_settings', $names_arr );
		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=settings' ) );
		exit;
	}

	/**
	 * Checks the post array element for existence. Filters data and writes to an array
	 */

	public function add_option_to_array( &$array, $key, $filter = FILTER_SANITIZE_STRING ) {
		if ( isset( $_POST[ $key ] ) && isset( $_POST['settings_notify_nonce_field'] ) && wp_verify_nonce( sanitize_text_field( $_POST['settings_notify_nonce_field'] ), 'settings_notify_action' ) ) {
			$value         = filter_input( INPUT_POST, $key, $filter );
			$array[ $key ] = 'off' === $value ? null : $value;
		}

		return $array;
	}

	/**
	 * Save emails options for notification template
	 */
	public function save_settings_template() {
		$settings_status = new ZWORKFLOWMANAGER_Settings();

		$names_arr = array();

		$this->add_option_to_array( $names_arr, 'product_page', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'display_on_product_page', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'notify_opt_in_text', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'notify_button_text', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'notification_opt-in', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'opt-in_text', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_preference', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_email', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_sms', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_whatsapp', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'default_communication_method', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'message_timeframe_schedule', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_schedule_email', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_schedule_sms', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'communication_methods_schedule_wa', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'schedule_timeframe_from', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'schedule_timeframe_to', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'name', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'address', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'aw_custom_image', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'footer_text', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'base_color', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'background_color', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'body_bg_color', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'body_text_color', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'save_info_logs', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'delete_setting', FILTER_SANITIZE_STRING );
		$this->add_option_to_array( $names_arr, 'default_code', FILTER_SANITIZE_STRING );

		/* Getting Last updated settings */
		$old_settings = get_option( 'notification_email_settings' );

		if ( is_array( $old_settings ) ) {
			$new_settings = array_merge( $old_settings, $names_arr );
			$settings_status->set_settings( $new_settings );
		} else {
			$settings_status->set_settings( $names_arr );
		}

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		if ( isset( $_POST['settings_notify_nonce_field'] ) && wp_verify_nonce( sanitize_text_field( $_POST['settings_notify_nonce_field'] ), 'settings_notify_action' ) ) {
			$type_form = filter_input( INPUT_POST, 'type-form', FILTER_SANITIZE_STRING );

			if ( 'opt-in' === $type_form ) {
				wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=settings&section=opt-ins' ) );
			}

			if ( 'support' === $type_form ) {
				wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=settings&section=support' ) );
			}

			if ( 'general' === $type_form ) {
				wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=settings' ) );
			}
		}

		exit;
	}

	/**
	 * New message template
	 */
	public function new_message_template() {
		if ( ! isset( $_POST['zwf_template_message_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['zwf_template_message_nonce'] ), 'zwf_template_message_nonce' ) ) {
			return;
		}

		 $sending_type = ( isset( $_POST['sending_type'] ) ) ? sanitize_text_field( wp_unslash( $_POST['sending_type'] ) ) : '';

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
		}

		$post_title = ( isset( $_POST['post_title'] ) ) ? sanitize_text_field( wp_unslash( $_POST['post_title'] ) ) : '';

		$email_exist = new WP_Query(
			array(
				'order_status_title_exact' => $post_title,
				'post_type'                => 'zworkflowtemplates',
			)
		);

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		if ( $email_exist->have_posts() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails' ) );
			exit;
		}

		$slug = preg_replace( '/\s+/', '_', strtolower( $post_title ) );

		$template_message_id = wp_insert_post(
			array(
				'post_title'  => $post_title,
				'post_type'   => 'zworkflowtemplates',
				'post_status' => 'publish',
				'meta_input'  => array(
					'zcustotemplate_slug' => $slug,
				),
			)
		);

		$this->update_message_template_status( $template_message_id );

		if ( 'whatsapp' === $sending_type ) {
			$whatsapp = new ZWORKFLOWMANAGER_Whatsapp();
			$whatsapp->add_message_template( $template_message_id );
			update_post_meta( $template_message_id, 'zapproval_status', 'PENDING' );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails&section=message-templates&edit_template=' . $template_message_id ) );
		exit;
	}

	/**
	 * New email status
	 */
	public function new_email_status() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
		}

		$post_title = filter_input( INPUT_POST, 'post_title', FILTER_SANITIZE_STRING );

		$email_exist = new WP_Query(
			array(
				'order_status_title_exact' => $post_title,
				'post_type'                => 'zworkflowemail',
			)
		);

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		if ( $email_exist->have_posts() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails' ) );
			exit;
		}

		$slug = preg_replace( '/\s+/', '_', strtolower( $post_title ) );

		$email_status_id = wp_insert_post(
			array(
				'post_title'  => $post_title,
				'post_type'   => 'zworkflowemail',
				'post_status' => 'publish',
				'meta_input'  => array(
					'zcustomemail_slug' => $slug,
				),
			)
		);

		$this->update_email_status( $email_status_id );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails&edit_email=' . $email_status_id ) );
		exit;
	}

	/**
	 * Update message template_status
	 */
	public function update_message_template_status( $email_status_id ) {
		$post_title           = filter_input( INPUT_POST, 'post_title', FILTER_SANITIZE_STRING );
		$type                 = filter_input( INPUT_POST, 'type', FILTER_SANITIZE_STRING );
		$sending_type         = filter_input( INPUT_POST, 'sending_type', FILTER_SANITIZE_STRING );
		$zcustomemail_subject = filter_input( INPUT_POST, 'zmessagetemplate_subject', FILTER_SANITIZE_STRING );
		$status_toggle        = filter_input( INPUT_POST, 'status_toggle', FILTER_SANITIZE_STRING );
		$description          = filter_input( INPUT_POST, 'description', FILTER_SANITIZE_STRING );
		$template_name        = filter_input( INPUT_POST, 'zcustomemail_template_name', FILTER_SANITIZE_STRING );
		$template_language    = filter_input( INPUT_POST, 'template_language', FILTER_SANITIZE_STRING );
		$template_category    = filter_input( INPUT_POST, 'template_category', FILTER_SANITIZE_STRING );

		if ( isset( $post_title ) ) {
			wp_update_post(
				array(
					'post_title' => trim( $post_title ),
					'ID'         => $email_status_id,
				)
			);
		}
		if ( isset( $type ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_type', $type );
		}
		if ( isset( $sending_type ) ) {
			update_post_meta( $email_status_id, 'zsending_type', $sending_type );
		}
		if ( isset( $zcustomemail_subject ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_subject', $zcustomemail_subject );
		}
		if ( isset( $status_toggle ) && 'on' === $status_toggle ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_status', 'enabled' );
		} else {
			update_post_meta( $email_status_id, 'zmessagetemplate_status', 'disabled' );
		}
		if ( isset( $description ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_description', $description );
		}
		if ( isset( $template_name ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_name', $template_name );
		}
		if ( isset( $template_language ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_language', $template_language );
		}
		if ( isset( $template_category ) ) {
			update_post_meta( $email_status_id, 'zmessagetemplate_category', $template_category );
		}
	}

	/**
	 * Update Email status
	 *
	 * @param string $email_status_id email_status_id.
	 */
	public function update_email_status( $email_status_id ) {
		$email_status = new ZWORKFLOWMANAGER_Status_Email( $email_status_id );
		if ( isset( $_POST['zwf_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['zwf_nonce'] ), 'zfn_operation_type' ) ) {
			$post_title                    = ( isset( $_POST['post_title'] ) ) ? sanitize_text_field( wp_unslash( $_POST['post_title'] ) ) : '';
			$type                          = ( isset( $_POST['type'] ) ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
			$sending_type                  = ( isset( $_POST['sending_type'] ) ) ? sanitize_text_field( wp_unslash( $_POST['sending_type'] ) ) : '';
			$zcustomemail_subject          = ( isset( $_POST['zcustomemail_subject'] ) ) ? sanitize_text_field( wp_unslash( $_POST['zcustomemail_subject'] ) ) : '';
			$status_toggle                 = ( isset( $_POST['status_toggle'] ) ) ? sanitize_text_field( wp_unslash( $_POST['status_toggle'] ) ) : '';
			$description                   = ( isset( $_POST['description'] ) ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
			$type_preference_status_toggle = ( isset( $_POST['type_preference_status_toggle'] ) ) ? sanitize_text_field( wp_unslash( $_POST['type_preference_status_toggle'] ) ) : '';
			$trigger_status                = ( isset( $_POST['trigger'] ) ) ? sanitize_text_field( wp_unslash( $_POST['trigger'] ) ) : '';
			$total_spend                   = ( isset( $_POST['total_spend'] ) ) ? sanitize_text_field( wp_unslash( $_POST['total_spend'] ) ) : '';
			$from_dispatch_element         = ( isset( $_POST['from_dispatch_element'] ) ) ? sanitize_text_field( wp_unslash( $_POST['from_dispatch_element'] ) ) : '';
			$to_dispatch_element           = ( isset( $_POST['to_dispatch_element'] ) ) ? sanitize_text_field( wp_unslash( $_POST['to_dispatch_element'] ) ) : '';
			$timing_type                   = ( isset( $_POST['timing'] ) ) ? sanitize_text_field( wp_unslash( $_POST['timing'] ) ) : '';
			$schedule_timeframe_enabled    = ( isset( $_POST['schedule_timeframe'] ) ) ? sanitize_text_field( wp_unslash( $_POST['schedule_timeframe'] ) ) : '';
			$message_template_id           = ( isset( $_POST['message_template'] ) ) ? sanitize_text_field( wp_unslash( $_POST['message_template'] ) ) : '';
		}

		if ( 'on' === $schedule_timeframe_enabled ) {
			update_post_meta( $email_status_id, 'zcustomemail_timeframe_enabled', $schedule_timeframe_enabled );
		} else {
			delete_post_meta( $email_status_id, 'zcustomemail_timeframe_enabled' );
		}

		if ( $timing_type ) {
			$email_status->set_timing_settings();
		} else {
			delete_post_meta( $email_status_id, 'zcustomemail_timing_settings' );
		}

		if ( isset( $post_title ) ) {
			$email_status->set_name( $post_title );
		}
		if ( isset( $type ) ) {
			$email_status->set_type( $type );
		}
		if ( isset( $sending_type ) ) {
			$email_status->set_sending_type( $sending_type );
		}
		if ( isset( $zcustomemail_subject ) ) {
			$email_status->set_subject( $zcustomemail_subject );
		}
		if ( isset( $trigger_status ) ) {
			$email_status->set_trigger_status( $trigger_status );
		}
		if ( isset( $total_spend ) ) {
			$email_status->set_total_spend( $total_spend );
		}

		if ( isset( $status_toggle ) && 'on' === $status_toggle ) {
			$email_status->set_status( 'enabled' );
		} else {
			$email_status->set_status( 'disabled' );
		}

		if ( isset( $description ) ) {
			$email_status->set_description( $description );
		}

		if ( $message_template_id ) {
			$email_status->set_message_template_id( $message_template_id );
		}

		if ( isset( $type_preference_status_toggle ) && 'on' === $type_preference_status_toggle ) {
			$email_status->set_type_preference( 'enabled' );
		} else {
			$email_status->set_type_preference( 'disabled' );
		}

		if ( isset( $from_dispatch_element ) && isset( $to_dispatch_element ) ) {
			$from = str_replace( 'wc-', '', $from_dispatch_element );
			$to   = str_replace( 'wc-', '', $to_dispatch_element );

			$email_status->set_dispatch_list( $from . '_to_' . $to );
		}
	}

	/**
	 * Edit email status
	 */
	public function edit_email_status() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
		}

		$status_id = filter_input( INPUT_POST, 'status_id', FILTER_SANITIZE_NUMBER_INT );

		$email_status_id = sanitize_text_field( $status_id );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		$this->update_email_status( $email_status_id );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails&edit_email=' . $email_status_id ) );
		exit;
	}

	/**
	 * Edit message template
	 */
	public function edit_message_template() {
		$status_id         = filter_input( INPUT_POST, 'status_id', FILTER_SANITIZE_NUMBER_INT );
		$sending_type      = filter_input( INPUT_POST, 'sending_type', FILTER_SANITIZE_STRING );
		$description       = filter_input( INPUT_POST, 'description', FILTER_SANITIZE_STRING );
		$template_category = filter_input( INPUT_POST, 'template_category', FILTER_SANITIZE_STRING );

		$template_status_id = sanitize_text_field( $status_id );
		$old_description    = get_post_meta( $template_status_id, 'zmessagetemplate_description', true );

		if ( $old_description !== $description && 'whatsapp' === $sending_type ) {
			$whatsapp             = new ZWORKFLOWMANAGER_Whatsapp();
			$whatsapp_template_id = get_post_meta( $template_status_id, 'whatsapp_template_id', true );

			$result = $whatsapp->edit_template( $whatsapp_template_id, $description, $template_category );

			$result = json_decode( $result['body'] );

			if ( $result->success ) {
				set_transient( 'fx-admin-notice-panel', true, 5 );
				set_transient( 'fx-admin-notice-panel-status', 'Edit_whatsapp_template', 5 );
				set_transient( 'whatsapp-respond', 'Your template has been sent for approval', 5 );
				update_post_meta( $template_status_id, 'zapproval_status', 'PENDING' );
				$this->update_message_template_status( $template_status_id );

			} else {
				set_transient( 'fx-admin-error-notice-panel', $result->error->message, 5 );
			}
		} else {
			set_transient( 'fx-admin-notice-panel', true, 5 );
			$this->update_message_template_status( $template_status_id );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails&section=message-templates&edit_template=' . $template_status_id ) );

		exit;
	}

	/**
	 * Edit send information
	 */
	public function edit_send() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		$send_status_id = filter_input( INPUT_POST, 'status_id', FILTER_SANITIZE_STRING );
		$date           = filter_input( INPUT_POST, 'date', FILTER_SANITIZE_STRING );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		$this->update_send_status( $send_status_id );

		( 'Instant' === $date ) ? wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=send' ) ) : wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=send&edit_send=' . $send_status_id ) );
		exit;
	}

	/**
	 * Update posts who have post_type 'zworkflowsend'
	 *
	 * @param string $email_status_id email_status_id.
	 *
	 * @return bool[]
	 */
	public function update_send_status( $email_status_id ) {
		$send_status = new ZWORKFLOWMANAGER_Send( $email_status_id );

		$names_arr['datepicker']        = filter_input( INPUT_POST, 'datepicker', FILTER_SANITIZE_STRING );
		$names_arr['timepicker']        = filter_input( INPUT_POST, 'timepicker', FILTER_SANITIZE_STRING );
		$names_arr['recipient']         = filter_input( INPUT_POST, 'recipient', FILTER_SANITIZE_STRING );
		$names_arr['SMS']               = filter_input( INPUT_POST, 'SMS', FILTER_SANITIZE_STRING );
		$names_arr['email']             = filter_input( INPUT_POST, 'email', FILTER_SANITIZE_EMAIL );
		$names_arr['whatsapp']          = filter_input( INPUT_POST, 'whatsapp', FILTER_SANITIZE_STRING );
		$names_arr['notification']      = filter_input( INPUT_POST, 'notification', FILTER_SANITIZE_STRING );
		$names_arr['description']       = filter_input( INPUT_POST, 'description', FILTER_SANITIZE_STRING );
		$names_arr['date']              = filter_input( INPUT_POST, 'date', FILTER_SANITIZE_STRING );
		$names_arr['send_status']       = filter_input( INPUT_POST, 'date', FILTER_SANITIZE_STRING );
		$names_arr['wooCommerceData']   = filter_input( INPUT_POST, 'wooCommerceData', FILTER_SANITIZE_STRING );
		$names_arr['wooCommerceOrders'] = filter_input( INPUT_POST, 'wooCommerceOrders', FILTER_SANITIZE_STRING );
		$names_arr['subject']           = filter_input( INPUT_POST, 'subject', FILTER_SANITIZE_STRING );
		$user_recipient                 = filter_input( INPUT_POST, 'user_recipient', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$names_arr['timestamp_chedule'] = $this->create_timestamp( $names_arr['datepicker'], $names_arr['timepicker'] );

		$send_type = $names_arr['date'];

		if ( 'Scheduled' === $names_arr['date'] ) {
			$send_type = 'Edit_Scheduled';
		}
		set_transient( 'fx-admin-notice-panel-status', $send_type, 5 );

		$all_users                   = $this->get_customer_users();
		$users_id                    = array();
		$names_arr['user_recipient'] = ( 'All Customers' === $names_arr['recipient'] ) ? $all_users : $user_recipient;

		foreach ( $names_arr as $key => $value ) {
			$send_status->set_data( $key, $value );
		}

		/* Collect users ID to variable */
		foreach ( $names_arr['user_recipient'] as $user ) {
			array_push( $users_id, ( is_array( $user ) ) ? $user['ID'] : explode( ',', $user )[2] );
		}

		if ( 'Instant' === $send_type || 'Instant' === $names_arr['date'] ) {
			/* if there is this parameter, then we select the order by user_id */
			if ( 'include_data' === $names_arr['wooCommerceData'] ) {

				foreach ( $users_id as $user_id ) {
					/* get order_id */
					$orders_id = ( 'last_order_placed' === $names_arr['wooCommerceOrders'] )
						? $this->get_last_order_id( $user_id ) : $this->get_all_order_id( $user_id );

					foreach ( $orders_id as $id ) {
						/* get a user if the user_id is equal to the user_id of the order */
						$user = $this->get_customer_users( $user_id );
						$this->send_from_admin( $user, null, null, $email_status_id, $id );
					}
				}
			} else {
				$this->send_from_admin( $names_arr['user_recipient'], null, null, $email_status_id );
			}
		}

		return array( 'success' => true );
	}

	/**
	 * Create timestamp helper for select in database
	 *
	 * @param string $date date.
	 * @param string $time time.
	 *
	 * @return false|int
	 */
	public function create_timestamp( $date, $time = '0:0:0' ) {
		$timestamp = false;

		if ( is_null( $date ) && ( is_null( $time ) || '0:0:0' === $time ) ) {
			return $timestamp;
		}

		$timestamp = strtotime( $date . ' ' . $time );

		return $timestamp;
	}

	/**
	 * Get users who have role 'customer'
	 *
	 * @param null $user_id user_id.
	 *
	 * @return array|object|stdClass[]|null
	 */
	public function get_customer_users( $user_id = null ) {
		global $wpdb;

		$usermeta = $wpdb->prefix . 'usermeta';

		$request                      = array();
		$args                         = array( 'role__in' => array( 'customer', 'subscriber' ) );
		$wp_user_query                = new WP_User_Query( $args );
		$wp_user_query->query_orderby = str_replace( 'user_login', $usermeta . '.meta_value', $wp_user_query->query_orderby );
		$wp_user_query->query();
		$users = $wp_user_query->get_results();

		foreach ( $users as $u ) {
			if ( ! is_null( $user_id ) && (int) $user_id !== $u->ID ) {
				continue;
			}
			array_push(
				$request,
				array(
					'ID'             => $u->ID,
					'user_email'     => $u->user_email,
					'first_name'     => get_user_meta( $u->ID, 'first_name', true ),
					'last_name'      => get_user_meta( $u->ID, 'last_name', true ),
					'billing_phone'  => get_user_meta( $u->ID, 'billing_phone', true ),
					'whatsapp_phone' => get_user_meta( $u->ID, 'whatsapp_phone', true ),
					'whatsapp_code'  => get_user_meta( $u->ID, 'zworkflow_whatsapp_code', true ),
				)
			);
		}

		return $request;
	}

	/**
	 * Get last order_id
	 *
	 * @param string $user_id user_id.
	 *
	 * @return mixed
	 */
	private function get_last_order_id( $user_id ) {
		global $wpdb;

		/* Getting last Order ID (max value) */
		$results = $wpdb->get_col(
			$wpdb->prepare(
				"
            SELECT MAX(ID) FROM $wpdb->posts INNER JOIN $wpdb->postmeta
            ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE post_type LIKE %s
            AND $wpdb->postmeta.meta_key = %s
            AND $wpdb->postmeta.meta_value LIKE %d
        ",
				'shop_order',
				'_customer_user',
				$user_id
			)
		);

		return $results;
	}

	/**
	 * Get all order_id's
	 *
	 * @param string $user_id user_id.
	 *
	 * @return mixed
	 */
	private function get_all_order_id( $user_id ) {
		global $wpdb;

		/* Getting all Order ID's */
		$results = $wpdb->get_col(
			$wpdb->prepare(
				"
            SELECT ID FROM $wpdb->posts INNER JOIN $wpdb->postmeta
            ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE post_type LIKE %s
            AND $wpdb->postmeta.meta_key = %s
            AND $wpdb->postmeta.meta_value LIKE %d
        ",
				'shop_order',
				'_customer_user',
				$user_id
			)
		);

		return $results;
	}

	/**
	 * New send from admin
	 */
	public function new_send_from_admin() {

		if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
		}

		$datepicker = filter_input( INPUT_POST, 'datepicker', FILTER_SANITIZE_STRING );
		$timepicker = filter_input( INPUT_POST, 'timepicker', FILTER_SANITIZE_STRING );
		$send_type  = filter_input( INPUT_POST, 'date', FILTER_SANITIZE_STRING );

		$send_status_id = wp_insert_post(
			array(
				'post_title'  => $datepicker . ', ' . $timepicker,
				'post_type'   => 'zworkflowsend',
				'post_status' => 'publish',
			)
		);

		$result = $this->update_send_status( $send_status_id );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );
		set_transient( 'fx-admin-notice-panel-status', $send_type, 5 );

		/* Try to setup connection with Twilio service */
		if ( isset( $result['success'] ) && $result['success'] ) {
			/* Force show notice after page will be reloaded */
			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=send' ) );
			exit;
		}

		/* ↓↓↓↓ Connection wasn't successfully established ↓↓↓↓ */

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-error-notice-panel', $result['error'], 5 );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=send' ) );
		exit;
	}

	/**
	 * Send order notification
	 */
	public function send_order_notification() {
		if ( ! isset( $_POST['zwf_send_order_nonce'] ) && ! wp_verify_nonce( sanitize_key( $_POST['zwf_send_order_nonce'] ), 'zwf_send_order_nonce' ) ) {
			return;
		}
		$data                        = array();
		$order_id                    = ( isset( $_POST['order_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : '';
		$subject                     = ( isset( $_POST['subject'] ) ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$names_arr['description']    = ( isset( $_POST['description'] ) ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
		$names_arr['notification']   = ( isset( $_POST['notification'] ) ) ? sanitize_text_field( wp_unslash( $_POST['notification'] ) ) : '';
		$names_arr['send_status']    = ( isset( $_POST['send_status'] ) ) ? sanitize_text_field( wp_unslash( $_POST['send_status'] ) ) : '';
		$names_arr['product_values'] = ( isset( $_POST['product_values'] ) ) ? sanitize_text_field( wp_unslash( $_POST['product_values'] ) ) : '';
		$communication_preference    = ( isset( $_POST['communication_preference'] ) ) ? sanitize_text_field( wp_unslash( $_POST['communication_preference'] ) ) : '';
		$message_template_id         = ( isset( $_POST['message_template_id'] ) ) ? sanitize_text_field( wp_unslash( $_POST['message_template_id'] ) ) : '';

		$names_arr['SMS']            = ( 'sms' === $communication_preference ) ? $communication_preference : '';
		$names_arr['email']          = ( 'email' === $communication_preference ) ? $communication_preference : '';
		$names_arr['date']           = 'Instant';
		$order                       = wc_get_order( $order_id );
		$user_phone                  = $order->get_billing_phone();
		$user_email                  = $order->get_billing_email();
		$send_order_notification     = $order->get_meta( 'send_order_notification' );
		$placeholder_arr             = $this->get_information_by_order( $order_id );
		$products_info               = $this->get_information_by_product( $names_arr['product_values'] );
		$names_arr['user_recipient'] = array( $user_email . ',' . $user_phone );
		$users                       = array(
			array(
				'user_email'    => $user_email,
				'billing_phone' => $user_phone,
			),
		);

		foreach ( $placeholder_arr as $key => $value ) {
			$names_arr['description'] = str_replace( '{' . $key . '}', $value, $names_arr['description'] );
		}

		if ( $products_info ) {
			foreach ( $products_info as $product ) {
				foreach ( $product as $key => $value ) {
					$names_arr['description'] = str_replace( '{' . $key . '}', $value, $names_arr['description'] );
				}
			}
		}

		$send_status_id = wp_insert_post(
			array(
				'post_title'  => gmdate( 'm/d/Y, H:i' ),
				'post_type'   => 'zworkflowsend',
				'post_status' => 'publish',
			)
		);

		array_push(
			$data,
			array(
				'post_id'        => $send_status_id,
				'subject'        => $subject,
				'sms'            => ( 'SMS' === $communication_preference || 'sms' === $communication_preference )
					? $communication_preference : '',
				'email'          => ( 'email' === $communication_preference ) ? $communication_preference : '',
				'whatsapp'       => ( 'whatsapp' === $communication_preference ) ? $communication_preference : '',
				'description'    => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
				'zsending_type'  => $communication_preference,
				'template_name'  => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
				'template_lang'  => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
				'whatsapp_phone' => $order->get_meta( 'billing_whatsapp_phone' ),
			)
		);

		$send_status = new ZWORKFLOWMANAGER_Send( $send_status_id );

		foreach ( $names_arr as $key => $value ) {
			$send_status->set_data( $key, $value );
		}

		$this->send_from_admin( $users, null, $data, $send_status_id, $order_id );

		if ( empty( $send_order_notification ) || is_null( $send_order_notification ) ) {
			$order->update_meta_data(
				'send_order_notification',
				array(
					array(
						$names_arr['description'],
						$communication_preference,
						gmdate( 'd.m.Y \a\t H:i' ),
					),
				)
			);
			$order->save();

		} else {
			$send_order_notification[] = array(
				$names_arr['description'],
				$communication_preference,
				gmdate( 'd.m.Y \a\t H:i' ),
			);

			$order->update_meta_data( 'send_order_notification', $send_order_notification );
			$order->save();
		}

		wp_send_json_success();
	}

	/**
	 * Save notification details
	 */
	public function save_notification_details() {
		$user_id                  = get_current_user_id();
		$communication_preference = filter_input( INPUT_POST, 'communication_preference', FILTER_SANITIZE_STRING );
		$product_notifications    = filter_input( INPUT_POST, 'product_notifications', FILTER_SANITIZE_STRING );
		$all_notifications        = filter_input( INPUT_POST, 'all_notifications', FILTER_SANITIZE_STRING );

		if ( isset( $communication_preference ) ) {
			update_user_meta( $user_id, 'communication_preference', $communication_preference );
		}
		if ( isset( $product_notifications ) || is_null( $product_notifications ) ) {
			update_user_meta( $user_id, 'product_notifications', $product_notifications );
		}
		if ( isset( $all_notifications ) || is_null( $product_notifications ) ) {
			update_user_meta( $user_id, 'all_notifications', $all_notifications );
		}

		wp_send_json_success();
	}

	/**
	 * Create new order status
	 */
	public function new_order_status() {
		if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
		}

		$post_title = filter_input( INPUT_POST, 'post_title', FILTER_SANITIZE_STRING );
		$slug       = filter_input( INPUT_POST, 'slug', FILTER_SANITIZE_STRING );

		$os_exist = new WP_Query(
			array(
				'order_status_title_exact' => $post_title,
				'post_type'                => 'zworkflowstatus',
			)
		);

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		if ( $os_exist->have_posts() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows' ) );
			exit;
		}

		$order_status_id = wp_insert_post(
			array(
				'post_title'  => $post_title,
				'post_type'   => 'zworkflowstatus',
				'post_status' => 'publish',
				'meta_input'  => array(
					'zworkflowstatus_slug' => $slug,
					'zcustomstatus_type'   => 'core',
					'text_color'           => '#777',
					'background_color'     => '#e5e5e5',
				),
			)
		);

		register_post_status(
			$slug,
			array(
				'label'                     => $post_title,
				'public'                    => false,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				/* Translators: %s: posts count */
				'label_count'               => _n_noop( '$post_title <span class="count">(%s)</span>', '$post_title <span class="count">(%s)</span>', 'flow_notify_text' ),
			)
		);

		$this->update_order_status( $order_status_id );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=order_status&edit_status=' . $order_status_id ) );
		exit;
	}

	/**
	 * Insert original statuses
	 */
	public function insert_original_statuses() {
		$default_statuses = $this->get_core_statuses();
		foreach ( $default_statuses as $slug => $title ) {
			$exist_status_query = new WP_Query(
				array(
					'post_type'  => 'zworkflowstatus',
					'meta_key'   => 'zworkflowstatus_slug',
					'meta_value' => $slug,
				)
			);

			if ( $exist_status_query->have_posts() ) {
				continue;
			}

			$text_color       = $this->get_core_text_color( $slug );
			$background_color = $this->get_core_background_color( $slug );

			wp_insert_post(
				array(
					'post_title'  => $title,
					'post_type'   => 'zworkflowstatus',
					'post_status' => 'publish',
					'meta_input'  => array(
						'zworkflowstatus_slug' => $slug,
						'zcustomstatus_type'   => 'core',
						'text_color'           => $text_color,
						'background_color'     => $background_color,
						'next_statuses'        => $this->zworkflowmanager_get_core_next_statuses( $slug ),
					),
				)
			);
		}
	}

	/**
	 * Get core statuses
	 *
	 * @return array
	 */
	public function get_core_statuses() {
		return array(
			'wc-pending'    => _x( 'Pending payment', 'Order status', 'flow_notify_text' ),
			'wc-processing' => _x( 'Processing', 'Order status', 'flow_notify_text' ),
			'wc-on-hold'    => _x( 'On hold', 'Order status', 'flow_notify_text' ),
			'wc-completed'  => _x( 'Completed', 'Order status', 'flow_notify_text' ),
			'wc-cancelled'  => _x( 'Cancelled', 'Order status', 'flow_notify_text' ),
			'wc-refunded'   => _x( 'Refunded', 'Order status', 'flow_notify_text' ),
			'wc-failed'     => _x( 'Failed', 'Order status', 'flow_notify_text' ),
		);
	}

	/**
	 * Get core text color
	 *
	 * @param string $slug slug.
	 *
	 * @return string
	 */
	private function get_core_text_color( $slug ) {
		switch ( $slug ) {
			case 'wc-pending':
			case 'wc-cancelled':
			case 'wc-refunded':
				return '#777';
			case 'wc-processing':
				return '#5b841b';
			case 'wc-on-hold':
				return '#94660c';
			case 'wc-completed':
				return '#2e4453';
			case 'wc-failed':
				return '#761919';
		}
	}

	/**
	 * Get core background color
	 *
	 * @param string $slug slug.
	 *
	 * @return string
	 */
	private function get_core_background_color( $slug ) {
		switch ( $slug ) {
			case 'wc-pending':
			case 'wc-refunded':
			case 'wc-cancelled':
				return '#e5e5e5';
			case 'wc-processing':
				return '#c6e1c6';
			case 'wc-on-hold':
				return '#f8dda7';
			case 'wc-completed':
				return '#c8d7e1';
			case 'wc-failed':
				return '#eba3a3';
		}
	}

	/**
	 * Get core next statuses
	 *
	 * @param string $status status.
	 *
	 * @return string
	 */
	public function zworkflowmanager_get_core_next_statuses( $status ) {
		switch ( $status ) {
			case 'wc-pending':
			case 'wc-on-hold':
				return 'wc-processing,wc-completed';
			case 'wc-processing':
				return 'wc-completed';
		}

		return '';
	}
	/**
	 * Print settings tabs
	 */
	public function print_settings_tabs() {
		$tab = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_STRING );

		?>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=order_status' ) ); ?>"
		class="nav-tab
		<?php echo( 'order_status' === $tab ? 'nav-tab-active' : '' ); ?>">
		<?php esc_html_e( 'Status', 'flow_notify_text' ); ?>
		</a>
		<?php
	}

	/**
	 * Show order status page
	 */
	public function show_order_status_page() {
		require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/order-statuses/order-statuses.php';
	}

	/**
	 * Is core status
	 *
	 * @param string $slug slug.
	 *
	 * @return bool
	 */
	public function is_core_status( $slug ) {
		switch ( $slug ) {
			case 'wc-pending':
			case 'wc-processing':
			case 'wc-on-hold':
			case 'wc-completed':
			case 'wc-cancelled':
			case 'wc-refunded':
			case 'wc-failed':
				return true;
			default:
				return false;
		}
	}

	/**
	 * Get order statuses
	 *
	 * @param array $order_statuses order_statuses.
	 *
	 * @return array
	 */
	public function get_order_statuses( $order_statuses ) {
		$exist_status_query = new WP_Query(
			array(
				'posts_per_page' => - 1,
				'post_type'      => 'zworkflowstatus',
			)
		);
		$custom_statuses    = $exist_status_query->get_posts();
		if ( count( $custom_statuses ) === 0 ) {
			return $order_statuses;
		}
		$return_status = array();
		foreach ( $custom_statuses as $custom_status ) {
			$slug                   = get_post_meta( $custom_status->ID, 'zworkflowstatus_slug', true );
			$title                  = esc_textarea( $custom_status->post_title );
			$return_status[ $slug ] = $title;
		}

		return $return_status;
	}

	/**
	 * General Admin Init hook
	 */
	public function admin_init() {
		if ( isset( $_GET['zwf_nonce'] ) && wp_verify_nonce( sanitize_key( $_GET['zwf_nonce'] ), 'zfn_operation_type' ) ) {
			$operation_type         = ( isset( $_GET['zfn_operation_type'] ) ) ? sanitize_text_field( wp_unslash( $_GET['zfn_operation_type'] ) ) : '';
			$notification_id        = ( isset( $_GET['notification_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['notification_id'] ) ) : '';
			$order_status_id        = ( isset( $_GET['order_status_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['order_status_id'] ) ) : '';
			$send_id                = ( isset( $_GET['send_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['send_id'] ) ) : '';
			$message_template_id    = ( isset( $_GET['message_template_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['message_template_id'] ) ) : '';
			$sending_type           = ( isset( $_GET['sending_type'] ) ) ? sanitize_text_field( wp_unslash( $_GET['sending_type'] ) ) : '';
			$whatsapp_template_id   = ( isset( $_GET['whatsapp_template_id'] ) ) ? sanitize_text_field( wp_unslash( $_GET['whatsapp_template_id'] ) ) : '';
			$template_name          = ( isset( $_GET['template_name'] ) ) ? sanitize_text_field( wp_unslash( $_GET['template_name'] ) ) : '';
			$backward_compatibility = ( isset( $_GET['backward_compatibility'] ) ) ? sanitize_text_field( wp_unslash( $_GET['backward_compatibility'] ) ) : '';

			/* Delete "Notification" post */
			if ( 'delete_notification' === $operation_type && ! empty( $notification_id ) ) {
				$this->delete_notification( $notification_id );
			}

			if ( 'delete_message_template' === $operation_type && ! empty( $message_template_id ) ) {
				$this->delete_message_template( $message_template_id );

				if ( 'whatsapp' === $sending_type ) {
					if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
						require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
					}

					$whatsapp = new ZWORKFLOWMANAGER_Whatsapp();
					$whatsapp->delete_template( $whatsapp_template_id, $template_name );
				}
			}

			/* Delete "order status" post */
			if ( 'delete_order_status' === $operation_type && ! empty( $order_status_id ) ) {
				$this->delete_order_status( $order_status_id );
			}

			/* Delete Scheduled earlie "SEND" post */
			if ( 'delete_send' === $operation_type && ! empty( $send_id ) ) {
				wp_delete_post( $send_id );
			}

			/* Triggers backward compatibility */
			if ( 'on' === $backward_compatibility ) {
				$this->start_backward_compatibility();
			}

			/* Include Plugin header for his own pages */
			new ZWORKFLOWMANAGER_Page_Header_Admin();

			/* Add admin notice */
			add_action( 'admin_notices', array( $this, 'show_success_notice' ) );
			add_action( 'admin_notices', array( $this, 'show_error_notice' ) );

			if ( get_option( 'zworkflowmanager_backward' ) ) {
				add_action( 'admin_notices', array( $this, 'show_backward_compatibility_notice' ) );
			}

			/* Checking the correct connection to the service Twilio */
			if ( 'check_connection' === $operation_type ) {
				$this->check_connection_with_twilio();
			}

			/* Checking the correct connection to the service Twilio */
			if ( 'check_connection_whatsapp' === $operation_type ) {
				$this->check_connection_with_whatsapp();
			}

			/* Clear log file Connection */
			if ( 'clear-log-connection' === $operation_type ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
						require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
				}
				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger::clear_logs( true );
			}

			/* Clear main log file */
			if ( 'clear-log' === $operation_type ) {
				if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
						require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
				}
				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger::clear_logs();
			}
		}

		/* Init own Cron job */
		$this->send_message_from_cron();

	}

	/**
	 * Show backward compatibility notice
	 */
	public function show_backward_compatibility_notice() {
		$class              = 'notice notice-info is-dismissible zworkflowmanager-backward-compatibility';
		$backward_url       = '?page=wc-workflows&tab=dashboard&backward_compatibility=on';
		$backward_nonce_url = wp_nonce_url( $backward_url, 'zfn_operation_type', 'zwf_nonce' );
		echo wp_kses_post(
			"<div class='$class'>
            <h4>Flow Notify notifications require template update</h4>
            <p>Important: Flow Notify has new template functionality to build better notifications. To support existing notifications an update is required to the new templates. Notifications paused until templates are created.</p>
            <a href='$backward_nonce_url' class='button button-primary'>Create Templates and update notifications</a>
        </div>"
		);
	}

	/**
	 * Start backward compatibility
	 */
	public function start_backward_compatibility() {
		$args = array(
			'post_type'      => 'zworkflowemail',
			'posts_per_page' => -1,
		);

		$notifications = get_posts( $args );

		if ( $notifications ) {
			foreach ( $notifications as $notification ) {
				$notification_id    = $notification->ID;
				$notification_title = $notification->post_title;

				$status = new ZWORKFLOWMANAGER_Order_Status( $notification_id );

				$template_message_id = wp_insert_post(
					array(
						'post_title'  => $notification_title,
						'post_type'   => 'zworkflowtemplates',
						'post_status' => 'publish',
						'meta_input'  => array(
							'zmessagetemplate_type'        => get_post_meta( $notification_id, 'zcustomemail_type', true ),
							'zsending_type'                => get_post_meta( $notification_id, 'zsending_type', true ),
							'zmessagetemplate_subject'     => get_post_meta( $notification_id, 'zcustomemail_subject', true ),
							'zmessagetemplate_description' => $status->get_description(),
							'zmessagetemplate_status'      => 'enabled',
						),
					)
				);

				if ( $template_message_id ) {
					update_post_meta( $notification_id, 'message_template_id', $template_message_id );
				}
			}
		}
		delete_option( 'zworkflowmanager_backward' );
	}

	/**
	 * Delete provided notification
	 *
	 * @param string $notification_id notification_id.
	 */
	public function delete_notification( $notification_id ) {
		wp_delete_post( $notification_id );
		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails' ) );
		exit;
	}

	/**
	 * Delete message template
	 *
	 * @param string $message_template_id message_template_id.
	 */
	public function delete_message_template( $message_template_id ) {
		wp_delete_post( $message_template_id );
		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=emails&section=message-templates' ) );
	}

	/**
	 * Delete provided order status
	 *
	 * @param string $order_status_id order_status_id.
	 */
	public function delete_order_status( $order_status_id ) {
		wp_delete_post( $order_status_id );
		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=order_status' ) );
		exit;
	}

	/**
	 * Try connecting to the Twilio service to make sure all credentials are correct.
	 */
	public function check_connection_with_twilio() {

		/* Try to set up connection with Twilio service */
		$connection_status = $this->twilio_sending_sms_to_customer( null, 'Test Connection with Twilio', true );

		if ( isset( $connection_status['success'] ) ) {
			/* Force show notice after page will be reloaded */
			update_option( 'twilio_connection', true );

			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection' ) );
			exit;
		}

		/* ↓↓↓↓ Connection wasn't successfully established ↓↓↓↓ */

		/* Update Twilio connection status */
		update_option( 'twilio_connection', false );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-error-notice-panel', $connection_status['error'], 5 );

		if ( isset( $connection_status['error'] ) ) {
			if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
			}

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( $connection_status['error'], true );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection' ) );
		exit;
	}

	/**
	 * Check connection with whatsapp
	 */
	public function check_connection_with_whatsapp() {
		$existing_whatsapp_settings   = get_option( 'whatsapp_settings' );
		$access_token                 = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_token'] : $existing_whatsapp_settings['whatsapp_token_test'];
		$whatsapp_business_account_id = ( $existing_whatsapp_settings['whatsapp_account_credentials'] ) ? $existing_whatsapp_settings['whatsapp_business_account_id'] : $existing_whatsapp_settings['whatsapp_business_account_id_test'];
		$link                         = "https://graph.facebook.com/v16.0/{$whatsapp_business_account_id}?access_token={$access_token}";
		$request                      = wp_remote_request( $link );

		$result = json_decode( $request['body'], true );

		if ( isset( $result['id'] ) ) {
			update_option( 'whatsapp_connection', true );

			wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection&section=whatsapp' ) );
			exit;
		}

		update_option( 'whatsapp_connection', false );

		set_transient( 'fx-admin-error-notice-panel', $result['error']['message'], 5 );

		if ( isset( $result['error']['message'] ) ) {
			if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
					require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
			}

				$logger = new ZWORKFLOWMANAGER_Logger();
				$logger->log( $result['error']['message'], true );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection&section=whatsapp' ) );
		exit;

	}

	/**
	 * CRON sending scheduled SEND actions
	 */
	public function send_message_from_cron() {
		$all_scheduled = $this->select_user_by_time();

		if ( is_array( $all_scheduled ) ) {

			foreach ( $all_scheduled as $key => $item ) {
				if ( $item['whatsapp'] ) {
					$status_send = new ZWORKFLOWMANAGER_Send( 1 );
					foreach ( $status_send->get_notification() as $item_notification ) {
						if ( $item['notification'] === $item_notification['post_title'] ) {
							$message_template_id = $item_notification['message_template_id'];
							$template_name       = get_post_meta( $message_template_id, 'zmessagetemplate_name', true );
							$template_lang       = get_post_meta( $message_template_id, 'zmessagetemplate_language', true );
						}
					}
				}
				$array_contact[0] = array(
					'sms'           => $item['sms'],
					'email'         => $item['email'],
					'whatsapp'      => $item['whatsapp'],
					'description'   => $item['description'],
					'post_id'       => $key,
					'notification'  => $item['notification'],
					'template_name' => isset( $template_name ) ? $template_name : '',
					'template_lang' => isset( $template_lang ) ? $template_lang : '',
				);
				$users            = $item['users'];

				if ( 'include_data' === $item['woo_commerce_data'] ) {

					if ( is_array( $users ) ) {

						foreach ( $users as $user_id ) {
							$user_id = ( is_string( $user_id ) ) ? explode( ',', $user_id )[2] : $user_id['ID'];

							$orders_id = ( 'last_order_placed' === $item['woo_commerce_orders'] ) ? $this->get_last_order_id( $user_id ) : $this->get_all_order_id( $user_id );

							foreach ( $orders_id as $id ) {
								$user  = $this->get_customer_users( $user_id );
								$order = new WC_Order( $id );

								$array_contact[0]['whatsapp_phone'] = $order->get_meta( 'billing_whatsapp_phone' );

								$this->send_from_admin( $user, null, $array_contact, null, $id );
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Select user from db
	 * By timestamp
	 *
	 * @return array
	 */
	public function select_user_by_time() {
		global $wpdb;
		$current_timestamp = time();
		$result_query      = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT a.ID AS id_post,
                   m3.meta_value AS users ,
                   m4.meta_value AS sms,
                   m5.meta_value AS email,
                   m6.meta_value AS whatsapp,
                   m7.meta_value AS description,
                   m8.meta_value AS notification,
                   m9.meta_value AS wooCommerceOrders,
                   m10.meta_value AS wooCommerceData
                FROM $wpdb->posts a LEFT JOIN $wpdb->postmeta m1 ON a.ID = m1.post_id
                LEFT JOIN $wpdb->postmeta m2 ON a.ID = m2.post_id
                LEFT JOIN $wpdb->postmeta m3 ON a.ID = m3.post_id
                LEFT JOIN $wpdb->postmeta m4 ON a.ID = m4.post_id
                LEFT JOIN $wpdb->postmeta m5 ON a.ID = m5.post_id
                LEFT JOIN $wpdb->postmeta m6 ON a.ID = m6.post_id
                LEFT JOIN $wpdb->postmeta m7 ON a.ID = m7.post_id
                LEFT JOIN $wpdb->postmeta m8 ON a.ID = m8.post_id
                LEFT JOIN $wpdb->postmeta m9 ON a.ID = m9.post_id
                LEFT JOIN $wpdb->postmeta m10 ON a.ID = m10.post_id
                WHERE m1.meta_key = %s
                  AND m1.meta_value = %s
                  AND m2.meta_key = %s
                  AND m2.meta_value < %d
                  AND m3.meta_key = %s
                  AND m4.meta_key = %s
                  AND m5.meta_key = %s
                  AND m6.meta_key = %s
                  AND m7.meta_key = %s
                  AND m8.meta_key = %s
                  AND m9.meta_key = %s
                  AND m10.meta_key = %s;
                ",
				'send_status',
				'Scheduled',
				'timestamp_chedule',
				$current_timestamp,
				'user_recipient',
				'SMS',
				'email',
				'whatsapp',
				'description',
				'notification',
				'wooCommerceOrders',
				'wooCommerceData'
			)
		);

		$all_scheduled = array();

		foreach ( $result_query as $val ) {
			$array_user_data = array();
			$unserialize     = unserialize( $val->users );

			if ( is_array( $unserialize ) ) {
				foreach ( $unserialize as $item ) {
					array_push( $array_user_data, $item );
				}
				$all_scheduled[ $val->id_post ]['sms']                 = $val->sms;
				$all_scheduled[ $val->id_post ]['email']               = $val->email;
				$all_scheduled[ $val->id_post ]['whatsapp']            = $val->whatsapp;
				$all_scheduled[ $val->id_post ]['description']         = $val->description;
				$all_scheduled[ $val->id_post ]['notification']        = $val->notification;
				$all_scheduled[ $val->id_post ]['woo_commerce_orders'] = $val->wooCommerceOrders;
				$all_scheduled[ $val->id_post ]['woo_commerce_data']   = $val->wooCommerceData;
				$all_scheduled[ $val->id_post ]['users']               = $array_user_data;
			}
		}

		return $all_scheduled;
	}

	/**
	 * Load resources
	 */
	public function load_resources() {

		wp_enqueue_style( 'jquery-ui-datepicker-style', '//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css', array(), '1.0.0' );
		wp_enqueue_style( 'wp-color-picker' );

		wp_enqueue_style( 'styles', plugins_url( 'assets/styles/app.css', ZWORKFLOWMANAGER_BASE_FILE ), array(), '1.0.0' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'chart', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js', array(), '1.0.0', true );

		wp_enqueue_script( 'libs_js', plugins_url( 'assets/js/libsApp.js', ZWORKFLOWMANAGER_BASE_FILE ), array( 'jquery' ), '1.0.0', true );
		wp_enqueue_script( 'main_js', plugins_url( 'assets/js/app.js', ZWORKFLOWMANAGER_BASE_FILE ), array( 'jquery', 'wp-color-picker' ), '1.0.0', true );

		$ajax_order_statuses        = wc_get_order_statuses();
		$ajax_order_statuses['any'] = 'Any';
		ksort( $ajax_order_statuses );
		$zwf_dashboard = new ZWORKFLOWMANAGER_Dashboard();

		if ( isset( $_GET['user_id'] ) ) {
			$user_id = sanitize_text_field( wp_unslash( $_GET['user_id'] ) );
		} else {
			$user_id = get_current_user_id();
		}

		$whatsapp_country    = ( get_user_meta( $user_id, 'zworkflow_whatsapp_country', true ) ) ? get_user_meta( $user_id, 'zworkflow_whatsapp_country', true ) : '';
		$billing_country     = ( get_user_meta( $user_id, 'zworkflow_billing_country', true ) ) ? get_user_meta( $user_id, 'zworkflow_billing_country', true ) : '';
		$default_country_iso = ( isset( get_option( 'notification_email_settings' )['default_code'] ) ) ? get_option( 'notification_email_settings' )['default_code'] : 'US';

		wp_localize_script(
			'main_js',
			'ajax_object',
			array(
				'ajax_url'                 => admin_url( 'admin-ajax.php' ),
				'we_value'                 => 1234,
				'order_statuses'           => $ajax_order_statuses,
				'get_send_posts_from_data' => $zwf_dashboard->get_send_posts_from_data(),
				'intl_utils'               => plugins_url( 'assets/js/utils.js', ZWORKFLOWMANAGER_BASE_FILE ),
				'whatsapp_country'         => $whatsapp_country,
				'billing_country'          => $billing_country,
				'default_country_iso'      => $default_country_iso,

			)
		);

		$this->update_icon_options();
	}

	/**
	 * Update icon options
	 */
	public function update_icon_options() {
		/* Dashicons, included in WP */
		$options = array();
		$glyphs  = $this->extract_icon_glyphs( ABSPATH . WPINC . '/css/dashicons.css', 'dashicons' );

		foreach ( $glyphs as $class => $glyph ) {
			/* prepend each icon class with the generic `dashicons` class */
			$options[ 'dashicons ' . $class ] = $glyph;
		}

		/* update the option, specifying autoload=no */
		delete_option( 'zworkflowmanager_icons' );
		add_option( 'zworkflowmanager_icons', $options, '', 'no' );
	}

	/**
	 * Extract icon glyphs
	 *
	 * @param string $path path.
	 * @param string $class_prefix class_prefix.
	 *
	 * @return array
	 */
	public function extract_icon_glyphs( $path, $class_prefix ) {
		$css = file_get_contents( $path );

		$class_pattern = '/(?<=\.)(?<class>' . $class_prefix . '[-\w]+)(?::before\s*{\s*content:\s*")(?<glyph>\\\\\w+)(?=")/';

		$matches = array();
		$results = array();

		preg_match_all( $class_pattern, $css, $matches );

		/* Restructure matches into an associative array like $class => $glyph */
		if ( ! empty( $matches ) && isset( $matches['class'] ) && ! empty( $matches['class'] ) ) {
			foreach ( $matches['class'] as $key => $class ) {
				$results[ $class ] = $matches['glyph'][ $key ];
			}
		}

		return $results;
	}

	/**
	 * Wc notice dismissed
	 */
	public function zworkflowmanager_wc_notice_dismissed() {
		$current_user_id = get_current_user_id();
		update_option( 'zworkflowmanager_wc_notice_' . $current_user_id, time() );
	}

	/**
	 * Show admin notice when some changes were made in plugin setting page
	 */
	public function show_success_notice() {
		/* Check transient, if available display notice */
		if ( get_transient( 'fx-admin-notice-panel' ) ) {

			$messages = get_transient( 'fx-admin-notice-panel-status' );

			?>
			<div class="updated notice is-dismissible<?php echo ( 'Scheduled' === $messages || 'Edit_Scheduled' === $messages || 'Instant' === $messages ) ? ' send-notice' : ''; ?>">
				<p class="p">
					<?php
					if ( $messages ) {
						if ( 'Edit_Scheduled' === $messages ) {
							esc_html_e( 'Message Scheduled', 'flow_notify_text' );
							?>
							<a href="admin.php?page=wc-workflows&amp;tab=activities" class="view-activity">View Activity</a>
							<?php
						} elseif ( 'Instant' === $messages ) {
							esc_html_e( 'Message Sent', 'flow_notify_text' );
							?>
							<a href="admin.php?page=wc-workflows&amp;tab=activities" class="view-activity">View Activity</a>
							<?php
						} elseif ( 'Scheduled' === $messages ) {
							esc_html_e( 'Message Scheduled', 'flow_notify_text' );
							?>
							<a href="admin.php?page=wc-workflows&amp;tab=activities" class="view-activity">View Activity</a>
							<?php
						} elseif ( 'Edit_whatsapp_template' === $messages ) {
							esc_html_e( 'Your template has been sent for approval', 'flow_notify_text' );
							?>
							<?php
						} else {
							esc_html_e( 'Message notification has been scheduled to send.', 'flow_notify_text' );
						}
					} else {
						esc_html_e( 'Your settings have been saved.', 'flow_notify_text' );
					}
					?>
				</p>
			</div>
			<?php
			/* Delete transient, only display this notice once. */
			delete_transient( 'fx-admin-notice-panel' );
			delete_transient( 'fx-admin-notice-panel-status' );
		}
	}

	/**
	 * Show admin notice when something go wrong
	 */
	public function show_error_notice() {

		/* Check transient, if available display notice */
		$error_notice = get_transient( 'fx-admin-error-notice-panel' );

		if ( $error_notice ) {
			?>
			<div class="notice notice-error is-dismissible">
				<p class="p"><?php echo esc_textarea( $error_notice ); ?></p>
			</div>
			<?php
			/* Delete transient, only display this notice once. */
			delete_transient( 'fx-admin-error-notice-panel' );
		}
	}

	/**
	 * Save Twilio page settings
	 */
	public function zwf_twilio_gateway_save_changes() {
		/* Getting Last updated settings */
		$existing_twilio_settings = get_option( 'twilio_settings' );
		$encoded_account_sid      = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_twilio_settings['account_sid'], 0, - 5, '*' );
		$encoded_account_sid_test = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_twilio_settings['account_sid_test'], 0, - 5, '*' );
		$encoded_auth_token       = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_twilio_settings['auth_token'], 0, - 5, '*' );
		$encoded_auth_token_test  = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_twilio_settings['auth_token_test'], 0, - 5, '*' );

		$account_sid       = filter_input( INPUT_POST, 'account-sid', FILTER_SANITIZE_STRING );
		$account_sid_value = filter_input( INPUT_POST, 'account-sid-value', FILTER_SANITIZE_STRING );
		$account_sid       = ( $encoded_account_sid === $account_sid ) ? $account_sid_value : $account_sid;

		$account_sid_test       = filter_input( INPUT_POST, 'account-sid-test', FILTER_SANITIZE_STRING );
		$account_sid_test_value = filter_input( INPUT_POST, 'account-sid-test-value', FILTER_SANITIZE_STRING );
		$account_sid_test       = ( $encoded_account_sid_test === $account_sid_test ) ? $account_sid_test_value : $account_sid_test;

		$auth_token       = filter_input( INPUT_POST, 'auth-token', FILTER_SANITIZE_STRING );
		$auth_token_value = filter_input( INPUT_POST, 'auth-token-value', FILTER_SANITIZE_STRING );
		$auth_token       = ( $encoded_auth_token === $auth_token ) ? $auth_token_value : $auth_token;

		$auth_token_test       = filter_input( INPUT_POST, 'auth-token-test', FILTER_SANITIZE_STRING );
		$auth_token_test_value = filter_input( INPUT_POST, 'auth-token-test-value', FILTER_SANITIZE_STRING );
		$auth_token_test       = ( $encoded_auth_token_test === $auth_token_test ) ? $auth_token_test_value : $auth_token_test;

		$from_number               = filter_input( INPUT_POST, 'from-number', FILTER_SANITIZE_STRING );
		$from_number_test          = filter_input( INPUT_POST, 'from-number-test', FILTER_SANITIZE_STRING );
		$to_number                 = filter_input( INPUT_POST, 'to-number', FILTER_SANITIZE_STRING );
		$to_number_test            = filter_input( INPUT_POST, 'to-number-test', FILTER_SANITIZE_STRING );
		$account_credentials       = filter_input( INPUT_POST, 'account_credentials', FILTER_SANITIZE_STRING );
		$status_return_sms_message = filter_input( INPUT_POST, 'status_return_sms_message', FILTER_SANITIZE_STRING );
		$response_message          = filter_input( INPUT_POST, 'response_message', FILTER_SANITIZE_STRING );
		$status_sender_id          = filter_input( INPUT_POST, 'status_sender_id', FILTER_SANITIZE_STRING );
		$sender_id                 = filter_input( INPUT_POST, 'sender_id', FILTER_SANITIZE_STRING );
		$concatenate_messages      = filter_input( INPUT_POST, 'concatenate_messages', FILTER_SANITIZE_STRING );

		/* Try to define that user changed encoded string (****) with new values */
		$star_pos_in_sid        = strpos( $account_sid, '*****' );
		$star_pos_in_sid_test   = strpos( $account_sid_test, '*****' );
		$star_pos_in_token      = strpos( $auth_token, '*****' );
		$star_pos_in_token_test = strpos( $auth_token_test, '*****' );

		/* Allow to save if normal(new) value was entered */
		if ( ! $star_pos_in_sid ) {
			$existing_twilio_settings['account_sid'] = $account_sid;
		}
		if ( ! $star_pos_in_sid_test ) {
			$existing_twilio_settings['account_sid_test'] = $account_sid_test;
		}

		/* Allow to save if normal(new) value was entered */
		if ( ! $star_pos_in_token ) {
			$existing_twilio_settings['auth_token'] = $auth_token;
		}
		if ( ! $star_pos_in_token_test ) {
			$existing_twilio_settings['auth_token_test'] = $auth_token_test;
		}

		/* Prepared for store account phone number ( this phone will be used as "From" ) */
		$existing_twilio_settings['from_number']      = $from_number;
		$existing_twilio_settings['from_number_test'] = $from_number_test;

		/* Prepared for store account test phone number ( this phone will be used for test as "To" ) */
		$existing_twilio_settings['to_number']      = $to_number;
		$existing_twilio_settings['to_number_test'] = $to_number_test;

		/* Save account credentials */
		$existing_twilio_settings['account_credentials'] = $account_credentials;

		/* Save status return sms message */
		$existing_twilio_settings['status_return_sms_message'] = $status_return_sms_message;

		/* Save return sms message */
		$existing_twilio_settings['response_message'] = $response_message;

		/* Save status sender id */
		$existing_twilio_settings['status_sender_id'] = $status_sender_id;

		/* Save sender id */
		$existing_twilio_settings['sender_id'] = $sender_id;

		/* Save concatenate messages */
		$existing_twilio_settings['concatenate_messages'] = $concatenate_messages;

		/* Save changes in DB */
		update_option( 'twilio_settings', $existing_twilio_settings );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection' ) );
		exit;
	}

	/**
	 * Save WhatsApp page settings
	 */
	public function zwf_whatsapp_gateway_save_changes() {
		/* Getting Last updated settings */
		$existing_whatsapp_settings                = get_option( 'whatsapp_settings' );
		$encoded_whatsapp_phone_id                 = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_phone_id'], 0, - 5, '*' );
		$encoded_whatsapp_phone_id_test            = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_phone_id_test'], 0, - 5, '*' );
		$encoded_whatsapp_token                    = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_token'], 0, - 5, '*' );
		$encoded_whatsapp_token_test               = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_token_test'], 0, - 5, '*' );
		$encoded_whatsapp_business_account_id      = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_business_account_id'], 0, - 5, '*' );
		$encoded_whatsapp_business_account_id_test = ZWORKFLOWMANAGER_Core::character_string_replacer( $existing_whatsapp_settings['whatsapp_business_account_id_test'], 0, - 5, '*' );

		$whatsapp_account_credentials = filter_input( INPUT_POST, 'whatsapp_account_credentials', FILTER_SANITIZE_STRING );

		$whatsapp_phone_id       = filter_input( INPUT_POST, 'whatsapp-phone-id', FILTER_SANITIZE_STRING );
		$whatsapp_phone_id_value = filter_input( INPUT_POST, 'whatsapp-phone-id-value', FILTER_SANITIZE_STRING );
		$whatsapp_phone_id       = ( $encoded_whatsapp_phone_id === $whatsapp_phone_id ) ? $whatsapp_phone_id_value : $whatsapp_phone_id;

		$whatsapp_phone_id_test       = filter_input( INPUT_POST, 'whatsapp-phone-id-test', FILTER_SANITIZE_STRING );
		$whatsapp_phone_id_value_test = filter_input( INPUT_POST, 'whatsapp-phone-id-test-value', FILTER_SANITIZE_STRING );
		$whatsapp_phone_id_test       = ( $encoded_whatsapp_phone_id_test === $whatsapp_phone_id_test ) ? $whatsapp_phone_id_value_test : $whatsapp_phone_id_test;

		$whatsapp_token       = filter_input( INPUT_POST, 'whatsapp-token', FILTER_SANITIZE_STRING );
		$whatsapp_token_value = filter_input( INPUT_POST, 'whatsapp-token-value', FILTER_SANITIZE_STRING );
		$whatsapp_token       = ( $encoded_whatsapp_token === $whatsapp_token ) ? $whatsapp_token_value : $whatsapp_token;

		$whatsapp_token_test       = filter_input( INPUT_POST, 'whatsapp-token-test', FILTER_SANITIZE_STRING );
		$whatsapp_token_value_test = filter_input( INPUT_POST, 'whatsapp-token-test-value', FILTER_SANITIZE_STRING );
		$whatsapp_token_test       = ( $encoded_whatsapp_token_test === $whatsapp_token_test ) ? $whatsapp_token_value_test : $whatsapp_token_test;

		$whatsapp_business_account_id       = filter_input( INPUT_POST, 'whatsapp-business-account-id', FILTER_SANITIZE_STRING );
		$whatsapp_business_account_id_value = filter_input( INPUT_POST, 'whatsapp-business-account-id-value', FILTER_SANITIZE_STRING );
		$whatsapp_business_account_id       = ( $encoded_whatsapp_business_account_id === $whatsapp_business_account_id ) ? $whatsapp_business_account_id_value : $whatsapp_business_account_id;

		$whatsapp_business_account_id_test       = filter_input( INPUT_POST, 'whatsapp-business-account-id-test', FILTER_SANITIZE_STRING );
		$whatsapp_business_account_id_value_test = filter_input( INPUT_POST, 'whatsapp-business-account-id-test-value', FILTER_SANITIZE_STRING );
		$whatsapp_business_account_id_test       = ( $encoded_whatsapp_business_account_id_test === $whatsapp_business_account_id_test ) ? $whatsapp_business_account_id_value_test : $whatsapp_business_account_id_test;

		$star_pos_phone_id            = strpos( $whatsapp_phone_id, '*****' );
		$star_pos_token               = strpos( $whatsapp_token, '*****' );
		$star_pos_business_account_id = strpos( $whatsapp_business_account_id, '*****' );

		$star_pos_phone_id_test            = strpos( $whatsapp_phone_id_test, '*****' );
		$star_pos_token_test               = strpos( $whatsapp_token_test, '*****' );
		$star_pos_business_account_id_test = strpos( $whatsapp_business_account_id_test, '*****' );

		/* Allow to save if normal(new) value was entered */
		if ( ! $star_pos_phone_id ) {
			$existing_whatsapp_settings['whatsapp_phone_id'] = $whatsapp_phone_id;
		}

		if ( ! $star_pos_token ) {
			$existing_whatsapp_settings['whatsapp_token'] = $whatsapp_token;
		}

		if ( ! $star_pos_business_account_id ) {
			$existing_whatsapp_settings['whatsapp_business_account_id'] = $whatsapp_business_account_id;
		}

		if ( ! $star_pos_phone_id_test ) {
			$existing_whatsapp_settings['whatsapp_phone_id_test'] = $whatsapp_phone_id_test;
		}

		if ( ! $star_pos_token_test ) {
			$existing_whatsapp_settings['whatsapp_token_test'] = $whatsapp_token_test;
		}

		if ( ! $star_pos_business_account_id_test ) {
			$existing_whatsapp_settings['whatsapp_business_account_id_test'] = $whatsapp_business_account_id_test;
		}

		$existing_whatsapp_settings['whatsapp_account_credentials'] = $whatsapp_account_credentials;

		/* Save changes in DB */
		update_option( 'whatsapp_settings', $existing_whatsapp_settings );

		/* Force show notice after page will be reloaded */
		set_transient( 'fx-admin-notice-panel', true, 5 );

		wp_safe_redirect( admin_url( 'admin.php?page=wc-workflows&tab=connection&section=whatsapp' ) );
		exit;
	}

	/**
	 * Making sending test SMS message
	 */
	public function twilio_test_message() {
		/* check if it's ajax request (simple defence) */
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {

			$phone = filter_input( INPUT_POST, 'phone_to_test_msg', FILTER_SANITIZE_STRING );

			/* Making SMS sending */
			$result = $this->twilio_sending_sms_to_customer( $phone );

			/* Sending error result to js code */
			if ( isset( $result['error'] ) ) {
				wp_send_json_error( $result['error'] );
			}

			/* Sending success result to js code */
			if ( isset( $result['success'] ) ) {
				wp_send_json_success( $result['success'] );
			}
		}

		die;
	}

	/**
	 * Making Quick sending SMS message to provided phone number
	 */
	public function twilio_quick_send() {
		/* check if it's ajax request (simple defence) */
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {

			$phone = filter_input( INPUT_POST, 'quick_send', FILTER_SANITIZE_STRING );
			$text  = filter_input( INPUT_POST, 'zwf-test-twilio-text', FILTER_SANITIZE_STRING );

			/* Making SMS sending */
			$result = $this->twilio_sending_sms_to_customer( $phone, $text );

			/* Sending error result to js code */
			if ( isset( $result['error'] ) ) {
				wp_send_json_error( $result['error'] );
			}

			/* Sending success result to js code */
			if ( isset( $result['success'] ) ) {
				wp_send_json_success( $result['success'] );
			}
		}

		die;
	}

	/**
	 * Sending a notification if the status of the order and the notification match
	 *
	 * @param string $order_id order_id.
	 * @param string $old_status old_status.
	 * @param string $new_status new_status.
	 */
	public function so_order_status_changed( $order_id, $old_status, $new_status ) {
		$data                            = array();
		$order                           = wc_get_order( $order_id );
		$communication_preference_method = $order->get_meta( 'communication_preference' );
		$users                           = array( $order->get_billing_email() . ',' . $order->get_billing_phone() );
		$value                           = array( $old_status . '_to_' . $new_status, 'any_to_' . $new_status, $old_status . '_to_any', 'any_to_any' );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'zcustomemail_dispatch_list',
					'value'   => $value,
					'compare' => 'IN',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {

				$type_preference_status_toggle = get_post_meta( $current_post->ID, 'type_preference_status_toggle' )[0];
				$zsending_type                 = ( $communication_preference_method && 'enabled' === $type_preference_status_toggle )
					? $communication_preference_method : get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id           = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'zsending_type'   => $zsending_type,
						'notification_id' => $current_post->ID,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => ( 'billing' === $order->get_meta( 'zworkflow_select_phone_type' ) ) ? $order->get_meta( 'zworkflow_billing_code' ) . $order->get_billing_phone() : $order->get_meta( 'billing_whatsapp_phone' ),
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $order->get_billing_phone(),
						'notification_email'  => $order->get_billing_email(),
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				),
				false,
				false
			);

			$item['post_id'] = $send_post_id;
		}

		return $this->send_from_admin( $users, null, $data, null, $order_id );
	}

	/**
	 * Sending notification when order creating
	 *
	 * @param string $order_id order_id.
	 *
	 * @return array|string[]
	 */
	public function so_order_created( $order_id ) {

		$data                            = array();
		$order                           = wc_get_order( $order_id );
		$communication_preference_method = $order->get_meta( 'communication_preference' );
		$users                           = array( $order->get_billing_email() . ',' . $order->get_billing_phone() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'order_created',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$type_preference_status_toggle = get_post_meta( $current_post->ID, 'type_preference_status_toggle' )[0];
				$zsending_type                 = ( $communication_preference_method && 'enabled' === $type_preference_status_toggle )
					? $communication_preference_method : get_post_meta( $current_post->ID, 'zsending_type' )[0];
				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $order->get_billing_phone(),
						'notification_email'  => $order->get_billing_email(),
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				),
				false,
				false
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $users, null, $data, null, $order_id );
	}

	/**
	 * Sending notification when order is paid
	 *
	 * @param string $order_id order_id.
	 *
	 * @return array|string[]
	 */
	public function so_order_paid( $order_id ) {

		$data                            = array();
		$order                           = wc_get_order( $order_id );
		$communication_preference_method = $order->get_meta( 'communication_preference' );
		$users                           = array( $order->get_billing_email() . ',' . $order->get_billing_phone() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'order_paid',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$type_preference_status_toggle = get_post_meta( $current_post->ID, 'type_preference_status_toggle' )[0];
				$zsending_type                 = ( $communication_preference_method && 'enabled' === $type_preference_status_toggle )
					? $communication_preference_method : get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id           = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => ( 'billing' === $order->get_meta( 'zworkflow_select_phone_type' ) ) ? $order->get_meta( 'zworkflow_billing_code' ) . $order->get_billing_phone() : $order->get_meta( 'billing_whatsapp_phone' ),
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id    = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $order->get_billing_phone(),
						'notification_email'  => $order->get_billing_email(),
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);
			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $users, null, $data, null, $order_id );

	}

	/**
	 * Sending notification when a customers total completed order amount reaches, the defined amount
	 *
	 * @param string $order_id order_id.
	 *
	 * @return array|string[]
	 */
	public function order_total_reaches( $order_id ) {
		global $wpdb;

		$data      = array();
		$total_sum = 0;
		$email     = get_bloginfo( 'admin_email' );
		$admin     = get_user_by( 'email', $email );

		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $email . ',' . $phone );

		$results = array_map(
			'unserialize',
			array_unique(
				array_map(
					'serialize',
					$wpdb->get_col(
						"
            SELECT ID FROM $wpdb->posts INNER JOIN $wpdb->postmeta
            ON $wpdb->posts.ID = $wpdb->postmeta.post_id
            WHERE $wpdb->posts.post_type LIKE 'shop_order'
            AND $wpdb->posts.post_status LIKE 'wc-completed'
        "
					)
				)
			)
		);

		foreach ( $results as $order_id ) {
			$order      = wc_get_order( $order_id );
			$total_sum += (int) $order->get_total();
		}

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_order_total_reaches',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$total_spend   = get_post_meta( $current_post->ID, 'total_spend' )[0];
				$zsending_type = get_post_meta( $current_post->ID, 'zsending_type' )[0];

				if ( (int) $total_sum < (int) $total_spend ) {
					return $data;
				}

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id    = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);
			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $admin_contacts, null, $data, null );
	}

	/**
	 * Sending notification when user created
	 *
	 * @param string $user_id user_id.
	 *
	 * @return array|string[]
	 */
	public function so_user_registered( $user_id ) {

		$data  = array();
		$email = get_bloginfo( 'admin_email' );
		$admin = get_user_by( 'email', $email );
		$user  = get_user_by( 'ID', $user_id );

		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $email . ',' . $phone );

		$user_roles = $user->roles[0];

		if ( 'customer' !== $user_roles ) {
			return $data;
		}

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_account_created',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type       = get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => get_user_meta( $user_id, 'whatsapp_phone', true ),
					)
				);
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $admin_contacts, null, $data, null );
	}

	/**
	 * Sending notification when user Opted In
	 *
	 * @param string $user_id user_id.
	 *
	 * @return array|string[]
	 */
	public function so_user_opted_in( $user_id ) {

		$data  = array();
		$email = get_bloginfo( 'admin_email' );
		$admin = get_user_by( 'email', $email );
		$user  = get_user_by( 'ID', $user_id );

		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $email . ',' . $phone );

		$user_roles            = $user->roles[0];
		$all_notifications     = get_user_meta( $user_id, 'all_notifications' )[0];
		$product_notifications = get_user_meta( $user_id, 'product_notifications' )[0];

		if ( ( ! $all_notifications || ! $product_notifications ) && 'customer' !== $user_roles ) {
			return $data;
		}

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_opted_in',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type       = get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => get_user_meta( $user_id, 'whatsapp_phone', true ),
					)
				);
			}
		}

		/*Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $admin_contacts, null, $data, null );

	}

	/**
	 * Sending notification when user Opted Out
	 *
	 * @param string $user_id user_id.
	 *
	 * @return array|string[]
	 */
	public function so_user_opted_out( $user_id ) {

		$data  = array();
		$email = get_bloginfo( 'admin_email' );
		$admin = get_user_by( 'email', $email );
		$user  = get_user_by( 'ID', $user_id );

		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $email . ',' . $phone );

		$user_roles            = $user->roles[0];
		$all_notifications     = get_user_meta( $user_id, 'all_notifications' )[0];
		$product_notifications = get_user_meta( $user_id, 'product_notifications' )[0];

		if ( ( $all_notifications || $product_notifications ) && 'customer' !== $user_roles ) {
			return $data;
		}

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'customer_opted_out',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type       = get_post_meta( $current_post->ID, 'zsending_type' )[0];
				$message_template_id = get_post_meta( $current_post->ID, 'message_template_id', true );

				array_push(
					$data,
					array(
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $message_template_id, 'zmessagetemplate_description', true ),
						'subject'         => get_post_meta( $message_template_id, 'zmessagetemplate_subject', true ),
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
						'template_name'   => get_post_meta( $message_template_id, 'zmessagetemplate_name', true ),
						'template_lang'   => get_post_meta( $message_template_id, 'zmessagetemplate_language', true ),
						'whatsapp_phone'  => get_user_meta( $user_id, 'whatsapp_phone', true ),
					)
				);
			}
		}

		/*Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);

			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $admin_contacts, null, $data, null );

	}

	/**
	 * This trigger occurs when a new guest is captured
	 *
	 * @return array|string[]
	 */
	public function new_guest_capture_action() {

		$user_email     = filter_input( INPUT_POST, 'email', FILTER_SANITIZE_STRING );
		$data           = array();
		$admin_email    = get_bloginfo( 'admin_email' );
		$admin          = get_user_by( 'email', $admin_email );
		$phone          = get_user_meta( $admin->ID, 'billing_phone', true );
		$admin_contacts = array( $admin_email . ',' . $phone );
		$users          = get_users();

		foreach ( $users as $user ) {
			if ( $user->user_email === $user_email ) {
				return $data;
			}
		}

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowemail' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'trigger_status',
					'value'   => 'new_guest_capture',
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'zcustomemail_status',
					'value'   => 'enabled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {

			foreach ( $query->get_posts() as $current_post ) {
				$zsending_type = get_post_meta( $current_post->ID, 'zsending_type' )[0];

				array_push(
					$data,
					array(
						'post_id'         => $current_post->ID,
						'sms'             => ( 'SMS' === $zsending_type || 'sms' === $zsending_type ) ? $zsending_type : '',
						'email'           => ( 'email' === $zsending_type ) ? $zsending_type : '',
						'whatsapp'        => ( 'whatsapp' === $zsending_type ) ? $zsending_type : '',
						'description'     => get_post_meta( $current_post->ID, 'order_description' )[0],
						'subject'         => get_post_meta( $current_post->ID, 'zcustomemail_subject' )[0],
						'post_title'      => $current_post->post_title,
						'notification_id' => $current_post->ID,
						'zsending_type'   => $zsending_type,
					)
				);
			}
		}

		/*Restore original Post Data */
		wp_reset_postdata();

		foreach ( $data as &$item ) {
			$send_post_id    = wp_insert_post(
				array(
					'post_title'  => $item['post_title'],
					'post_type'   => 'zworkflowsend',
					'post_status' => 'publish',
					'meta_input'  => array(
						'notification_title'  => $item['post_title'],
						'notification_phone'  => $phone,
						'notification_email'  => $admin_email,
						'notification_type'   => $item['zsending_type'],
						'notification_method' => 'Status Trigger',
						'notification_date'   => current_time( 'timestamp' ),
					),
				)
			);
			$item['post_id'] = $send_post_id;
		}

		$this->send_from_admin( $admin_contacts, null, $data, null );

	}
}

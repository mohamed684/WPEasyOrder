<?php
/**
 * Message Templates Settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}
class ZWORKFLOWMANAGER_Core_Message_Templates extends WP_List_Table {

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'order_email',
				'plural'   => 'order_emails_table',
				'ajax'     => false,
			)
		);
	}

	public function print_overview() {
		$this->prepare_items();
		echo '<div class="zworkflowmanager_overview_wrap" style="width: 95%;">';
		echo '<h2 class="screen-reader-text">Status Emails</h2>';
		if ( count( $this->items ) !== 0 ) {
			$this->display();
		} else {
			echo '<div style=" color:#000; padding:1px 12px; background: #fff; border-left: solid 4px #ffb900;margin-top:20px;">';
			echo '<p style="margin: .5em 0; padding: 2px;">Create message templates</p>';
			echo '</div>';
		}
		echo '</div>';
	}

	public function prepare_items() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( $current_page - 1 ) * $per_page : 0;

		/* Init column headers. */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$results = get_posts(
			array(
				'post_type'   => 'zworkflowtemplates',
				'numberposts' => $per_page,
				'offset'      => $offset,
			)
		);

		$items = array();

		foreach ( $results as $result ) {
			$item['id']              = $result->ID;
			$item['name']            = $result->post_title;
			$item['type']            = get_post_meta( $result->ID, 'zmessagetemplate_type', true );
			$item['sending_type']    = get_post_meta( $result->ID, 'zsending_type', true );
			$item['description']     = get_post_meta( $result->ID, 'zmessagetemplate_description', true );
			$item['status']          = get_post_meta( $result->ID, 'zmessagetemplate_status', true );
			$item['approval_status'] = get_post_meta( $result->ID, 'zapproval_status', true );

			array_push( $items, $item );
		}

		$this->items = $items;

		/* Pagination. */
		$total_results = $this->get_total_number_of_results();

		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	public function get_columns() {
		$columns = array(
			'name'            => 'Name',
			'sending_type'    => 'Type',
			'description'     => 'Message Snippet',
			'approval_status' => 'Approval status',
			'status'          => 'Enabled',
		);

		return $columns;
	}

	public function get_total_number_of_results() {
		$results = get_posts(
			array(
				'post_type'   => 'zworkflowtemplates',
				'numberposts' => - 1,
			)
		);

		return count( $results );
	}

	public function column_default( $result, $column_name ) {
		switch ( $column_name ) {
			case 'name':
				$edit_link = add_query_arg( array( 'edit_template' => $result['id'] ) );
				$label     = __( 'Edit', 'flow_notify_text' );

				return '<div class="zworkflowstatus_entry">
							<a href="' . $edit_link . '">' . $result['name'] . '</a>
							<br/>
							<a href="' . $edit_link . '"
							   class="zworkflowmanager_display_link_on_hover">' . $label . '</a>
						</div>';
			case 'sending_type':
				if ( 'whatsapp' === $result['sending_type'] ) {
					return '<span>WhatsApp</span>';
				} else {
					return '<span>' . ucfirst( $result['sending_type'] ) . '</span>';
				}
			case 'description':
				return '<span>' . $result['description'] . '</span>';

			case 'approval_status':
				if ( 'whatsapp' === $result['sending_type'] ) {
					return '<span class="approov_result approov_result_' . $result['id'] . '">' . $result['approval_status'] . '</span><div type="button" class="get_status_approov" data-template-name="' . get_post_meta( $result['id'], 'zmessagetemplate_name', true ) . '" data-template-id="' . $result['id'] . '">' . esc_html__( 'Get Status', 'flow_notify_text' ) . '</div></span>';
				} else {
					return '';
				}
			case 'status':
				$checked = 'enabled' === $result['status'] ? 'checked' : '';

				return '<label class="zworkflowmanager_switch">
							<input type="checkbox" ' . $checked . '
								   class="zworkflow_message_template_status_toggle"
								   data-attr="' . $result['id'] . '">
							<span class="zworkflowmanager_slider round"></span>
						</label>';
		}

		return '';
	}

	public function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			echo '<div class="alignright" style="margin-bottom: 1rem;">';
			$this->pagination( 'top' );
			echo '</div>';
		}
	}
}

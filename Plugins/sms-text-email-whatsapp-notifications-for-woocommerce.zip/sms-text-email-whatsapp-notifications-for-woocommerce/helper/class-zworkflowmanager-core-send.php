<?php
/**
 * Flow-Notify functionality for Send tab
 *
 * @package Flow-Notify/helper/class-zworkflowmanager-core-send
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
}

/**
 * Class ZWORKFLOWMANAGER_Core_Send
 */
class ZWORKFLOWMANAGER_Core_Send extends WP_List_Table {

	/**
	 * ZWORKFLOWMANAGER_Core_Send constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'send',
				'plural'   => 'send_table',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Print table activities
	 *
	 * @return void
	 */
	public function print_activity() {
		$this->prepear_items_activity();
		$this->display();
	}

	/**
	 *
	 * Build table activities
	 *
	 * @return void
	 */
	public function prepear_items_activity() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( (int) $current_page - 1 ) * $per_page : 0;
		$items        = array();

		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns_activity(), array(), array() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowsend' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'numberposts'            => $per_page,
			'offset'                 => $offset,
		);

		$query = new WP_Query( $args );

		$total_results = $query->found_posts;

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$custom_status            = new ZWORKFLOWMANAGER_Send( get_the_ID() );
				$item['id']               = get_the_ID();
				$item['notification']     = get_post_meta( get_the_ID(), 'notification_title', true )
					? get_post_meta( get_the_ID(), 'notification_title' )[0] : $custom_status->get_notification_name();
				$item['phone']            = get_post_meta( get_the_ID(), 'notification_phone', true )
					? get_post_meta( get_the_ID(), 'notification_phone' )[0] : $custom_status->get_phone();
				$item['email']            = get_post_meta( get_the_ID(), 'notification_email', true )
					? get_post_meta( get_the_ID(), 'notification_email' )[0] : $custom_status->get_email();
				$item['data']             = $custom_status->get_date();
				$item['status']           = get_post_meta( get_the_ID(), 'notification_status', true )
					? get_post_meta( get_the_ID(), 'notification_status' )[0] : $custom_status->get_status();
				$item['type']             = get_post_meta( get_the_ID(), 'notification_type', true )
					? get_post_meta( get_the_ID(), 'notification_type' )[0] : $custom_status->get_checkbox_value();
				$item['background_color'] = get_post_meta( get_the_ID(), 'notification_background_color', true )
					? get_post_meta( get_the_ID(), 'notification_background_color', true )
					: $custom_status->get_background_color();
				$item['text_color']       = get_post_meta( get_the_ID(), 'notification_text_color', true )
					? get_post_meta( get_the_ID(), 'notification_text_color' )[0] : $custom_status->get_text_color();
				$item['method']           = get_post_meta( get_the_ID(), 'notification_method', true )
					? get_post_meta( get_the_ID(), 'notification_method' )[0] : $custom_status->get_method();
				$item['sent']             = get_post_meta( get_the_ID(), 'notification_date', true )
					? get_post_meta( get_the_ID(), 'notification_date', true )
					: get_post_meta( get_the_ID(), 'timestamp_chedule', true );
				array_push( $items, $item );
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		$this->items = $items;

		/**
		 * Pagination.
		 */
		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	/**
	 * Column activities
	 *
	 * @return string[]
	 */
	public function get_columns_activity() {
		return array(
			'notification' => 'Notification',
			'email'        => 'Email',
			'phone'        => 'Phone',
			'status'       => 'Status',
			'data'         => 'Schedule',
			'type'         => 'Type',
			'method'       => 'Method',
			'sent'         => 'Sent',

		);
	}

	/**
	 * Print table logs
	 *
	 * @return void
	 */
	public function print_logs() {
		$this->prepear_items_logs();
		$this->display();
	}

	/**
	 *
	 * Build table logs
	 *
	 * @return void
	 */
	public function prepear_items_logs() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( (int) $current_page - 1 ) * $per_page : 0;
		$items        = array();

		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns_logs(), array(), array() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowsend' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'numberposts'            => $per_page,
			'offset'                 => $offset,
			'meta_query'             => array(
				array(
					'key'     => 'send_status',
					'value'   => 'Failed',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		$total_results = $query->found_posts;

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$custom_status            = new ZWORKFLOWMANAGER_Send( get_the_ID() );
				$item['id']               = get_the_ID();
				$item['notification']     = $custom_status->get_notification_name()
					? $custom_status->get_notification_name() : get_the_title();
				$item['phone']            = get_post_meta( get_the_ID(), 'notification_phone', true )
					? get_post_meta( get_the_ID(), 'notification_phone' )[0] : $custom_status->get_phone();
				$item['email']            = get_post_meta( get_the_ID(), 'notification_email', true )
					? get_post_meta( get_the_ID(), 'notification_email' )[0] : $custom_status->get_email();
				$item['status']           = get_post_meta( get_the_ID(), 'notification_status', true )
					? get_post_meta( get_the_ID(), 'notification_status' )[0] : $custom_status->get_status();
				$item['type']             = get_post_meta( get_the_ID(), 'notification_type', true )
					? get_post_meta( get_the_ID(), 'notification_type' )[0] : $custom_status->get_checkbox_value();
				$item['background_color'] = get_post_meta( get_the_ID(), 'notification_background_color', true )
					? get_post_meta( get_the_ID(), 'notification_background_color', true )
					: $custom_status->get_background_color();
				$item['text_color']       = get_post_meta( get_the_ID(), 'notification_text_color', true )
					? get_post_meta( get_the_ID(), 'notification_text_color' )[0] : $custom_status->get_text_color();
				$item['method']           = get_post_meta( get_the_ID(), 'notification_method', true )
					? get_post_meta( get_the_ID(), 'notification_method' )[0] : $custom_status->get_method();
				$item['logs']             = get_post_meta( get_the_ID(), 'error_logs', true );
				array_push( $items, $item );
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		$this->items = $items;

		/**
		 * Pagination.
		 */
		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	/**
	 * Column activities
	 *
	 * @return string[]
	 */
	public function get_columns_logs() {
		return array(
			'notification' => 'Notification',
			'email'        => 'Email',
			'phone'        => 'Phone',
			'status'       => 'Status',
			'type'         => 'Type',
			'method'       => 'Method',
			'logs'         => 'Log',

		);
	}

	/**
	 * Print send table
	 */
	public function print_overview() {
		$this->prepare_items();
		echo '<div class="zworkflowmanager_overview_wrap" style="width: 95%;">';
		echo '<h2 class="screen-reader-text">' . esc_html__( 'Send Statuses', 'flow_notify_text' ) . '</h2>';
		if ( 0 !== count( $this->items ) ) {
			$this->display();
		} else {
			echo '<div style="color:#000; padding:1px 12px; background: #fff; border-left: solid 4px #ffb900;margin-top:20px;">';
			echo '<p style="margin: .5em 0; padding: 2px;">' . esc_html__( 'No Send Statuses', 'flow_notify_text' ) . '</p>';
			echo '</div>';
		}
		echo '</div>';
	}

	/**
	 * Prepares the list of items for displaying.
	 *
	 * @since 5.6.0
	 */
	public function prepare_items() {
		$current_page = $this->get_pagenum();
		$per_page     = 20;
		$offset       = 0 !== (int) $current_page ? ( (int) $current_page - 1 ) * $per_page : 0;
		$items        = array();
		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		/* WP_Query arguments */
		$args = array(
			'post_type'              => array( 'zworkflowsend' ),
			'post_status'            => array( 'publish' ),
			'posts_per_page'         => '-1',
			'posts_per_archive_page' => '-1',
			'numberposts'            => $per_page,
			'offset'                 => $offset,
			'meta_query'             => array(
				array(
					'key'     => 'send_status',
					'value'   => 'Scheduled',
					'compare' => 'LIKE',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$custom_status = new ZWORKFLOWMANAGER_Send( get_the_ID() );
				$total_results = $query->found_posts;

				$item['id']               = get_the_ID();
				$item['notification']     = $custom_status->get_notification_name();
				$item['phone']            = $custom_status->get_phone();
				$item['email']            = $custom_status->get_email();
				$item['data']             = $custom_status->get_date();
				$item['status']           = $custom_status->get_status();
				$item['type']             = $custom_status->get_checkbox_value();
				$item['background_color'] = $custom_status->get_background_color();
				$item['text_color']       = $custom_status->get_text_color();

				array_push( $items, $item );
			}
		}

		/* Restore original Post Data */
		wp_reset_postdata();

		$this->items = $items;

		/**
		 * Pagination.
		 */
		$this->set_pagination_args(
			array(
				'total_items' => $total_results,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_results / $per_page ),
			)
		);
	}

	/**
	 * Get columns
	 *
	 * @return array|string[]
	 */
	public function get_columns() {
		return array(
			'notification' => 'Notification',
			'email'        => 'Email',
			'phone'        => 'Phone',
			'status'       => 'Status',
			'data'         => 'Data',
			'type'         => 'Type',
		);
	}

	/**
	 * Build Columns with data for "Scheduled action list"
	 *
	 * @param array|object $result get result.
	 * @param string       $column_name get column_name.
	 *
	 * @return string|void
	 */
	public function column_default( $result, $column_name ) {
		if ( is_array( $result['type'] ) ) {
			$result['type'] = array_map(
				function( $value ) {
					return 'whatsapp' === $value ? 'WhatsApp' : $value;
				},
				$result['type']
			);
		} else {
			$result['type'] = ( 'whatsapp' === $result['type'] ) ? 'WhatsApp' : $result['type'];
		}

		switch ( $column_name ) {
			case 'data':
				$settings_status     = new ZWORKFLOWMANAGER_Settings();
				$settings            = $settings_status->get_settings();
				$schedule_timeframe  = $settings['schedule_timeframe_from'] . ' - ' . $settings['schedule_timeframe_to'];
				$today               = gmdate( 'm/d/Y', strtotime( gmdate( 'm/d/Y' ) ) );
				$tomorrow            = gmdate( 'm/d/Y', strtotime( gmdate( 'm/d/Y' ) . '+1 days' ) );
				$check_day           = current_time( 'timestamp' ) < strtotime( gmdate( $settings['schedule_timeframe_to'] ) )
					? $today : $tomorrow;
				$schedule_time_frame = $check_day . ', ' . $schedule_timeframe;
				$data                = ( 'On hold' === $result['status'] ) ? 'Schedule' : $result['data'];

				return '<span>' . $data . '</span>';
			case 'sent':
				$date = gmdate( 'm/d/Y, H:i:s', intval( $result['sent'] ) );
				if ( 'Success' !== $result['status'] ) {
					return '';
				}

				return '<span>' . $date . '</span>';
			case 'logs':
				return '<span>' . $result['logs'] . '</span>';
			case 'method':
				return '<span>' . $result['method'] . '</span>';
			case 'email':
				$email = is_array( $result['email'] ) ? implode( ', ', $result['email'] ) : $result['email'];

				return '<span>' . $email . '</span>';
			case 'phone':
				$phone = is_array( $result['phone'] ) ? implode( ', ', $result['phone'] ) : $result['phone'];

				return '<span>' . $phone . '</span>';
			case 'status':
				$status = ( 'Success' === $result['status'] ) ? 'Sent' : $result['status'];

				return '<span style="color:' . $result['text_color'] . '; background-color:' . $result['background_color'] . '" class="zworkflowmanager_label">' . $status . '</span>';
			case 'type':
				$type = is_array( $result['type'] ) ? implode( ', ', $result['type'] ) : $result['type'];

				return '<span>' . $type . '</span>';
			case 'notification':
				$edit_link    = admin_url( 'admin.php?page=wc-workflows&tab=send&edit_send=' . $result['id'] );
				$delete_link  = admin_url( 'admin.php?page=wc-workflows&tab=activities&zfn_operation_type=delete_send&send_id=' . $result['id'] );
				$label        = esc_html__( 'Edit', 'flow_notify_text' );
				$label_delete = esc_html__( 'Delete', 'flow_notify_text' );
				$delete_url   = wp_nonce_url( $delete_link, 'zfn_operation_type', 'zwf_nonce' );

				return '<div class="zworkflowstatus_entry">
							<a href="' . $edit_link . '">' . $result['notification'] . '</a><br/>
							<a href="' . $edit_link . '" class="zworkflowmanager_display_link_on_hover">' . $label . '</a>
							<a href="' . $delete_url . '" class="zworkflowmanager_display_link_on_hover delete">' . $label_delete . '</a>
						</div>';
		}

		return '';
	}

	/**
	 * Display table navigation
	 *
	 * @param string $which get which.
	 */
	public function display_tablenav( $which ) {
		if ( 'top' === $which ) {
			echo '<div class="alignright" style="margin-bottom: 1rem;">';
			$this->pagination( 'top' );
			echo '</div>';
		}
	}
}

<?php
/**
 *
 * Plugin Name: Flow Notify for WooCommerce
 * Plugin URI: https://www.flownotify.com
 * Description: Advanced functionality for order management using notifications, workflows and statuses for WooCommerce
 * Version: 1.11.16
 * Text Domain: flow_notify_text
 * WC requires at least: 2.4.0
 * WC tested up to: 8.6.1
 * woo:18734001190651:14a453aa96a2aed51eb9462a86b14db8
 * Author: BizSwoop a CPF Concepts, LLC Brand
 * Author URI: http://www.bizswoop.com
 *
 * @package Flow-Notify/workflow-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


define( 'ZWORKFLOWMANAGER_BASE_FILE', __FILE__ );
define( 'ZWORKFLOWMANAGER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZWORKFLOWMANAGER_LOGS_PATH', plugins_url( 'logs/logs.log', __FILE__ ) );
define( 'ZWORKFLOWMANAGER_LOGS_CONNECTION_PATH', plugins_url( 'logs/connetcion_logs.log', __FILE__ ) );

/*
 Required if your environment does not handle autoloading */
/*
 require ZWORKFLOWMANAGER_PLUGIN_DIR . 'twilio-php-main/src/Twilio/autoload.php';
*/

/* Loading Classes */
require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core.php';

register_activation_hook( __FILE__, array( 'ZWORKFLOWMANAGER_Core', 'plugin_activation' ) );
register_uninstall_hook( __FILE__, array( 'ZWORKFLOWMANAGER_Core', 'plugin_deactivation' ) );

add_action( 'init', array( 'ZWORKFLOWMANAGER_Core', 'init' ) );

add_action(
	'before_woocommerce_init',
	function() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

if ( ! class_exists( 'ZWORKFLOWMANAGER_Timing_Schedule' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-timing-schedule.php';
}

( new ZWORKFLOWMANAGER_Timing_Schedule() )->init_hooks();

if ( is_admin() ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-admin.php';
	$adm_admin = new ZWORKFLOWMANAGER_Core_Admin();
}

require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-public.php';
$public = new ZWORKFLOWMANAGER_Core_Public();

if ( ! class_exists( 'Flow_Checkout_Block_Example' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'flow-notify-checkout-block/checkout-block-example.php';
}

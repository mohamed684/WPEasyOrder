/**
 * Debounce function
 *
 * @param fn     - function that should be executed
 * @param time   - time delay
 * @returns {Function}
 */
export const debounce = ( fn, time = 1000 ) => {

	if ( ! fn ) {
		throw Error( '"debounce function - "You didn\'t add required parameters' );
	}

	let timeout;

	return function () {
		const functionCall = () => fn.apply( this, arguments );

		clearTimeout( timeout );
		timeout = setTimeout( functionCall, time );
	}
};

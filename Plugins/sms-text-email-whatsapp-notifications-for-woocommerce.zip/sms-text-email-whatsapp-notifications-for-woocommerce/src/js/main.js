import intlTelInput from '../js/libs/intlTelInput.min';

(function ( $ ) {
	$( document ).ready(
		function () {

			const template_name_wa = document.querySelector('#zcustomemail_template_name');

			template_name_wa && template_name_wa.addEventListener('input', () => {
				const currentValue = template_name_wa.value;
				const newValue = currentValue.replace(/[^a-z0-9_]/g, (match) => {
					if (match === ' ') {
						return '_';
					}
					return '';
				});
				template_name_wa.value = newValue;
			});

			$( '.zworkflowmanager_wp_colorpick' ).wpColorPicker();

			$( '#zworkflowmanager_next_statuses' ).select2(
				{
					placeholder: 'Select statuses...'
				}
			);

			$( '#zworkflowmanager_default_status' ).select2(
				{
					placeholder: 'Select one status...'
				}
			);

			$( '#zworkflowmanager_select_days' ).select2(
				{
					placeholder: 'Select days'
				}
			);

			$( 'input[name="zworkflowmanager_action_icon"]' ).on(
				'click',
				function () {
					$( '.zworkflowmanager_selected_hover_icon' )
						.removeClass( 'zworkflowmanager_selected_hover_icon' );
					$( this ).parent().addClass( 'zworkflowmanager_selected_hover_icon' );
				}
			);

			$( '.zworkflowemail_dispatch_remove_element' ).on(
				'click',
				function () {
					let element_id  = $( this ).attr( 'data-attr' );
					let current_row = $( '#zworkflowemail_dispatch_row_' + element_id );
					current_row.remove();
				}
			);

			$( 'a#zworkflowemail_dispatch_add_element' ).on(
				'click',
				function () {
					let dispatch_list      = $( '#zworkflowemail_dispatch_list' );
					let total_elements     = $( '#zworkflowemail_dispatch_list_number' );
					let new_element_number = parseInt( total_elements.val() ) + 1;

					let new_element             = `
					< div class                 = "zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
						id                      = "zworkflowemail_dispatch_row_` + new_element_number + `"
						style                   = "align-items: flex-end;" >
						< div class             = "zworkflowmanager_row zworkflowmanager_col_4 zworkflowmanager_disabled_left_padding" >
							< label class       = "zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
								   for          = "from_dispatch_element_` + new_element_number + `" > From Status < / label >
							< select class      = "zworkflowmanager_col_12 zworkflowmanager_from_status_select"
									data - attr = "` + new_element_number + `"
									data - role = "dispatch-status-from"
									name        = "from_dispatch_element_` + new_element_number + `"
									id          = "from_dispatch_element_` + new_element_number + `" > `;
					$.each(
						ajax_object.order_statuses,
						function ( index, value ) {
							new_element += '<option value="' + index + '">' + value + '</option>';
						}
					);
					new_element                += ` < / select >
						< / div >
						< div class             = "zworkflowmanager_row zworkflowmanager_col_4" >
							< label class       = "zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
								   for          = "to_dispatch_element_` + new_element_number + `" > To Status < / label >
							< select class      = "zworkflowmanager_col_12 zworkflowmanager_to_status_select"
									data - role = "dispatch-status-to"
									data - attr = "` + new_element_number + `"
									name        = "to_dispatch_element_` + new_element_number + `"
									id          = "to_dispatch_element_` + new_element_number + `" > `;
					let i                       = 0;
					$.each(
						ajax_object.order_statuses,
						function ( index, value ) {
							let selected = (i === 1) ? 'selected' : '';
							new_element += '<option value="' + index + '" ' + selected + '>' + value + '</option>';
							i++;
						}
					);
					new_element           += ` < / select >
						< / div >
						< div class        = "zworkflowmanager_col_3" >
							< a class      = "zworkflowemail_dispatch_remove_element button"
							   data - attr = "` + new_element_number + `" > Remove < / a >
						< / div >
						< div class        = "zworkflowmanager_col_12 zworkflowmanager_disabled_padding zworkflowmanager_element_error" >
							< span id      = "zworkflowmanager_error_element_` + new_element_number + `" > < / span >
						< / div >
						< / div > `;

					total_elements.val( new_element_number );
					dispatch_list.append( new_element );

					$( '.zworkflowemail_dispatch_remove_element' ).on(
						'click',
						function () {
							let element_id  = $( this ).attr( 'data-attr' );
							let current_row = $( '#zworkflowemail_dispatch_row_' + element_id );
							current_row.remove();
						}
					);

				}
			);

			$( '.zworkflowemail_status_toggle' ).on(
				'change',
				function () {
					let id      = $( this ).attr( 'data-attr' );
					let checked = $( 'input[data-attr="' + id + '"]:checked' ).val() === 'on' ? 'checked' : 'unchecked';

					$.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'change_custom_email_status',
								'email_id': id,
								'checked': checked
							}
						}
					);

				}
			);

			$( '.zworkflow_message_template_status_toggle' ).on(
				'change',
				function () {
					let id      = $( this ).attr( 'data-attr' );
					let checked = $( 'input[data-attr="' + id + '"]:checked' ).val() === 'on' ? 'checked' : 'unchecked';

					$.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'change_message_template_status',
								'message_template_id': id,
								'checked': checked
							}
						}
					);

				}
			);

			$( '#zworkflowmanager_delete_order_status_button' ).on(
				'click',
				function () {
					$( '#zworkflowmanager_delete_order_status_container' ).addClass( 'zworkflowmanager_show' );
				}
			);

			$( '#zworkflowmanager_close_delete_order_status_box' ).on(
				'click',
				function () {
					$( '#zworkflowmanager_delete_order_status_container' ).removeClass( 'zworkflowmanager_show' );
				}
			);

			$( '#zworkflowmanager_delete_reassign_button' ).on(
				'click',
				function () {
					let id                   = $( this ).attr( 'data-id' );
					let slug                 = $( '#new_status_reassign' ).val();
					let zwf_order_status     = $( '#zwf_order_status' ).val();

					$( '#zworkflowmanager_delete_order_status_box' ).removeClass( 'zworkflowmanager_show' )
						.addClass( 'zworkflow_hidden' );
					$( '#zworkflowmanager_loading_img' ).removeClass( 'zworkflow_hidden' ).addClass( 'zworkflowmanager_show' );

					$.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'reassign_orders_statuses',
								'slug': slug,
								'order_status_id': id,
								'zwf_order_status': zwf_order_status,
							},
							success: function ( response ) {
								window.location.href = response.data;
							}
						}
					);
				}
			);

			$('#zworkflowmanager_get_status, .get_status_approov').click(function () {
				const data_template_id = $(this).attr('data-template-id');
				$.ajax({
					url: ajax_object.ajax_url,
					method: 'POST',
					data: {
						'action': 'zworkflowmanager_get_template',
						'template_name': $(this).attr('data-template-name'),
						'template_id': data_template_id,
					},
					beforeSend: function () {
						$("#zworkflow_approval_status").val('Checking Status...');
						$(".approov_result_"+data_template_id+"").html('Checking Status...');
					},
					success: function (response) {
						$("#zworkflow_approval_status").val(response);
						$(".approov_result_"+data_template_id+"").html(response);
					}
				});

				return false;
			});

			$( '#zworkflowmanager_delete_directly_button' ).on(
				'click',
				function () {
					let id = $( this ).attr( 'data-id' );

					$( '#zworkflowmanager_delete_order_status_box' ).removeClass( 'zworkflowmanager_show' )
						.addClass( 'zworkflowmanager_hidden' );
					$( '#zworkflowmanager_loading_img' ).removeClass( 'zworkflowmanager_hidden' )
						.addClass( 'zworkflowmanager_show' );

					$.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'delete_status_directly',
								'order_status_id': id
							},
							success: function ( response ) {
								window.location.href = response.data;
							}
						}
					);
				}
			);

			$( '.js-delete-notification' ).on(
				'click',
				( e ) => {
                e.preventDefault();

				const post_type = $(e.currentTarget).hasClass('js-delete-message-template') ? 'message template' : 'notification';
                const result = confirm( 'Are you sure you want to delete ' + post_type  + '?' );
                if ( ! result ) {
                    return;
                }
                window.location.href = e.target.href;
				}
			);

		}
	);
})( jQuery );

(function ( $ ) {
	$( document ).ready(
		function () {

			const INTL_INPUT                      = document.querySelector( '.js-intl-input' );
			const INTL_INPUT_TEST                 = document.querySelector( '.js-intl-input-test' );
			const INTL_INPUT2                     = document.querySelector( '.js-intl-input2' );
			const INTL_INPUT2_TEST                = document.querySelector( '.js-intl-input2-test' );
			const INTL_INPUT3                     = document.querySelector( '.js-intl-input3' );
			const INTL_INPUT4                     = document.querySelector( '.js-intl-input4' );
			const ZWF_CONNECTION_FROM_NUMBER      = document.querySelector( '.js-zwf-connection-from-number' );
			const ZWF_CONNECTION_FROM_NUMBER_TEST = document.querySelector( '.js-zwf-connection-from-number-test' );
			const ZWF_CONNECTION_TO_NUMBER        = document.querySelector( '.js-zwf-connection-to-number' );
			const ZWF_CONNECTION_TO_NUMBER_TEST   = document.querySelector( '.js-zwf-connection-to-number-test' );
			const ZWF_CONNECTION_TEST_MSG         = document.querySelector( '.js-zwf-connection-test-msg' );
			const ZWF_CONNECTION_QUICK_SEND       = document.querySelector( '.js-zwf-connection-quick-send' );

			const TYPE_PREFERENCE_SWITCHER    = document.querySelector( '.js-type-preference_switcher' );
			const TYPE_PREFERENCE_STATUS_TEXT = document.querySelector( '.js-type-preference-status-text' );

			const MESSAGE_SCHEDULE_SWITCHER    = document.querySelector( '.js-message-schedule-switcher' );
			const MESSAGE_SCHEDULE_TEXT        = document.querySelector( '.js-message-schedule-text' );

			const zworkflowmanager_status_switcher = document.querySelector( '.js-zworkflowmanager_status_switcher' );
			const status_text                      = document.querySelector( '.js-status-text' );
			const send_recipient                   = document.querySelector( '.js-send-recipient' );

			const $datepicker          = $( '#datepicker' );
			const send_posts_from_data = ajax_object.get_send_posts_from_data;

			const INTL_INPUT_ARR     = [
				INTL_INPUT, INTL_INPUT_TEST, INTL_INPUT2, INTL_INPUT2_TEST, INTL_INPUT3, INTL_INPUT4
			];
			const ZWF_CONNECTION_ARR = [
				ZWF_CONNECTION_FROM_NUMBER, ZWF_CONNECTION_FROM_NUMBER_TEST, ZWF_CONNECTION_TO_NUMBER,
				ZWF_CONNECTION_TO_NUMBER_TEST, ZWF_CONNECTION_TEST_MSG, ZWF_CONNECTION_QUICK_SEND
			];

			const select_notification               = document.querySelector( '.js-select-notification' );
			const message_input                     = document.querySelector( '.js-message-input' );
			const notification_type                 = document.querySelectorAll( '.js-notification-type input[type="checkbox"]' );
			const wc_workflows_list                 = document.querySelectorAll( '#toplevel_page_wc-workflows ul li' );
			const form_edit                         = document.querySelector( '#zworkflowmanager_send_status' );
			const EMAIL_BUTTON                      = document.querySelectorAll( '.js-email-button' );
			const ZWF_MESSAGE                       = document.querySelector( '.js-zwf-message' );
			const SELECT_WOOCOMMERCE_ORDERS_WRAP    = document.querySelector( '.js-select-wooCommerceOrders-wrap' );
			const NOTIFICATION_WOOCOMMERCE_ORDERS   = document.querySelector( '.js-show-notification-wooCommerceOrders' );
			const SELECT_WOOCOMMERCE_DATA           = document.querySelector( '.js-select-wooCommerceData' );
			const SELECT_WOOCOMMERCEORDERS          = document.querySelector( '.js-select-wooCommerceOrders' );
			const SELECT_TRIGER                     = document.querySelector( '.trigger' );
			const CHECK_STATUS_TEMPLATE             = document.querySelector( '.zworkflowmanager_check_status_template' );
			const ZCUSTOMEMAIL_SUBJECT_WRAP         = document.querySelector( '.zcustomemail_subject-wrap' );
			const SENDING_TYPE                      = document.querySelector( '.js-sending-type' );
			const TIME_VALUE                        = document.querySelector( '.js-time-value' );
			const ZWORKFLOWMANAGER_SEND_STATUS_FORM = document.querySelector( '#zworkflowmanager_send_status' );
			const SENDING_REQUIRED                  = document.querySelectorAll( '.js-sending-required' );
			const DEFAULT_COMMUNICATION_METHOD      = document.querySelector( '.js-default_communication_method' );
			const COMMUNICATION_METHODS             = document.querySelectorAll( '.js-communication_methods' );
			const SCHEDULE_TIMEFRAME                = document.querySelectorAll( '.js-schedule_timeframe' );
			const SEND_ORDER_NOTIFICATION           = document.querySelector( '.js-send-order-notification' );
			const SELECT_WRAP                       = document.querySelectorAll( '.select-wrap' );
			const PRODUCT_VALUES                    = document.querySelector( '.js-product-values' );
			const STATUS_SWITCHER                   = document.querySelector( '.js-status-switcher' );
			const ZWF_SETTING_TABLE                 = document.querySelectorAll( '.js-zwf-setting-table' );
			const INPUT_PHONE                       = document.querySelectorAll( '.js-input-phone' );
			const STATUS_TRIGGER                    = document.querySelector( '.js-status-trigger' );
			const TRIGGER_DESC                      = document.querySelectorAll( '.js-trigger-desc' );
			const TRIGGER_COL_2                     = document.querySelector( '.js-trigger-col-2' );
			const TRIGGER_COL_3                     = document.querySelector( '.js-trigger-col-3' );
			const ctx                               = document.getElementById( 'myChart' );
			const delayed_time                      = document.getElementById('zwf_delayed_time');
			const ORDER_COMMUNICATIONS_PREFERENCE   = document.querySelectorAll('.communication-preference-checkbox');
			const copy_log                          = document.querySelectorAll('.zworkflowmanager_opy-log');
			const DEFAULT_COUNTRY_CODE              = document.getElementById('zwf_default-code');
			const WHATSAPP_PHONE                    = document.getElementById("whatsapp_phone");
			const BILLING_PHONE                     = document.getElementById("billing_phone");

			BILLING_PHONE && intlTelInput(BILLING_PHONE, {
				separateDialCode: true,
				initialCountry: ajax_object.billing_country ? ajax_object.whatsapp_country : ajax_object.default_country_iso,
				utilsScript: ajax_object.intl_utils
			});

			WHATSAPP_PHONE && intlTelInput(WHATSAPP_PHONE, {
				separateDialCode: true,
				initialCountry: ajax_object.whatsapp_country ? ajax_object.whatsapp_country : ajax_object.default_country_iso,
				utilsScript: ajax_object.intl_utils
			});

			const defaultIti = DEFAULT_COUNTRY_CODE && intlTelInput(DEFAULT_COUNTRY_CODE, {
				separateDialCode: true,
				initialCountry: ajax_object.default_country_iso,
				utilsScript: ajax_object.intl_utils
			});

			DEFAULT_COUNTRY_CODE && DEFAULT_COUNTRY_CODE.addEventListener('countrychange', function() {
				const countryData = defaultIti.getSelectedCountryData();
				const hiddenElement = document.getElementById('zwf_default-code-hidden');
				hiddenElement.value = countryData.iso2;
			});

			const timing_select = document.getElementById('zworkflowmanager_timing_select');
			const variants = document.querySelectorAll('.timing-variant');

			let delayTimerAjax;

			function do_ajax_get_product(thisInput, selectProductsValue, inputValue, offset = null){
				const post_count_offset = offset;
				$.ajax({
					url: ajax_object.ajax_url,
					type: 'GET',
					data: {
						'action': 'get_product_for_placeholder',
						'request': inputValue,
						'select_products': selectProductsValue,
						'offset': offset,
					},
					beforeSend: function() {
						thisInput.prev().prev('.zwf__close-input-btn').removeClass('active');
						thisInput.prev('.zwf_preloder').addClass('active');
					},
					success: function(response) {
						if (response) {
							const data = JSON.parse(response);
							const select_products = data.select_products;
							let liArray = [];

							data.items.forEach(function(item) {
								let li = $("<li class='zwf_placeholder_product'></li>");
								li.attr("data-placeholder", "{" + select_products + item.ID + "}");
								li.text(item.post_title + ' (#' + item.ID + ')');

								if (item.variations) {
									li.addClass("zwf_sub-prod-list");
									li.append("<div class='zwf_open-list' data-product-id='"+ item.ID +"' data-select-products='" + select_products + "'></div>");
								}
								liArray.push(li);
							});

							const class_ul = select_products + 'ul';

							if (data.items.length === 0 && post_count_offset === null){
								let ul_obj = $('#' + class_ul);
								ul_obj.html('<li>No result</li>');
								ul_obj.slideDown(500);
								return;
							}

							if (data.items.length > 19 && post_count_offset !== null){
								const offset_now = $('#' + class_ul).data('offset') + 20;
								$('#' + class_ul).data('offset', offset_now);
							}

							if (data.items.length < 20 && post_count_offset !== null) {
								$('#' + class_ul).addClass('no_ajax');

							}

							if (post_count_offset === null){
								let ul_obj = $('#' + class_ul);
								ul_obj.html(liArray);
								ul_obj.removeClass('no_ajax');
								ul_obj.data('offset', 20);
								ul_obj.slideDown(500);
							} else {
								$('#' + class_ul).append(liArray);
							}

						}
					},
					complete: function() {
						thisInput.prev().prev('.zwf__close-input-btn').addClass('active');
						thisInput.prev('.zwf_preloder').removeClass('active');
					}
				});
			}

			$('.zwf_search-product').on('input', function() {
				const thisInput = $(this);
				const inputValue = $(this).val();
				const selectProductsValue = $(this).data('select-products');
				if (inputValue.length > 2) {
					clearTimeout(delayTimerAjax);
					delayTimerAjax = setTimeout(function() {
						do_ajax_get_product(thisInput, selectProductsValue, inputValue);
					}, 1000);
				}
				if (inputValue.length === 0) {
					thisInput.next('.zwf_-select-list').slideUp();
				}
			});

			$('.zwf_-select-list').on('scroll', function() {
				if($(this).hasClass('no_ajax')){
					return;
				}
				if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
					const thisInput = $(this).prev();
					const inputValue =  $(this).prev().val();
					const selectProductsValue = $(this).prev().data('select-products');
					do_ajax_get_product(thisInput, selectProductsValue, inputValue, $(this).data('offset'));
				}
			});

			function clearlistPoduct() {
				$('.zwf_select-wrap').removeClass('search-active');
				$('.zwf_select-wrap .zwf__email-button').removeClass('disable');
				$('.zwf_select-wrap .zwf__close-input-btn').removeClass('active');
				$('.zwf_search-product').val('');
				$('.zwf_-select-list').empty();
			}

			function get_variation_ajax(elem, product_id, select_products){
				$.ajax({
					url: ajax_object.ajax_url,
					type: 'GET',
					data: {
						'action': 'get_variations_for_placeholder',
						'product_id': product_id,
					},
					success: function(response) {
						const data = JSON.parse(response);
						let liArray = [];
						let ul = $("<ul class='zwf_variation-list'></ul>");

						data.forEach(function(item) {
							let li = $("<li class='zwf_placeholder_product'></li>");
							li.attr("data-placeholder", "{" + select_products + 'variation_' +item.ID + "}");
							li.text(item.post_title);
							liArray.push(li);
						});

						elem.append(ul.append(liArray));
						elem.find('.zwf_variation-list').slideDown(300);
					}
				});
			}

			$(document).on('click', '.zwf_open-list', function (event) {
				event.stopPropagation();
				$(this).toggleClass('active');
				if (! $(this).hasClass('added')) {
					get_variation_ajax($(this).parent(), $(this).data('product-id'), $(this).data('select-products'));
					$(this).addClass('added');
					return;
				}
				$(this).next('.zwf_variation-list').toggle(300);
			});

			$(document).on('click', '.zwf_placeholder_product', function (event) {
				event.stopPropagation();
				const placeholderValue = $(this).data('placeholder');
				$('.zwf_search-product').val(placeholderValue);

				const message_value = $('.js-zwf-message').val();

				$('.js-zwf-message').val(message_value.trim() + ` ${placeholderValue} `);
			});

			$('.zwf_select-wrap').click(function(){
				if (!$(this).hasClass('search-active')) {
					clearlistPoduct();
				}
				$(this).addClass('search-active');
				$(this).find('.zwf__email-button').addClass('disable');
				$(this).find('.zwf__close-input-btn').addClass('active');
			});

			$('.zwf__close-input-btn').click(function(event){
				event.stopPropagation();
				$(this).parent('.zwf_select-wrap').removeClass('search-active');
				$(this).siblings('.zwf__email-button').removeClass('disable');
				$(this).siblings('.zwf__close-input-btn').removeClass('active');
				$(this).siblings('.zwf_search-product').val('');
				$(this).siblings('.zwf_-select-list').hide();
				$(this).removeClass('active');
			});

			timing_select && timing_select.addEventListener('change', function() {
				const selectedId = this.options[this.selectedIndex].dataset.id;
				variants.forEach(variant => {
					variant.classList.remove('visible');
					if (variant.id === selectedId) {
						variant.classList.add('visible');
						$( '#zworkflowmanager_select_days' ).select2(
							{
								placeholder: 'Select days'
							}
						);
						$('.zworkflowmanager_req').removeAttr('required');

						switch (selectedId) {
							case 'zworkflowmanager_delayed':
								$('#zworkflowmanager_delayed .zworkflowmanager_req').attr('required', true);
								break;
							case 'zworkflowmanager_scheduled':
								$('#zworkflowmanager_scheduled .zworkflowmanager_req').attr('required', true);
								break;
							case 'zworkflowmanager_fixed':
								$('#zworkflowmanager_fixed .zworkflowmanager_req').attr('required', true);
								break;
						}
					}
					if ('zworkflowmanager_immediately' === selectedId) {
						$('.zworkflowmanager_req').removeAttr('required');
					}
				});
			});

			copy_log && copy_log.forEach(function(element) {
				element.addEventListener('click', function() {
					const hasCopyLogConnectionClass   = element.classList.contains('copy-log-connection');
					const log_connection              = hasCopyLogConnectionClass ? 1 : 0;
					const button                      = element;
					const settings_notify_nonce_field = document.getElementById("settings_notify_nonce_field").value;;
					element.setAttribute("disabled", "disabled");
					$.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'copy_log_file',
								'log_connection': log_connection,
								'settings_notify_nonce_field': settings_notify_nonce_field,
							},
							success: function (response) {
								unsecuredCopyToClipboard(response);
								button.removeAttribute("disabled");
							}
						}
					);
				});
			});

			function unsecuredCopyToClipboard(text) {
				const textArea = document.createElement("textarea");
				textArea.value = text;
				document.body.appendChild(textArea);
				textArea.focus();
				textArea.select();
				try {
					document.execCommand('copy');
				} catch (err) {
					console.error('Unable to copy to clipboard', err);
				}
				document.body.removeChild(textArea);
			}


			if ($('.timing-variant').hasClass('visible')) {
				const id = $('.timing-variant.visible').attr('id');
				$('#' + id + ' .zworkflowmanager_req').attr('required', true);
			}

			$( '#timing-datepicker' ).datepicker({
				dateFormat: 'yy-mm-dd'
			});

			delayed_time && delayed_time.addEventListener('input', function() {
				this.value = this.value.replace(/[^0-9]/g, '');
			});


			/**
			 * Chart diagram for dashboard tab
			 */
			const chart_functionality = () => {
				let month_arr         = [];
				let countFirst        = [];
				let countSecond       = [];
				let countThird        = [];
				let countFourth        = [];

				send_posts_from_data && send_posts_from_data[0].forEach(
					item => {
                    month_arr.push( item[0] );
                    countFirst.push( item[1] );
					}
				);
				send_posts_from_data && send_posts_from_data[1].forEach(
					item => {
                    countSecond.push( item[1] );
					}
				);
				send_posts_from_data && send_posts_from_data[2].forEach(
					item => {
                    countThird.push( item[1] );
					}
				);
				send_posts_from_data && send_posts_from_data[3].forEach(
					item => {
						countFourth.push( item[1] );
					}
				);

				let dataFirst = {
					label: 'Message sent',
					data: countFirst,
					lineTension: 0,
					fill: false,
					borderColor: '#D63638'
				};

				let dataSecond = {
					label: 'Email',
					data: countSecond,
					lineTension: 0,
					fill: false,
					borderColor: '#d1a2e4'
				};

				let dataThird = {
					label: 'SMS',
					data: countThird,
					lineTension: 0,
					fill: false,
					borderColor: '#6dc7ae'
				};

				let dataFourth = {
					label: 'WhatsApp',
					data: countFourth,
					lineTension: 0,
					fill: false,
					borderColor: '#4da4df'
				};

				let speedData = {
					labels: month_arr,
					datasets: [dataFirst, dataSecond, dataThird, dataFourth]
				};

				new Chart(
					ctx,
					{
						type: 'line',
						data: speedData,
						options: {
							responsive: true,
							animation: {
								onComplete: function ( animation ) {
									let firstSet  = animation.chart.config.data.datasets[0].data;
									const no_data = document.querySelector( '.js-no-data' );
									const myChart = document.querySelector( '#myChart' );

									if ( firstSet.length === 0 ) {
										no_data && no_data.classList.add( 'active' );
										myChart && myChart.classList.add( 'hide' );
									}
								}
							},
							interaction: {
								mode: 'index',
								intersect: false,
							},
							plugins: {
								legend: {
									display: false,
								}
							},
							scales: {
								x: {
									display: true,
									position: 'bottom',
									grid: {
										drawOnChartArea: false,
									},
								},
								y: {
									display: true,
									position: 'left',
									grid: {
										drawOnChartArea: false,
									},
								}
							}
						}
					}
				);
			}

			/**
			 * Ajax request to backend for sending SMS through Twilio service
			 *
			 * @param event_target
			 * @param action_url
			 */
			const twilioSendSMS = ( event_target, action_url ) => {

				const formData   = new FormData( event_target );
				const STATUS_EL  = event_target.querySelector( '.js-zwf-operation-status' );
				const SUBMIT_BTN = event_target.querySelector( '.js-submit' );

				formData.append( 'action', action_url );

				const option = {
					method: 'POST',
					body: formData,
				};

				SUBMIT_BTN && SUBMIT_BTN.classList.add( 'loading' );

				fetch( ajax_object.ajax_url, option )
					.then( result => result.json() )
					.then(
						result_data => {
                        if ( STATUS_EL ) {
                            const status_class = (result_data.success) ? 'success' : 'error';
                            STATUS_EL.classList.remove( 'check-success', 'check-error' );
                            STATUS_EL.classList.add( 'check-' + status_class );
                            STATUS_EL.innerHTML = result_data.data;
                        }
                        SUBMIT_BTN && SUBMIT_BTN.classList.remove( 'loading' );
						}
					);

			};
			(INTL_INPUT_ARR) && INTL_INPUT_ARR.forEach(
				item => {
                item && intlTelInput(
						item,
						{
							separateDialCode: true,
							initialCountry: ajax_object.default_country_iso,
							utilsScript: ajax_object.intl_utils
						}
					);
				}
			);

			INTL_INPUT_ARR.forEach(
				( item, index ) => {
                if ( item === null ) {
                    return;
                }
                // Getting IntlPhone input instance
					const iti = window.intlTelInputGlobals.getInstance( item );
                item.addEventListener(
						'input',
						function () {
							// Update real input with entered value by user
							ZWF_CONNECTION_ARR[index].value = iti.getNumber();
						}
					);
				item.addEventListener(
					'keyup',
					event => {
                    event.target.value = event.target.value.replace( /[^0-9\-\+\s]/g, '' );
					}
				);
				}
			);

			/**
			 * Global handler for Submit event
			 */
			document.body.addEventListener(
				'submit',
				event => {
                const ROLE = event.target.dataset.role;
                switch ( ROLE ) {
                    // Twilio form for sending test SMS
                    case 'twilio-test-message':
                        event.preventDefault();
                        twilioSendSMS( event.target, 'twilio_test_message' );
                        break;

                    // Twilio form for Quick sending SMS
                    case 'twilio-quick-send':
                        event.preventDefault();
                        twilioSendSMS( event.target, 'twilio_quick_send' );
                        break;
                }
				}
			);

			(SELECT_WOOCOMMERCE_DATA) && SELECT_WOOCOMMERCE_DATA.addEventListener(
				'input',
				( event ) => {
                (event.target.value === 'include_data') ? SELECT_WOOCOMMERCE_ORDERS_WRAP.classList.add( 'active' )
						: SELECT_WOOCOMMERCE_ORDERS_WRAP.classList.remove( 'active' );
				}
			);

			(SELECT_WOOCOMMERCEORDERS) && SELECT_WOOCOMMERCEORDERS.addEventListener(
				'input',
				( event ) => {
                (event.target.value === 'all_orders_placed') ? NOTIFICATION_WOOCOMMERCE_ORDERS.classList.add( 'active' )
						: NOTIFICATION_WOOCOMMERCE_ORDERS.classList.remove( 'active' );
				}
			);

			/**
			 * Checking of status email checkbox
			 */
			(zworkflowmanager_status_switcher)
			&& zworkflowmanager_status_switcher.addEventListener(
				'change',
				( event ) => {
                if ( ! status_text ) {
                    return;
                }
                status_text.innerText = (event.target.checked) ? 'Enabled' : 'Disabled';
				}
			);

			(STATUS_SWITCHER)
			&& STATUS_SWITCHER.addEventListener(
				'change',
				( event ) => {
                if ( ! status_text ) {
                    return;
                }
                status_text.innerText = (event.target.checked) ? 'Live Credentials' : 'Testing Credentials';
                ZWF_SETTING_TABLE && ZWF_SETTING_TABLE.forEach(
						item => {
                        const live    = item.querySelector( '.js-live' );
                        const test    = item.querySelector( '.js-test' );
                        if ( event.target.checked ) {
                            live.classList.add( 'active' );
                            test.classList.remove( 'active' );
                        } else {
                        live.classList.remove( 'active' );
                        test.classList.add( 'active' );
                        }

							INPUT_PHONE && INPUT_PHONE.forEach(
								phone => {
                                const wrap = phone.closest( '.iti' );
                                phone.classList.contains( 'active' ) ? wrap.style.display                                       = 'inline-block' : wrap.style.display
										= 'none';
								}
							);
						}
					);
				}
			);

			INPUT_PHONE && INPUT_PHONE.forEach(
				phone => {
                const wrap = phone.closest( '.iti' );
                phone.classList.contains( 'active' ) ? wrap.style.display = 'inline-block' : wrap.style.display = 'none';
				}
			);

			/**
			 * Handler for user choice for selecting customers
			 */
			(send_recipient)
			&& send_recipient.addEventListener(
				'input',
				( event ) => {
                const value                = event.target.value;
                const customer_select_wrap = document.querySelector( '.js-customer_select_wrap' );
                (customer_select_wrap) && customer_select_wrap.classList.remove( 'selected' );
                if ( value && value !== 'Select Customer' ) {
                    return;
                }
                (customer_select_wrap) && customer_select_wrap.classList.add( 'selected' );
				}
			);

			const WHEN_DISPATCH     = document.querySelector( '.js-when-dispatch' );
			const WHEN_DISPATCH_BTN = document.querySelector( '.js-button-send-event' );

			let SELECTED_DATE = WHEN_DISPATCH && WHEN_DISPATCH.dataset.select_date;
			SELECTED_DATE     = (SELECTED_DATE) && SELECTED_DATE.split( ', ' );

			(WHEN_DISPATCH) && WHEN_DISPATCH.addEventListener(
				'input',
				( event ) => {
                const value            = event.target.value;
                const date_time_fields = document.querySelectorAll( '.js-date-time-fields' );
                const input            = document.querySelectorAll( '.js-date-time-input' );
                if ( WHEN_DISPATCH_BTN ) {
                    let container_text = WHEN_DISPATCH_BTN.querySelector( '.js-btn-text' );
                    switch ( value ) {
                        case 'Scheduled':
                            container_text.innerText = 'Schedule Send';
                            break;
                        default :
                            container_text.innerText = 'Send Now';
                            break;
                    }
                }
                (date_time_fields) && date_time_fields.forEach(
						item => {
                        item.classList.remove( 'selected' );
                        (input) && input.forEach(
                                input => {
								input.removeAttribute( 'required' );
								input.value = '';
                                }
                            );
						if ( value && value !== 'Scheduled' ) {
							return;
						}
						item.classList.add( 'selected' );
						(input) && input.forEach(
							input => {
                            input.setAttribute( 'required', 'required' );
							}
						);
						}
					);
				}
			);

			(SENDING_TYPE) && SENDING_TYPE.addEventListener(
				'input',
				( event ) => {
					let subject_input = null;
					if (ZCUSTOMEMAIL_SUBJECT_WRAP) {
						subject_input = ZCUSTOMEMAIL_SUBJECT_WRAP.querySelector('.js-subject');
					}
					if ( event.target.value === 'email' && event.target.type !== 'checkbox' || (event.target.value === 'email' && event.target.checked) ) {
						ZCUSTOMEMAIL_SUBJECT_WRAP && ZCUSTOMEMAIL_SUBJECT_WRAP.classList.add( 'active' );
						subject_input && subject_input.setAttribute( 'required', 'required' );
						$('.ztemplatename_subject-wrap').removeClass('active');
						CHECK_STATUS_TEMPLATE && CHECK_STATUS_TEMPLATE.classList.remove( 'active' );
						SELECT_TRIGER && SELECT_TRIGER.classList.remove( 'hidden' );
						$(".whatsapp_approval_status").hide();
						$('#zcustomemail_template_name').removeAttr('required');

					} else if ( event.target.value === 'whatsapp' ) {
						SELECT_TRIGER && SELECT_TRIGER.classList.add( 'hidden' );
						$('.ztemplatename_subject-wrap').addClass('active');
						CHECK_STATUS_TEMPLATE && CHECK_STATUS_TEMPLATE.classList.add( 'active' );
						ZCUSTOMEMAIL_SUBJECT_WRAP && ZCUSTOMEMAIL_SUBJECT_WRAP.classList.remove( 'active' );
						$(".whatsapp_approval_status").show();
						$('#zcustomemail_template_name').prop('required', true);
					} else {
						ZCUSTOMEMAIL_SUBJECT_WRAP && ZCUSTOMEMAIL_SUBJECT_WRAP.classList.remove( 'active' );
						subject_input && subject_input.removeAttribute( 'required' );
						$('.ztemplatename_subject-wrap').removeClass('active');
						CHECK_STATUS_TEMPLATE && CHECK_STATUS_TEMPLATE.classList.remove( 'active' );
						SELECT_TRIGER && SELECT_TRIGER.classList.remove( 'hidden' );
						$(".whatsapp_approval_status").hide();
						$('#zcustomemail_template_name').removeAttr('required');
					}
				}
			);

			$('.zworkflow-sending-type').on('change', function() {
				$('.zworkflow_message_template').prop('selectedIndex', 0);

				if ( $(this).val() == 'SMS' || $(this).val() == 'sms' ) {
					$('.message-templates-lists').removeClass('active');
					$('.sms-lists').addClass('active');
				}
				if ( $(this).val() == 'email' ) {
					$('.message-templates-lists').removeClass('active');
					$('.emails-lists').addClass('active');
				}
				if ( $(this).val() == 'whatsapp' ) {
					$('.message-templates-lists').removeClass('active');
					$('.whatsapp-lists').addClass('active');
				}
			});

			$datepicker.datepicker(
				{
					dateFormat: 'mm/dd/yy',
					showButtonPanel: true
				}
			);

			$( '.js-select_type' ).select2(
				{
					placeholder: 'Please enter 1 or more characters',
				}
			);

			$( '.js-select-product' ).select2(
				{
					placeholder: 'Filter by product',
				}
			);

			$( '.js-select-coupon' ).select2(
				{
					placeholder: 'Filter by coupon',
				}
			);

			/**
			 * Global handler for Change event
			 */
			document.body.addEventListener(
				'input',
				event => {
                const ROLE = event.target.dataset.role;
                switch ( ROLE ) {

                    // Processing selection of dispatch notification statuses
                    case 'dispatch-status-to':
                    case 'dispatch-status-from': {
                        const STATUS_FROM = document.querySelector( 'select[data-role="dispatch-status-from"]' );
                        const STATUS_TO   = document.querySelector( 'select[data-role="dispatch-status-to"]' );
                        const Idx         = STATUS_FROM.dataset.attr;
                        const ERROR_BOX   = document.querySelector( '#zworkflowmanager_error_element_' + Idx );

                        const message =
                        (STATUS_FROM.value === STATUS_TO.value && STATUS_TO.value !== 'any')
                        ? 'From status and To status can\'t be the same. This condition won\'t be saved.'
                        : '';
                        if ( ERROR_BOX ) {
                            ERROR_BOX.innerText = message;
                        }
                        }

                        break;
                    case 'disabled-btn': {
                        SENDING_REQUIRED.forEach(
                        item => {
                            [...SENDING_REQUIRED].every( elem => ! elem.checked )
                            ? item.setAttribute( 'required', 'required' )
                            : item.removeAttribute( 'required' );
                            }
                    );
                    ZWORKFLOWMANAGER_SEND_STATUS_FORM
                    && (ZWORKFLOWMANAGER_SEND_STATUS_FORM.checkValidity())
                    ? WHEN_DISPATCH_BTN && WHEN_DISPATCH_BTN.classList.remove( 'disabled' )
                    : WHEN_DISPATCH_BTN && WHEN_DISPATCH_BTN.classList.add( 'disabled' );
                        }
                        break;
                }
				}
			);

			/**
			 * Checking of status email checkbox
			 */
			(TYPE_PREFERENCE_SWITCHER) && TYPE_PREFERENCE_SWITCHER.addEventListener(
				'change',
				( event ) => {
                TYPE_PREFERENCE_STATUS_TEXT.innerText = (event.target.checked) ? 'Enabled' : 'Disabled';
				}
			);

			/**
			 * Message Schedule Timeframe
			 */
			(MESSAGE_SCHEDULE_SWITCHER) && MESSAGE_SCHEDULE_SWITCHER.addEventListener(
				'change',
				( event ) => {
					MESSAGE_SCHEDULE_TEXT.innerText = (event.target.checked) ? 'Enabled' : 'Disabled';
				}
			);

			/**
			 * Initialize tooltip for notification icon
			 */
			new Drooltip(
				{
					'element': '.js-show-notification-icon',
					'trigger': 'click',
					'content': 'Number format [country code][number], ex +1555555555 for number (555) 555-5555',
					'background': '#2370b0',
					'position': 'left'
				}
			);

			new Drooltip(
				{
					'element': '.js-show-notification-email-icon',
					'trigger': 'hover',
					'content': 'Click on the button to add the supported data type to the message field',
					'background': '#2370b0',
					'position': 'right'
				}
			);

			new Drooltip(
				{
					'element': '.js-email_template-help-tip',
					'trigger': 'hover',
					'content': null,
					'background': '#333',
					'position': 'top'
				}
			);

			new Drooltip(
				{
					'element': '.js-notification-wooCommerceOrders',
					'trigger': 'hover',
					'content': 'Note: A single message will be sent per order',
					'background': '#2370b0',
					'position': 'top'
				}
			);

			(select_notification) && select_notification.addEventListener(
				'input',
				event => {
                $.post(
						{
							url: ajax_object.ajax_url,
							data: {
								'action': 'select_notification_type',
								'name': event.target.value
							},
							success: function ( response ) {
								if ( ! response ) {
									return;
								}

								(notification_type) && notification_type.forEach(
									item => {
										//item.checked = (item.value === response.data[0]);
										const event  = new Event( 'input' );
										item.dispatchEvent( event );

										const whatsappCheckbox    = document.getElementById('whatsapp');
										const message_template_id = document.getElementById("message_template_id");
										message_template_id.value = response.data[2];

										if (response.data[0] === 'whatsapp') {
											whatsappCheckbox.removeAttribute('onclick');
											whatsappCheckbox.removeAttribute('readonly');
										} else {
											whatsappCheckbox.setAttribute('onclick', 'return false;');
											whatsappCheckbox.setAttribute('readonly', 'readonly');
											whatsappCheckbox.checked = false;
										}
									}
								);

								message_input.value = (response.data[1]) ? response.data[1] : '';

								if (response.data[0] === 'whatsapp') {
									message_input.readOnly = true;
									WHEN_DISPATCH_BTN && WHEN_DISPATCH_BTN.classList.remove( 'disabled' )
								} else {
									message_input.readOnly = false;
								}
							}
						}
					);
				}
			);

			/**
			 * Add class 'current' for active tab for sub menu
			 */
			(wc_workflows_list) && wc_workflows_list.forEach(
				item => {
                const url = document.location.href;
                const tab = (item.querySelector( 'a' )) && item.querySelector( 'a' ).href;
                if ( tab && url.includes( tab ) ) {
                    (item) && item.classList.add( 'current' );
                }
				}
			);

			(form_edit) && form_edit.addEventListener(
				'submit',
				() => {
                (WHEN_DISPATCH_BTN) && WHEN_DISPATCH_BTN.classList.add( 'loading' );
				}
			);

			/**
			 *
			 */
			(EMAIL_BUTTON) && EMAIL_BUTTON.forEach(
				item => {
                item && item.addEventListener(
						'click',
						() => {
                        const value       = item.dataset.value;
						if ( ! ZWF_MESSAGE.readOnly ) {
							ZWF_MESSAGE.value = ZWF_MESSAGE.value.trim() + ` ${value} `;
							item && item.classList.add( 'added' );
						}
                        setTimeout(
                                () => {
								item && item.classList.remove( 'added' );
                                },
                                3000
                            );
						}
					);
				}
			);

			$( 'body' ).on(
				'click',
				'.aw_upload_image_button',
				function ( e ) {
					e.preventDefault();
					let aw_uploader = wp.media(
						{
							title: 'Custom image',
							button: {
								text: 'Use this image'
							},
							multiple: false
						}
					).on(
						'select',
						function () {
							const attachment = aw_uploader.state().get( 'selection' ).first().toJSON();
							$( '#aw_custom_image' ).val( attachment.url );
						}
					)
						.open();
				}
			);

			/**
			 * Disabled or enabled  default communication methods in settings tab
			 */
			COMMUNICATION_METHODS && COMMUNICATION_METHODS.forEach(
				item => {
                const options         = DEFAULT_COMMUNICATION_METHOD.querySelectorAll( 'option' );
                item.addEventListener(
						'change',
						event => {
                        const checked = [...COMMUNICATION_METHODS].every( elem => ! elem.checked );
                        options && options.forEach(
                                options_item => {
								if ( event.target.value === options_item.value ) {
									options_item.disabled = false;
								}
								if ( event.target.checked ) {
									return;
								}
								if ( event.target.value === options_item.value ) {
									options_item.disabled = true;
								}
                                }
                            );
						DEFAULT_COMMUNICATION_METHOD.disabled = false;
						if ( ! checked ) {
							return;
						}
						DEFAULT_COMMUNICATION_METHOD.disabled = true;
						}
					);
				}
			);

			DEFAULT_COMMUNICATION_METHOD && DEFAULT_COMMUNICATION_METHOD.addEventListener(
				'change',
				() => {
                const options                 = DEFAULT_COMMUNICATION_METHOD.querySelectorAll( 'option' );
                options && options.forEach(
						options_item => {
                        options_item.selected = options_item.selected && ! options_item.disabled;
						}
					);
				}
			);

			STATUS_TRIGGER && STATUS_TRIGGER.addEventListener(
				'change',
				( event ) => {
                TRIGGER_DESC && TRIGGER_DESC.forEach(
						item => {
                        const key = item.dataset.key;
                        if ( event.target.value === key ) {
                            item.classList.add( 'active' );
                        } else {
								item.classList.remove( 'active' );
                        }

						}
					);
				if ( event.target.value === 'order_status_changes' ) {
					TRIGGER_COL_2.classList.add( 'active' );
				} else {
					TRIGGER_COL_2.classList.remove( 'active' );
				}

				if ( event.target.value === 'customer_order_total_reaches' ) {
					TRIGGER_COL_3.classList.add( 'active' );
				} else {
					TRIGGER_COL_3.classList.remove( 'active' );
				}

				}
			);

			let event        = new Event( 'input' );
			let change_event = new Event( 'change' );
			(WHEN_DISPATCH) && WHEN_DISPATCH.dispatchEvent( event );
			(SELECT_WOOCOMMERCE_DATA) && SELECT_WOOCOMMERCE_DATA.dispatchEvent( event );
			(SELECT_WOOCOMMERCEORDERS) && SELECT_WOOCOMMERCEORDERS.dispatchEvent( event );
			(send_recipient) && send_recipient.dispatchEvent( event );
			(SENDING_TYPE) && SENDING_TYPE.dispatchEvent( event );
			(COMMUNICATION_METHODS) && COMMUNICATION_METHODS.forEach(
				item => {
                item.dispatchEvent( change_event );
				}
			);
			(STATUS_TRIGGER) && STATUS_TRIGGER.dispatchEvent( change_event );
			(DEFAULT_COMMUNICATION_METHOD) && DEFAULT_COMMUNICATION_METHOD.dispatchEvent( change_event );

			if ( SELECTED_DATE ) {
				$datepicker.datepicker( 'setDate', SELECTED_DATE[0] );
				$datepicker.value = SELECTED_DATE[0];
				TIME_VALUE.value  = SELECTED_DATE[1];
			}

			// Set Schedule Timeframe for Messages in setting tab
			SCHEDULE_TIMEFRAME && SCHEDULE_TIMEFRAME.forEach( item => item.value = item.dataset.scheduleTime );

			$('.js-notification-communication-preference').on('change', function () {
				if ($(this).prop('checked')) {
					// Если выбран один чекбокс, снимаем галочки с остальных
					$('.js-notification-communication-preference').not(this).prop('checked', false);
				}
			});

			// send order notification
			SEND_ORDER_NOTIFICATION && SEND_ORDER_NOTIFICATION.addEventListener(
				'click',
				( event ) => {
                event.preventDefault();
                const order_id                 = document.querySelector( '.js-order-id' ).value;
                const send_status              = document.querySelector( '.js-send-status' ).value;
                const subject                  = document.querySelector( '.js-subject' ).value;
                const communication_preference = document.querySelector( '.js-notification-communication-preference:checked' ).value;
                const product_values           = document.querySelector( '.js-product-values' ).value;
                const message_template_id      = document.getElementById( 'message_template_id' ).value;
				const zwf_send_order_nonce     = $( '#zwf_send_order_nonce' ).val();

                SEND_ORDER_NOTIFICATION && SEND_ORDER_NOTIFICATION.classList.add( 'disabled' );
                let formData = new FormData();
                formData.append( 'action', 'send_order_notification' );
                formData.append( 'notification', select_notification.value );
                formData.append( 'order_id', order_id );
                formData.append( 'subject', subject );
                formData.append( 'description', message_input.value );
                formData.append( 'send_status', send_status );
                formData.append( 'product_values', product_values );
                formData.append( 'communication_preference', communication_preference );
                formData.append( 'message_template_id', message_template_id );
                formData.append( 'zwf_send_order_nonce', zwf_send_order_nonce );
                fetch(
						ajax_object.ajax_url,
						{
							method: 'POST',
							body: formData,
						}
					)
						.then( response => response.json() )
						.then(
							response => {
                            if ( response.success ) {
                                window.location.reload();
                            }
							}
						);
				}
			);

			SELECT_WRAP && SELECT_WRAP.forEach(
				( product, index ) => {
                const label     = product.querySelector( 'a' );
                const select    = product.querySelector( 'select' );
                const close_btn = product.querySelector( '.zwf__close-btn' );
                label && label.addEventListener(
						'click',
						( event ) => {
                        event.preventDefault();
                        event.target.classList.add( 'disable' );
                        select.classList.add( 'active' );
                        close_btn.classList.add( 'active' );
						}
					);
				close_btn && close_btn.addEventListener(
					'click',
					( event ) => {
                    event.preventDefault();
                    event.target.classList.remove( 'active' );
                    label.classList.remove( 'disable' );
                    select.classList.remove( 'active' );
					}
				);
				$( '#timing_select-products-' + index ).on(
					'select2:select',
					( event ) => {
						if ( ! ZWF_MESSAGE.readOnly ) {
							ZWF_MESSAGE.value = ZWF_MESSAGE.value.trim() + ` ${event.target.value} `;
							PRODUCT_VALUES.value += `${event.target.value} `;
							close_btn.classList.remove( 'active' );
							label && label.classList.add( 'added' );
							label && label.classList.remove( 'disable' );
							select.classList.remove( 'active' );
							setTimeout(
								() => {
								label && label.classList.remove( 'added' );
								select.classList.remove( 'active' );
								},
								3000
							);
						}
					}
				);
				}
			);

			$( '#select-coupon' ).on(
				'select2:select',
				( event ) => {
                const wrap            = SELECT_WRAP[SELECT_WRAP.length - 1];
                const label           = wrap.querySelector( 'a' );
                const select          = wrap.querySelector( 'select' );
                const close_btn       = wrap.querySelector( '.zwf__close-btn' );
					if ( ! ZWF_MESSAGE.readOnly ) {
						ZWF_MESSAGE.value = ZWF_MESSAGE.value.trim() + ` ${event.target.value} `;
						PRODUCT_VALUES.value += `${event.target.value} `;
						close_btn.classList.remove( 'active' );
						label && label.classList.add( 'added' );
						label && label.classList.remove( 'disable' );
						select.classList.remove( 'active' );
						setTimeout(
								() => {
								label && label.classList.remove( 'added' );
								select.classList.remove( 'active' );
								},
								3000
							);
					}
				}
			);

			ctx && chart_functionality();
		}
	);
})( jQuery );

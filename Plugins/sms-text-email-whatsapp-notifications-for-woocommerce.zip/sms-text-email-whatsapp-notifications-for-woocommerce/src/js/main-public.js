import intlTelInput from '../js/libs/intlTelInput.min';

export function initializeIntlTelInput() {
	const WHATSAPP_PHONE = document.getElementById("whatsapp_phone");
	WHATSAPP_PHONE && intlTelInput(WHATSAPP_PHONE, {
		separateDialCode: true,
		initialCountry: ajax_object.whatsapp_country ? ajax_object.whatsapp_country : ajax_object.default_country_iso,
		utilsScript: ajax_object.intl_utils
	});

}

initializeIntlTelInput();
(function ( $ ) {
	$( document ).ready(
		function () {
			const SUBSCRIBE_TO_NEWSLETTER     = document.querySelector( '.js-subscribe_to_newsletter' );
			const email_or_number_error       = document.querySelector( '.email_or_number-wrap span' );
			const EMAIL_OR_NUMBER             = document.querySelector( '.js-email_or_number' );
			const NOTIFY_BUTTON_TEXT          = document.querySelector( '.js-notify-button-text' );
			const UNSUBSCRIBE_TO_NOTIFICATION = document.querySelector( '.js-unsubscribe_to_notification' );
			const SAVE_NOTIFICATION_DETAILS   = document.querySelector( '.js-woocommerce-notificationForm' );
			const BILLING_EMAIL               = document.querySelector( '.woocommerce-checkout .woocommerce-billing-fields #billing_email' );
			const BILLING_PHONE               = document.getElementById("billing_phone");
			const WHATSAPP_PHONE              = document.getElementById("whatsapp_phone");

			$('.zworkflow-select-input').change(function() {
				var $parentLi = $(this).closest('li');

				if ($(this).is(':checked')) {
					$('.zworkflow-select-cheque').slideUp();
					$parentLi.find('.zworkflow-select-cheque').slideDown();

					$('li').removeClass('active');
					$parentLi.addClass('active');
				} else {
					$parentLi.find('.zworkflow-select-cheque').slideUp();
					$parentLi.removeClass('active');
				}
			});

			$('#communication_preference').on('change', function() {
				var selectedValue = $(this).val();

				if (selectedValue === 'whatsapp') {
					$('#zworkflow-select-phone-type').addClass('active');
				} else {
					$('#zworkflow-select-phone-type').removeClass('active');
				}
			});

			$( document.body ).on( 'woocommerce_variation_has_changed', function() {
				var variationId = $(".variation_id").val();
				var productIdInput = $("input[name='product_id']");

				const product_id = (variationId === "") ? productIdInput.val(): variationId;
				const zwf_notify_in_product = $("#zwf_notify_in_product").val();

				$('#zworkwlof_product_id').val(product_id);

				$.post(
					{
						url: ajax_object.ajax_url,
						data: {
							'action': 'check_subscription_user',
							'variation_id': product_id,
							'zwf_notify_in_product': zwf_notify_in_product,
						},
						success: function ( response ) {
							const result = JSON.parse(response);

							if (result.status) {
								$('.notify_button_text_wrap_default, .notify_button_text_wrap').addClass('subscribed');
							} else {
								$('.notify_button_text_wrap_default, .notify_button_text_wrap').removeClass('subscribed');
							}
						}
					}
				);

			});

			BILLING_PHONE && intlTelInput(BILLING_PHONE, {
				separateDialCode: true,
				initialCountry: ajax_object.billing_country ? ajax_object.whatsapp_country : ajax_object.default_country_iso,
				utilsScript: ajax_object.intl_utils
			});

			if ( $("#whatsapp_phone").length > 0 ) {
				const phoneCode = $("#whatsapp_phone").closest('.iti--allow-dropdown').find('.iti__selected-dial-code').text();
				$("#zworkflow_whatsapp_code").val(phoneCode);
			}

			if ( $("#billing_phone").length > 0 ) {
				const phoneCode = $("#billing_phone").closest('.iti--allow-dropdown').find('.iti__selected-dial-code').text();
				const country = $("#billing_phone").closest('.iti--allow-dropdown').find('.iti__active').attr('data-country-code');

				$("#zworkflow_billing_code").val(phoneCode);
				$("#zworkflow_billing_country").val(country);

			}

			WHATSAPP_PHONE && WHATSAPP_PHONE.addEventListener("countrychange", function() {
				const parentElement = $(this).closest('.iti--allow-dropdown');

				const phoneCode = parentElement.find('.iti__selected-dial-code').text();

				const country = parentElement.find('.iti__active').attr('data-country-code');

				$("#zworkflow_whatsapp_code").val(phoneCode);
				$("#zworkflow_whatsapp_country").val(country);
			});

			BILLING_PHONE && BILLING_PHONE.addEventListener("countrychange", function() {
				const parentElement = $(this).closest('.iti--allow-dropdown');

				const phoneCode = parentElement.find('.iti__selected-dial-code').text();

				const country = parentElement.find('.iti__active').attr('data-country-code');

				$("#zworkflow_billing_code").val(phoneCode);
				$("#zworkflow_billing_country").val(country);
			});

			const debounce = ( fn, time = 1000 ) => {

				if ( ! fn ) {
					throw Error( '"debounce function - "You didn\'t add required parameters' );
				}

				let timeout;

				return function () {
					const functionCall = () => fn.apply( this, arguments );

					clearTimeout( timeout );
					timeout = setTimeout( functionCall, time );
				}
			};

			const validateEmail = ( email ) => {
				  return email.match( /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/ );
			};

			// subscribe to newsletter for not logged users
			SUBSCRIBE_TO_NEWSLETTER && SUBSCRIBE_TO_NEWSLETTER.addEventListener(
				'submit',
				( event ) => {
                event.preventDefault();
                email_or_number_error && email_or_number_error.classList.remove( 'error' );
                if ( EMAIL_OR_NUMBER && EMAIL_OR_NUMBER.value === '' ) {
                     email_or_number_error && email_or_number_error.classList.add( 'error' );
                     return;
                }
                NOTIFY_BUTTON_TEXT.disabled = true;
                let formData                = new FormData( event.target );
                formData.append( 'action', 'subscribe_to_newsletter' );
                fetch(
                        ajax_object.ajax_url,
                        {
						method: 'POST',
						body: formData,
						}
                    )
				.then( response => response.json() )
				.then(
					response => {
                    if ( response.success ) {
                        window.location.reload();
                    }
					}
				);
				}
			);

			// unsubscribe to newsletter
			UNSUBSCRIBE_TO_NOTIFICATION && UNSUBSCRIBE_TO_NOTIFICATION.addEventListener(
				'click',
				( event ) => {
                event.preventDefault();
                UNSUBSCRIBE_TO_NOTIFICATION && UNSUBSCRIBE_TO_NOTIFICATION.classList.add( 'disabled' );
                let formData = new FormData( SUBSCRIBE_TO_NEWSLETTER );
				const zwf_notify_in_product = $("#zwf_notify_in_product").val();
                formData.append( 'action', 'unsubscribe_to_newsletter' );
                formData.append( 'zwf_notify_in_product', zwf_notify_in_product );
                fetch(
                        ajax_object.ajax_url,
                        {
						method: 'POST',
						body: formData,
						}
                    )
				.then( response => response.json() )
				.then(
					response => {
                    if ( response.success ) {
                        window.location.reload();
                    }
					}
				);
				}
			);

			// save_notification_details
			SAVE_NOTIFICATION_DETAILS && SAVE_NOTIFICATION_DETAILS.addEventListener(
				'submit',
				( event ) => {
                event.preventDefault();
                SAVE_NOTIFICATION_DETAILS && SAVE_NOTIFICATION_DETAILS.classList.add( 'disabled' );
                let formData = new FormData( event.target );
                formData.append( 'action', 'save_notification_details' );
                fetch(
                        ajax_object.ajax_url,
                        {
						method: 'POST',
						body: formData,
						}
                    )
				.then( response => response.json() )
				.then(
					response => {
                    if ( response.success ) {
                        SAVE_NOTIFICATION_DETAILS && SAVE_NOTIFICATION_DETAILS.classList.remove( 'disabled' );
                    }
					}
				);
				}
			);

			// This function occurs when a new guest is captured.
			BILLING_EMAIL && BILLING_EMAIL.addEventListener(
				'input',
				debounce(
					( event ) => {
                    if ( ! isNaN( validateEmail( event.target.value ) ) ) {
                        return;
                    }
                    $.post(
							{
								url: ajax_object.ajax_url,
								data: {
									'action': 'new_guest_capture_action',
									'email': event.target.value
								}
							}
						);
					}
				)
			);

		}
	);
})( jQuery );

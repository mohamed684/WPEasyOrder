// JS Scripts
//import './js/libs/intlTelInput.min';
import './js/main';

// Styles
import './sass/screen.scss';

//Images
import './img/bizswoop.png';
import './img/flags.png';
import './img/flags@2x.png';
import './img/flow-notify-logo.png';
import './img/wpspin_light-2x.gif';
import './img/arrow-right.png';
<?php
/**
 * Flow-Notify Notifications tab
 * email template settings
 *
 * @package Flow-Notify/templates/emails/email-template-settings
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
}

$email_settings = get_option( 'notification_email_settings' );
?>
	<div class="zworkflowmanager_email_template_wrap">
		<h3 style="width: 100%;"><?php esc_html_e( 'Template Options', 'flow_notify_text' ); ?></h3>
		<div class="email_template_input_wrap">
			<label for="name"><?php esc_html_e( '"From" name', 'flow_notify_text' ); ?>
				<span title="How the sender name appears in outgoing WooCommerce emails."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short"
				name="name"
				id="name"
				value="<?php echo isset( $email_settings['name'] ) ? esc_attr( $email_settings['name'] ) : ''; ?>"
				required>
		</div>
		<div class="email_template_input_wrap">
			<label for="address"><?php esc_html_e( '"From" address', 'flow_notify_text' ); ?>
				<span title="How the sender email appears in outgoing WooCommerce emails."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short"
				name="address"
				id="address"
				value="<?php echo isset( $email_settings['address'] ) ? esc_attr( $email_settings['address'] ) : ''; ?>"
				required>
		</div>
		<h3 style="width: 100%;"><?php esc_html_e( 'Email template', 'flow_notify_text' ); ?></h3>
		<div class="email_template_input_wrap">
			<p><?php esc_html_e( 'This section lets you customize the Flow Notify emails.', 'flow_notify_text' ); ?></p>
			<a style="margin-left: 20px;" target="_blank"
			href="?page=wc-workflows&tab=emails&preview_email=true"><?php esc_html_e( 'Click here to preview your email template.', 'flow_notify_text' ); ?></a>
		</div>
		<div class="email_template_input_wrap">
			<label for="aw_custom_image"><?php esc_html_e( 'Header image', 'flow_notify_text' ); ?>
				<span title="URL to an image you want to show in the email header. Upload images using the media uploader (Admin > Media)."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short"
				name="aw_custom_image"
				style="width: 44%;"
				id="aw_custom_image"
				value="<?php echo isset( $email_settings['aw_custom_image'] ) ? esc_attr( $email_settings['aw_custom_image'] ) : ''; ?>"
				placeholder="N/A"/>
			<a href="#"
			class="aw_upload_image_button button button-secondary"><?php esc_html_e( 'Upload Image', 'flow_notify_text' ); ?></a>

		</div>
		<div class="email_template_input_wrap">
			<label for="footer_text"><?php esc_html_e( 'Footer text', 'flow_notify_text' ); ?>
				<span title="The text to appear in the footer of all WooCommerce emails. Available placeholders: {site_title} {site_url}"
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<textarea class="short"
					name="footer_text"
					id="footer_text"
					rows="4"
					cols="50"
					placeholder="N/A"
					spellcheck="false"><?php echo isset( $email_settings['footer_text'] ) ? esc_attr( $email_settings['footer_text'] ) : ''; ?></textarea>
		</div>
		<div class="email_template_input_wrap">
			<label for="base_color"><?php esc_html_e( 'Base color', 'flow_notify_text' ); ?>
				<span title="The base color for WooCommerce email templates. Default #96588a."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short zworkflowmanager_wp_colorpick"
				name="base_color"
				id="base_color"
				value="<?php echo isset( $email_settings['base_color'] ) ? esc_attr( $email_settings['base_color'] ) : ''; ?>">
		</div>
		<div class="email_template_input_wrap">
			<label for="background_color"><?php esc_html_e( 'Background color', 'flow_notify_text' ); ?>
				<span title="The background color for WooCommerce email templates. Default #f7f7f7."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short zworkflowmanager_wp_colorpick"
				name="background_color"
				id="background_color"
				value="<?php echo isset( $email_settings['background_color'] ) ? esc_attr( $email_settings['background_color'] ) : ''; ?>">
		</div>
		<div class="email_template_input_wrap">
			<label for="body_bg_color"><?php esc_html_e( 'Body background color', 'flow_notify_text' ); ?>
				<span title="The main body background color. Default #ffffff."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short zworkflowmanager_wp_colorpick"
				name="body_bg_color"
				id="body_bg_color"
				value="<?php echo isset( $email_settings['body_bg_color'] ) ? esc_attr( $email_settings['body_bg_color'] ) : ''; ?>">
		</div>
		<div class="email_template_input_wrap">
			<label for="body_text_color"><?php esc_html_e( 'Body text color', 'flow_notify_text' ); ?>
				<span title="The main body text color. Default #3c3c3c."
					class="email_template-help-tip js-email_template-help-tip"></span>
			</label>
			<input type="text"
				class="short zworkflowmanager_wp_colorpick"
				name="body_text_color"
				id="body_text_color"
				value="<?php echo isset( $email_settings['body_text_color'] ) ? esc_attr( $email_settings['body_text_color'] ) : ''; ?>">
		</div>
	</div>

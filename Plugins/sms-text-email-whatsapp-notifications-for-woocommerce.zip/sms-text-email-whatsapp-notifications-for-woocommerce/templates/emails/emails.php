<?php
/**
 * Flow-Notify Notifications tab
 *
 * @package Flow-Notify/templates/emails
 */

$email_tab               = ( isset( $_GET['tab'] ) ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
$order_status_tab_active = ( 'order_status' === $email_tab ) ? 'nav-tab-active' : ' ';
$emails_tab_active       = ( 'emails' === $email_tab ) ? 'nav-tab-active' : ' ';
$section                 = ( isset( $_GET['section'] ) ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';
$preview_email           = ( isset( $_GET['preview_email'] ) ) ? sanitize_text_field( wp_unslash( $_GET['preview_email'] ) ) : '';
$add_new_email           = ( ! isset( $_GET['add_new_email'] ) && ! isset( $_GET['edit_email'] ) ) ? 1 : 0;

if ( 'emails' === $email_tab ) {
	if ( $add_new_email ) {
		?>
	<div class="wrap woocommerce flex-wrap" style="margin-top:10px;">
		<h3 class="workflows-title"><?php echo esc_html__( 'Notifications', 'flow_notify_text' ); ?></h3>
		<a href="?page=wc-workflows&tab=emails&section=notifications&add_new_email=1"
		   class="page-title-action"
		   style="margin-left:15px;"><?php echo esc_html__( 'Add', 'flow_notify_text' ); ?></a>
	</div>
	<div class="zworkflowmanager-notifications-header">
		<a href="?page=wc-workflows&tab=emails&section=notifications" class="<?php echo ( 'message-templates' !== $section ) ? 'active' : ''; ?>">My notifications</a>
		<a href="?page=wc-workflows&tab=emails&section=message-templates" class="<?php echo ( 'message-templates' === $section ) ? 'active' : ''; ?>">Message templates</a>
	</div>
		<?php if ( 'message-templates' === $section && ! isset( $_GET['add_new_template'] ) && ! isset( $_GET['edit_template'] ) ) { ?>
	<div class="zworkflowmanager-create-template-wrapper">
		<span>Create message templates to easily use in building notifications</span>
		<a class="zworkflowmanager-create-template" href="?page=wc-workflows&tab=emails&section=message-templates&add_new_template=1">Create template</a>
	</div>
	<?php } ?>
		<?php
	}
	if ( 'message-templates' === $section ) {
		$edit_template_status = ( isset( $_GET['edit_template'] ) ) ? sanitize_text_field( wp_unslash( $_GET['edit_template'] ) ) : 0;
		$add_new_template     = ( isset( $_GET['add_new_template'] ) ) ? sanitize_text_field( wp_unslash( $_GET['add_new_template'] ) ) : 0;

		if ( 0 !== $edit_template_status ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/message-templates/edit-template-status.php';
		} elseif ( 0 !== $add_new_template ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/message-templates/new-template-status.php';
		} else {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-message-templates.php';

			$status_templates_list = new ZWORKFLOWMANAGER_Core_Message_Templates();
			$status_templates_list->print_overview();
		}
	} else {
		$edit_email_status = ( isset( $_GET['edit_email'] ) ) ? sanitize_text_field( wp_unslash( $_GET['edit_email'] ) ) : 0;
		$add_new           = ( isset( $_GET['add_new_email'] ) ) ? sanitize_text_field( wp_unslash( $_GET['add_new_email'] ) ) : 0;

		if ( 0 !== $edit_email_status ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/edit-email-status.php';
		} elseif ( 0 !== $add_new ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/new-email-status.php';
		} elseif ( 'true' === $preview_email ) {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/templates/plain/email-form.php';
		} else {
			require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-status-emails.php';

			$status_emails_list = new ZWORKFLOWMANAGER_Core_Status_Emails();
			$status_emails_list->print_overview();
		}
	}
}

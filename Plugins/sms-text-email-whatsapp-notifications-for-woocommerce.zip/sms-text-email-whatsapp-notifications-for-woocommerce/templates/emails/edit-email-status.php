<?php
/**
 * Flow-Notify Notifications tab
 * edit notification
 *
 * @package Flow-Notify/templates/emails/edit-email-status
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
}

$edit_status_email = ( isset( $_GET['edit_email'] ) && ! empty( $_GET['edit_email'] ) ? sanitize_text_field( wp_unslash( $_GET['edit_email'] ) ) : 0 );

if ( 0 === (int) $edit_status_email ) {
	?>
	<h3><?php esc_html_e( 'Order Status Email doesn\'t exist', 'flow_notify_text' ); ?></h3>
	<?php
}

$status_email                 = new ZWORKFLOWMANAGER_Status_Email( $edit_status_email );
$checked                      = $status_email->get_status() === 'enabled' ? 'checked' : '';
$checked_text                 = $status_email->get_status() === 'enabled' ? 'Enabled' : 'Disabled';
$checked_type_preference      = $status_email->get_type_preference() === 'enabled' ? 'checked' : '';
$checked_type_preference_text = $status_email->get_type_preference() === 'enabled' ? 'Enabled' : 'Disabled';

$message_templates_sms = new WP_Query(
	array(
		'post_type'  => 'zworkflowtemplates',
		'meta_query' => array(
			array(
				'key'   => 'zmessagetemplate_status',
				'value' => 'enabled',
			),
			array(
				'key'   => 'zsending_type',
				'value' => 'sms',
			),
		),
	)
);

$message_templates_emails = new WP_Query(
	array(
		'post_type'  => 'zworkflowtemplates',
		'meta_query' => array(
			array(
				'key'   => 'zmessagetemplate_status',
				'value' => 'enabled',
			),
			array(
				'key'   => 'zsending_type',
				'value' => 'email',
			),
		),
	)
);

$message_templates_whatsapp = new WP_Query(
	array(
		'post_type'  => 'zworkflowtemplates',
		'meta_query' => array(
			array(
				'key'   => 'zmessagetemplate_status',
				'value' => 'enabled',
			),
			array(
				'key'   => 'zsending_type',
				'value' => 'whatsapp',
			),
			array(
				'key'   => 'zapproval_status',
				'value' => 'APPROVED',
			),
		),
	)
);

?>
<h2 class="workflows-title">
	<?php esc_html_e( 'Edit Notification', 'flow_notify_text' ); ?>
</h2>
<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>" id="zworkflowmanager_edit_status">
	<input type="hidden" name="action" value="zworkflowmanager_edit_email"/>
	<input type="hidden" name="status_id" value="<?php echo esc_attr( $edit_status_email ); ?>"/>
	<?php $nonce = wp_create_nonce( 'zfn_operation_type' ); ?>
	<input type="hidden" name="zwf_nonce" value="<?php echo esc_attr( $nonce ); ?>" />
	<div class="zworkflowmanager_order_wrapper">
		<div id="zworkflowmanager_order_status_data">
			<table class="zworkflowmanager_row zworkflowmanager_col_12">
				<tbody class="zworkflowmanager_row zworkflowmanager_col_12">
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding"><?php esc_html_e( 'Status', 'flow_notify_text' ); ?></td>
					<td class="status column-status zworkflowemail_status_toggle">
						<label class="zworkflowmanager_switch">
							<input type="checkbox"
								id="status_toggle"
								name="status_toggle"
								<?php echo esc_attr( $checked ); ?>
								class="js-zworkflowmanager_status_switcher">
							<span class="zworkflowmanager_slider round"></span>
						</label>
						<span class="js-status-text status-text"><?php echo esc_textarea( $checked_text ); ?></span>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="post_title"><?php esc_html_e( 'Name', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<input type="text"
							class="short"
							style=""
							name="post_title"
							id="post_title"
							value="<?php echo esc_attr( $status_email->get_name() ); ?>"
							required
							placeholder=""
							maxlength="35">
					</td>
				</tr>

				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="recipient"><?php esc_html_e( 'Recipient', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<select id="recipient" name="type">
							<?php
							$recipient_types = array( 'customer', 'admin' );

							foreach ( $recipient_types as $r_type ) {
								$selected = selected( $r_type, $status_email->get_type(), false );
								echo '<option value="' . esc_attr( $r_type ) . '" ' . esc_attr( $selected ) . '>' . esc_textarea( ucfirst( $r_type ) ) . '</option>';
							}
							?>
						</select>
					</td>
				</tr>

				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="type"><?php esc_html_e( 'Type', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<select id="type" name="sending_type" class="js-sending-type zworkflow-sending-type">
							<option value="SMS"<?php echo ( 'sms' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'SMS', 'flow_notify_text' ); ?></option>
							<option value="email"<?php echo ( 'email' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Email', 'flow_notify_text' ); ?></option>
							<option value="whatsapp"<?php echo ( 'whatsapp' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'WhatsApp', 'flow_notify_text' ); ?></option>
						</select>
					</td>
				</tr>

				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row sms-lists message-templates-lists<?php echo ( 'SMS' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' active' : ''; ?>">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<?php esc_html_e( 'Message Templates', 'flow_notify_text' ); ?>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<?php
						if ( $message_templates_sms->have_posts() ) {
							?>
							<select name="message_template" class="zworkflow_message_template">
								<option selected disabled>Select a message template...</option>
								<?php
								while ( $message_templates_sms->have_posts() ) {
									$message_templates_sms->the_post();
									?>
									<option value="<?php the_ID(); ?>"<?php echo ( get_the_ID() == get_post_meta( $edit_status_email, 'message_template_id', true ) ) ? ' selected' : ''; ?>><?php the_title(); ?></option>
								<?php } ?>
							</select>
							<?php
						}
						?>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row emails-lists message-templates-lists<?php echo ( 'email' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' active' : ''; ?>">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<?php esc_html_e( 'Message Templates', 'flow_notify_text' ); ?>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<?php
						if ( $message_templates_emails->have_posts() ) {
							?>
							<select name="message_template" class="zworkflow_message_template">
								<option selected disabled>Select a message template...</option>
								<?php
								while ( $message_templates_emails->have_posts() ) {
									$message_templates_emails->the_post();
									?>
									<option value="<?php the_ID(); ?>"<?php echo ( get_the_ID() == get_post_meta( $edit_status_email, 'message_template_id', true ) ) ? ' selected' : ''; ?>><?php the_title(); ?></option>
								<?php } ?>
							</select>
							<?php
						}
						?>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row whatsapp-lists message-templates-lists<?php echo ( 'whatsapp' === get_post_meta( $edit_status_email, 'zsending_type', true ) ) ? ' active' : ''; ?>">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<?php esc_html_e( 'Message Templates', 'flow_notify_text' ); ?>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<?php
						if ( $message_templates_whatsapp->have_posts() ) {
							?>
							<select name="message_template" class="zworkflow_message_template">
								<option selected disabled>Select a message template...</option>
								<?php
								while ( $message_templates_whatsapp->have_posts() ) {
									$message_templates_whatsapp->the_post();
									?>
									<option value="<?php the_ID(); ?>"<?php echo ( get_the_ID() == get_post_meta( $edit_status_email, 'message_template_id', true ) ) ? ' selected' : ''; ?>><?php the_title(); ?></option>
								<?php } ?>
							</select>

							<?php
						}
						?>
					</td>
				</tr>

				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding"><?php esc_html_e( 'Type Preference', 'flow_notify_text' ); ?></td>
					<td class="status column-status zworkflowemail_status_toggle">
						<label for="type_preference_status_toggle" class="zworkflowmanager_switch">
							<input type="checkbox"
								id="type_preference_status_toggle"
								name="type_preference_status_toggle"
								<?php echo esc_attr( $checked_type_preference ); ?>
								class="js-type-preference_switcher">
							<span class="zworkflowmanager_slider round"></span>
						</label>
						<span class="js-type-preference-status-text status-text"><?php echo esc_textarea( $checked_type_preference_text ); ?></span>
						<span class="status-text"><?php esc_html_e( 'Send to customer based upon selected communication preference', 'flow_notify_text' ); ?></span>
					</td>
				</tr>

				<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/templates/trigger.php'; ?>
				<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/templates/timing.php'; ?>
				</tbody>
			</table>
		</div>

		<?php
		$delete_link       = admin_url( 'admin.php?page=wc-workflows&tab=connection&zfn_operation_type=delete_notification&notification_id=' . $edit_status_email );
		$delete_nonce_link = wp_nonce_url( $delete_link, 'zfn_operation_type', 'zwf_nonce' );
		?>

		<button type="submit"
				class="button button-primary"><?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?></button>
		<a href="<?php echo esc_url( $delete_nonce_link ); ?>"
		class="button delete-notification-btn js-delete-notification">
			<?php esc_html_e( 'Delete', 'flow_notify_text' ); ?>
		</a>
	</div>
</form>

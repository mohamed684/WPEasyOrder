<?php
/**
 * Flow-Notify Notifications/timing
 *
 * @package Flow-Notify/templates/emails/templates/timing
 */

?>

<?php
$edit_email = ( isset( $_GET['edit_email'] ) ) ? sanitize_text_field( wp_unslash( $_GET['edit_email'] ) ) : '';

if ( isset( $edit_email ) ) {
	$timing_settings   = get_post_meta( $edit_email, 'zcustomemail_timing_settings', true );
	$timeframe_enabled = get_post_meta( $edit_email, 'zcustomemail_timeframe_enabled', true );
}

if ( ! isset( $timing_settings ) || ! is_array( $timing_settings ) ) {
	$timing_settings = array();
}
?>

<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row timing timing__col-3 js-timing-col-3">
	<td class="zworkflowmanager_col_6 timing__column">
		<label class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
			   for="from_timing_element"><?php esc_html_e( 'Timing', 'flow_notify_text' ); ?> <span class="required">*</span></label>
	</td>
	<td class="zworkflowmanager_col_6 timing__column">
		<select name="timing" id="zworkflowmanager_timing_select">
			<option value="0" data-id="zworkflowmanager_immediately"><?php esc_html_e( 'Run immediately', 'flow_notify_text' ); ?></option>
			<option value="delayed" data-id="zworkflowmanager_delayed"<?php echo ( isset( $timing_settings['timing_type'] ) && 'delayed' === $timing_settings['timing_type'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Delayed', 'flow_notify_text' ); ?></option>
			<option value="scheduled" data-id="zworkflowmanager_scheduled"<?php echo ( isset( $timing_settings['timing_type'] ) && 'scheduled' === $timing_settings['timing_type'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Scheduled', 'flow_notify_text' ); ?></option>
			<option value="fixed" data-id="zworkflowmanager_fixed"<?php echo ( isset( $timing_settings['timing_type'] ) && 'fixed' === $timing_settings['timing_type'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Fixed', 'flow_notify_text' ); ?></option>
		</select>

		<div id="zworkflowmanager_delayed" class="timing-variant<?php echo ( isset( $timing_settings['timing_type'] ) && 'delayed' === $timing_settings['timing_type'] ) ? ' visible' : ''; ?>">
			<input type="number" name="delayed_time" id="zwf_delayed_time" class="zworkflowmanager_req" min="0" placeholder="Delayed time" value="<?php echo ( isset( $timing_settings['delayed_time'] ) && $timing_settings['delayed_time'] ) ? esc_attr( $timing_settings['delayed_time'] ) : ''; ?>">
			<select name="time_unit" class="zworkflowmanager_req">
				<option value="minutes"<?php echo ( isset( $timing_settings['time_unit'] ) && 'minutes' === $timing_settings['time_unit'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Minutes', 'flow_notify_text' ); ?></option>
				<option value="hours"<?php echo ( isset( $timing_settings['time_unit'] ) && 'hours' === $timing_settings['time_unit'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Hours', 'flow_notify_text' ); ?></option>
				<option value="days"<?php echo ( isset( $timing_settings['time_unit'] ) && 'days' === $timing_settings['time_unit'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Days', 'flow_notify_text' ); ?></option>
				<option value="weeks"<?php echo ( isset( $timing_settings['time_unit'] ) && 'weeks' === $timing_settings['time_unit'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Weeks', 'flow_notify_text' ); ?></option>
				<option value="months"<?php echo ( isset( $timing_settings['time_unit'] ) && 'months' === $timing_settings['time_unit'] ) ? ' selected' : ''; ?>><?php esc_html_e( 'Months', 'flow_notify_text' ); ?></option>
			</select>

		</div>
		<div id="zworkflowmanager_scheduled" class="timing-variant<?php echo ( isset( $timing_settings['timing_type'] ) && 'scheduled' === $timing_settings['timing_type'] ) ? ' visible' : ''; ?>">
			<input type="time" class="schedule_timeframe zworkflowmanager_req"
				   name="schedule_time"
				   id="schedule_timeframe_from" value="<?php echo ( isset( $timing_settings['schedule_time'] ) ) ? esc_attr( $timing_settings['schedule_time'] ) : ''; ?>">
			<select name="select_days[]" id="zworkflowmanager_select_days" class="zworkflowmanager_req" multiple="multiple">
				<option value="1"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 1, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Monday', 'flow_notify_text' ); ?></option>
				<option value="2"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 2, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Tuesday', 'flow_notify_text' ); ?></option>
				<option value="3"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 3, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Wednesday', 'flow_notify_text' ); ?></option>
				<option value="4"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 4, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Thursday', 'flow_notify_text' ); ?></option>
				<option value="5"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 5, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Friday', 'flow_notify_text' ); ?></option>
				<option value="6"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 6, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Saturday', 'flow_notify_text' ); ?></option>
				<option value="7"<?php echo ( isset( $timing_settings['select_days'] ) && is_array( $timing_settings['select_days'] ) && in_array( 7, $timing_settings['select_days'] ) ) ? ' selected' : ''; ?>><?php esc_html_e( 'Sunday', 'flow_notify_text' ); ?></option>
			</select>
		</div>
		<div id="zworkflowmanager_fixed" class="timing-variant<?php echo ( isset( $timing_settings['timing_type'] ) && 'fixed' === $timing_settings['timing_type'] ) ? ' visible' : ''; ?>">
			<input class="js-date-time-input zworkflowmanager_req" data-role="disabled-btn" type="text" name="timing_datepicker" id="timing-datepicker" placeholder="YYYY-MM-DD" value="<?php echo ( isset( $timing_settings['timing_datepicker'] ) ) ? esc_attr( $timing_settings['timing_datepicker'] ) : ''; ?>">
			<input type="time" class="schedule_timeframe zworkflowmanager_req" name="fixed_time" value="<?php echo ( isset( $timing_settings['fixed_time'] ) ) ? esc_attr( $timing_settings['fixed_time'] ) : ''; ?>">
		</div>
	</td>
	<td class="zworkflowmanager_col_6 timing__column">
		<?php esc_html_e( 'Message Schedule Timeframe', 'flow_notify_text' ); ?>
	</td>
	<td class="zworkflowmanager_col_6 zworkflowemail_status_toggle">
		<label class="zworkflowmanager_switch">
			<input type="checkbox"
				   id="schedule_timeframe"
				   name="schedule_timeframe"
				   class="js-message-schedule-switcher"<?php echo ( isset( $timeframe_enabled ) && 'on' === $timeframe_enabled ) ? ' checked' : ''; ?>>
			<span class="zworkflowmanager_slider round"></span>
		</label>
		<span class="js-message-schedule-text"><?php esc_html_e( 'Disabled', 'flow_notify_text' ); ?></span> <span><?php esc_html_e( 'Messages will only be sent in the Message Schedule Timeframe', 'flow_notify_text' ); ?></span>
	</td>
	<td class="zworkflowmanager_col_6 timing__column"></td>
	<td class="zworkflowmanager_col_6 timing__column">
		<span id="warning-schedule">
		<?php esc_html_e( 'Warning: When disabled messages can be sent outside the Message Schedule TimeFrame.', 'flow_notify_text' ); ?>
		<a href="?page=wc-workflows&tab=settings" target="_blank"><?php esc_html_e( 'View Schedule', 'flow_notify_text' ); ?></a>
		</span>
	</td>
</tr>

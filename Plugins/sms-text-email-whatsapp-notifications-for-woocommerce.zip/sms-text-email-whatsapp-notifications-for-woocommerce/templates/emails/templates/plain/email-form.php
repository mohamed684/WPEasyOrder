<?php
/**
 * Flow-Notify Notifications/Template tab
 *
 * @package Flow-Notify/templates/emails/templates/plain/email-form
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$email_settings    = get_option( 'notification_email_settings' );
$order_hash_email  = get_option( 'order_hash_email' );
$unsubscribe_email = '';

if ( is_array( $order_hash_email ) ) {
	foreach ( $order_hash_email as $h_email ) {
		$clean_str        = substr( $h_email['email'], 0, - 32 );
		$order_user_email = substr( $clean_str, 32 );

		if ( $email === $order_user_email ) {
			$unsubscribe_email = get_site_url() . '?unsubscribe_email=' . $email . '&type=' . $h_email['type'];
		}
	}
}
$site_info = array(
	'site_url'   => get_site_url(),
	'site_title' => get_bloginfo(),
);
foreach ( $site_info as $key => $value ) {
	$email_settings['footer_text'] = str_replace( '{' . $key . '}', $value, $email_settings['footer_text'] );
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> lang="en-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>"/>
	<title><?php echo esc_textarea( get_bloginfo( 'name', 'display' ) ); ?></title>
</head>
<body <?php echo is_rtl() ? 'rightmargin' : 'leftmargin'; ?>="0" marginwidth="0" topmargin="0" marginheight="0" offset="
0">
<div id="wrapper" dir="<?php echo esc_attr( is_rtl() ? 'rtl' : 'ltr' ); ?>" style="background-color: <?php echo esc_attr( $email_settings['background_color'] ); ?>; margin: 0; padding: 70px 0; width: 100%; -webkit-text-size-adjust: none;">
	<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
		<tr>
			<td align="center" valign="top">
				<div id="template_header_image">
					<?php
					echo '<p style="margin-top:0;"><img src="' . esc_attr( $email_settings['aw_custom_image'] ) . '" alt="' . esc_attr( get_bloginfo( 'name', 'display' ) ) . '" /></p>';
					?>
				</div>
				<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_container">
					<tr>
						<td align="center" valign="top">
							<!-- Header -->
							<table border="0" cellpadding="0" cellspacing="0" width="100%" id="template_header">
								<tr>
									<td style="padding: 36px 48px; display: block; background: <?php echo esc_attr( $email_settings['base_color'] ); ?>" id="header_wrapper">
										<h1>
											<?php
											echo ( $subject ) ? esc_textarea( $subject )
												: 'HTML email template';
											?>
										</h1>
									</td>
								</tr>
							</table>
							<!-- End Header -->
						</td>
					</tr>
					<tr>
						<td align="center" valign="top">
							<!-- Body -->
							<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_body">
								<tr>
									<td valign="top" id="body_content" style="background: <?php echo esc_attr( $email_settings['body_bg_color'] ); ?>;">
										<!-- Content -->
										<table border="0" cellpadding="20" cellspacing="0" width="100%">
											<tr>
												<td valign="top" style="padding: 48px 48px 32px;">
													<div id="body_content_inner" style="color: <?php echo esc_attr( $email_settings['body_text_color'] ); ?>;">
														<?php
														echo ( $message ) ? esc_textarea( $message )
															: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda deleniti dicta ea esse illum impedit omnis ratione repellat saepe vitae. Accusamus atque aut ducimus earum eos ipsa itaque molestias! Reprehenderit!';
														?>
													</div>
												</td>
											</tr>
										</table>
										<!-- End Content -->
									</td>
								</tr>
							</table>
							<!-- End Body -->
						</td>
					</tr>
					<tr>
						<td align="center" valign="top">
							<!-- Body -->
							<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_body">
								<tr>
									<td valign="top" id="body_content" style="background: <?php echo esc_attr( $email_settings['body_bg_color'] ); ?>;">
										<!-- Content -->
										<table border="0" cellpadding="20" cellspacing="0" width="100%">
											<tr>
												<td valign="top" style="padding: 48px 48px 32px;">
													<div id="body_content_inner" style="color: <?php echo esc_attr( $email_settings['body_text_color'] ); ?>;">
														<a href="<?php echo esc_url( $unsubscribe_email ); ?>">Opt-out of notification</a>
													</div>
												</td>
											</tr>
										</table>
										<!-- End Content -->
									</td>
								</tr>
							</table>
							<!-- End Body -->
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td align="center" valign="top">
				<!-- Footer -->
				<table border="0" cellpadding="10" cellspacing="0" width="600" id="template_footer">
					<tr>
						<td valign="top">
							<table border="0" cellpadding="10" cellspacing="0" width="100%">
								<tr>
									<td colspan="2" valign="middle" id="credit" style="border-radius: 6px; border: 0; color: #f69a9a; font-size: 12px; line-height: 150%; text-align: center; padding: 24px 0;">
										<?php echo esc_textarea( $email_settings['footer_text'] ); ?>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<!-- End Footer -->
			</td>
		</tr>
	</table>
</div>
</body>
</html>

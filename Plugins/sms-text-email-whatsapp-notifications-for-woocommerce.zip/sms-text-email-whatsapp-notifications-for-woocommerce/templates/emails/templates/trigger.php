<?php
/**
 * Flow-Notify Notifications/trigger
 *
 * @package Flow-Notify/templates/emails/templates/trigger
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Status_Email' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-status-email.php';
}

$trigger_arr = array(
	'order_status_changes'         => array(
		'title'       => 'Order Status Changes',
		'description' => 'Triggers after an order changes status occurs. Set the workflow to run on certain status changes with the trigger options.',
	),
	'order_created'                => array(
		'title'       => 'Order Created',
		'description' => 'This trigger fires after an order is created in the database. At checkout this happens before payment is confirmed.',
	),
	'order_paid'                   => array(
		'title'       => 'Order Paid',
		'description' => 'Triggers at the end of the payment process after the order status has been changed and stock has been reduced.',
	),
	'customer_account_created'     => array(
		'title'       => 'Customer Account Created',
		'description' => 'New customer is created in the database.',
	),
	'customer_opted_in'            => array(
		'title'       => 'Customer Opted in',
		'description' => 'Customer opt-in to the notifications.',
	),
	'customer_opted_out'           => array(
		'title'       => 'Customer Opted out',
		'description' => 'Customer opt-out to the notifications.',
	),
	'customer_order_total_reaches' => array(
		'title'       => 'Customer Order Total Reaches',
		'description' => 'This trigger checks the customer\'s total spend each time an order is completed.',
	),
	'new_guest_capture'            => array(
		'title'       => 'New Guest Capture',
		'description' => 'This trigger occurs when a new guest is captured. Usually immediately after an email is entered at checkout.',
	),
	'new_review_submitted'         => array(
		'title'       => 'New Review Submitted',
		'description' => 'This trigger occurs when a new review is submitted.',
	),
	'new_review_posted'            => array(
		'title'       => 'New Review Posted',
		'description' => 'This trigger does not fire until the review has been approved.',
	),
);

$get_dispatch_list  = $status_email->get_dispatch_list();
$from_dispatch_list = ( ! is_null( $get_dispatch_list ) && isset( explode( '_to_', $get_dispatch_list )[0] ) ) ? 'wc-' . explode( '_to_', $get_dispatch_list )[0] : '';
$to_dispatch_list   = ( ! is_null( $get_dispatch_list ) && isset( explode( '_to_', $get_dispatch_list )[1] ) ) ? 'wc-' . explode( '_to_', $get_dispatch_list )[1] : '';
?>
<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row trigger trigger__col-1">
	<td class="zworkflowmanager_col_6 trigger__column-1">
		<label for="dispatch"><?php esc_html_e( 'Triggger', 'flow_notify_text' ); ?>
			<span class="required">*</span>
		</label>
	</td>
	<td class="zworkflowmanager_row zworkflowmanager_col_6">
		<select class="zworkflowmanager_col_12 zworkflowmanager_to_status_select_initial js-status-trigger"
				name="trigger"
				id="trigger">
			<option><?php esc_html_e( 'Select Status', 'flow_notify_text' ); ?></option>
			<?php
			foreach ( $trigger_arr as $key => $item ) {
				$selected = selected( $key, $status_email->get_trigger_status(), false );
				?>
				<option value="<?php echo esc_attr( $key ); ?>"
					<?php echo esc_attr( $selected ); ?>>
					<?php echo esc_textarea( $item['title'] ); ?>
				</option>
			<?php } ?>
		</select>
		<?php
		foreach ( $trigger_arr as $key => $item ) {
			?>
			<span class="js-trigger-desc trigger__description" data-key="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_textarea( $item['description'] ); ?>
			</span>
		<?php } ?>
	</td>
</tr>
<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row trigger trigger__col-2 js-trigger-col-2">
	<td class="zworkflowmanager_col_6 trigger__column">
		<label class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
			for="from_dispatch_element"><?php esc_html_e( 'Status changes from', 'flow_notify_text' ); ?></label>
	</td>
	<td class="zworkflowmanager_row zworkflowmanager_col_6 trigger__column">
		<select class="zworkflowmanager_col_12 zworkflowmanager_from_status_select_initial"
				data-role="dispatch-status-from"
				name="from_dispatch_element"
				id="from_dispatch_element">
			<?php
			$ajax_order_statuses        = wc_get_order_statuses();
			$ajax_order_statuses['any'] = 'Any';
			ksort( $ajax_order_statuses );
			foreach ( $ajax_order_statuses as $key => $value ) {
				?>
				<option value="<?php echo esc_attr( $key ); ?>"
					<?php echo esc_attr( selected( $key, $from_dispatch_list, false ) ); ?>>
					<?php echo esc_textarea( $value ); ?>
				</option>
			<?php } ?>
		</select>
	</td>

	<td class="zworkflowmanager_col_6 trigger__column">
		<label class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
			for="to_dispatch_element">
			<?php esc_html_e( 'Status changes to', 'flow_notify_text' ); ?>
		</label>
	</td>
	<td class="zworkflowmanager_row zworkflowmanager_col_6 trigger__column">
		<select class="zworkflowmanager_col_12 zworkflowmanager_to_status_select_initial"
				data-role="dispatch-status-to"
				name="to_dispatch_element"
				id="to_dispatch_element">
			<?php
			$ajax_order_statuses        = wc_get_order_statuses();
			$ajax_order_statuses['any'] = 'Any';
			ksort( $ajax_order_statuses );
			foreach ( $ajax_order_statuses as $key => $value ) {
				?>
				<option value="<?php echo esc_attr( $key ); ?>"
					<?php echo esc_attr( selected( $key, $to_dispatch_list, false ) ); ?>>
					<?php echo esc_textarea( $value ); ?>
				</option>
			<?php } ?>
		</select>
	</td>
</tr>

<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row trigger trigger__col-3 js-trigger-col-3">
	<td class="zworkflowmanager_col_6 trigger__column">
		<label class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding"
			for="from_dispatch_element"><?php esc_html_e( 'Total Spend', 'flow_notify_text' ); ?></label>
	</td>
	<td class="zworkflowmanager_row zworkflowmanager_col_6 trigger__column">
		<input type="number" name="total_spend" value="<?php echo esc_attr( $status_email->get_total_spend() ); ?>">
		<span class="trigger__plus-description">
				<?php esc_html_e( 'Note: Do not add currency symbol', 'flow_notify_text' ); ?>
		</span>
	</td>
</tr>

<?php
/**
 * Flow-Notify connection tab
 *
 * @package Flow-Notify/templates/connection
 */

$is_connected      = get_option( 'twilio_connection' );
$is_connected_wa   = get_option( 'whatsapp_connection' );
$twilio_settings   = get_option( 'twilio_settings' );
$whatsapp_settings = get_option( 'whatsapp_settings' );

$account_sid       = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'account_sid' );
$account_sid_test  = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'account_sid_test' );
$auth_token        = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'auth_token' );
$auth_token_test   = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'auth_token_test' );
$from_number       = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'from_number' );
$from_number_test  = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'from_number_test' );
$to_number         = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'to_number' );
$to_number_test    = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'to_number_test' );
$phone_to_test_msg = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'phone_to_test_msg' );
$quick_send        = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'quick_send' );
$response_message  = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'response_message' );
$sender_id         = ZWORKFLOWMANAGER_Core::get_field_value( $twilio_settings, 'sender_id' );

/* Encode Security data with "*" to prevent showing to frontend */
$encoded_account_sid          = ZWORKFLOWMANAGER_Core::character_string_replacer( $account_sid, 0, - 5, '*' );
$encoded_account_sid_test     = ZWORKFLOWMANAGER_Core::character_string_replacer( $account_sid_test, 0, - 5, '*' );
$encoded_auth_token           = ZWORKFLOWMANAGER_Core::character_string_replacer( $auth_token, 0, - 5, '*' );
$encoded_auth_token_test      = ZWORKFLOWMANAGER_Core::character_string_replacer( $auth_token_test, 0, - 5, '*' );
$checked                      = isset( $twilio_settings['account_credentials'] ) ? 'checked' : '';
$checked_whatsapp             = isset( $whatsapp_settings['whatsapp_account_credentials'] ) ? 'checked' : '';
$checked_return_sms           = isset( $twilio_settings['status_return_sms_message'] ) ? 'checked' : '';
$checked_sender_id            = isset( $twilio_settings['status_sender_id'] ) ? 'checked' : '';
$checked_concatenate_messages = isset( $twilio_settings['concatenate_messages'] ) ? 'checked' : '';
$checked_text                 = isset( $twilio_settings['account_credentials'] ) ? 'Live Credentials' : 'Testing Credentials';
$checked_text_wa              = isset( $whatsapp_settings['whatsapp_account_credentials'] ) ? 'Live Credentials' : 'Testing Credentials';
$active_class                 = isset( $twilio_settings['account_credentials'] ) ? 'active' : '';
$active_class_wa              = isset( $whatsapp_settings['whatsapp_account_credentials'] ) ? 'active' : '';
$active_test_class            = isset( $twilio_settings['account_credentials'] ) ? '' : 'active';
$active_test_class_wa         = isset( $whatsapp_settings['whatsapp_account_credentials'] ) ? '' : 'active';

/*WhatsApp fields*/
$whatsapp_settings                         = get_option( 'whatsapp_settings' );
$whatsapp_from_number_id                   = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_phone_id' );
$whatsapp_from_number_id_test              = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_phone_id_test' );
$whatsapp_token                            = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_token' );
$whatsapp_token_test                       = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_token_test' );
$whatsapp_business_account_id              = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_business_account_id' );
$whatsapp_business_account_id_test         = ZWORKFLOWMANAGER_Core::get_field_value( $whatsapp_settings, 'whatsapp_business_account_id_test' );
$encoded_whatsapp_from_number_id           = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_from_number_id, 0, - 5, '*' );
$encoded_whatsapp_from_number_id_test      = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_from_number_id_test, 0, - 5, '*' );
$encoded_whatsapp_token                    = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_token, 0, - 5, '*' );
$encoded_whatsapp_token_test               = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_token_test, 0, - 5, '*' );
$encoded_whatsapp_business_account_id      = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_business_account_id, 0, - 5, '*' );
$encoded_whatsapp_business_account_id_test = ZWORKFLOWMANAGER_Core::character_string_replacer( $whatsapp_business_account_id_test, 0, - 5, '*' );

$section = ( isset( $_GET['section'] ) ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';

?>
<h3 class="workflows-title"><?php esc_html_e( 'Connection', 'flow_notify_text' ); ?></h3>
<nav class="nav-tab-wrapper woo-nav-tab-wrapper">
	<a class="nav-tab<?php echo ( ( ! $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=connection"><?php echo esc_html( 'Twilio' ); ?></a>
	<a class="nav-tab<?php echo ( ( 'whatsapp' === $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=connection&section=whatsapp"><?php echo esc_html( 'WhatsApp' ); ?></a>
</nav>
<?php if ( 'whatsapp' === $section ) { ?>
<form method="POST"
	  action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	  id="zwf-connection">
	<input type="hidden" name="action" value="zwf_whatsapp_gateway_save_changes"/>

	<table class="zwf-setting-table">
		<tbody class="zwf-setting-table__tbody">
		<?php if ( $is_connected_wa ) { ?>
			<tr class="zwf-setting-table__tr">
				<td class="zwf-setting-table__td full" colspan="2">
					<p class="zwf-setting-table__banner success">
						<?php esc_html_e( 'Connected', 'flow_notify_text' ); ?>
					</p>
				</td>
			</tr>
		<?php } ?>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<strong><?php esc_html_e( 'WhatsApp Gateway', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<a href="https://developers.facebook.com/"
				   target="_blank"
				   class="zwf-setting-table__ext-link">
					<?php esc_html_e( 'Application account settings', 'flow_notify_text' ); ?>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" role="img"
						 aria-hidden="true" focusable="false">
						<path d="M18.2 17c0 .7-.6 1.2-1.2 1.2H7c-.7 0-1.2-.6-1.2-1.2V7c0-.7.6-1.2 1.2-1.2h3.2V4.2H7C5.5 4.2 4.2 5.5 4.2 7v10c0 1.5 1.2 2.8 2.8 2.8h10c1.5 0 2.8-1.2 2.8-2.8v-3.6h-1.5V17zM14.9 3v1.5h3.7l-6.4 6.4 1.1 1.1 6.4-6.4v3.7h1.5V3h-6.3z"></path>
					</svg>
				</a>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="whatsapp_account_credentials" class="zwf-setting-table__label">
					<?php esc_html_e( 'Account', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td">
				<label for="whatsapp_account_credentials" class="zworkflowmanager_switch">
					<input type="checkbox"
						   id="whatsapp_account_credentials"
						   name="whatsapp_account_credentials"
						<?php echo esc_attr( $checked_whatsapp ); ?>
						   class="js-status-switcher">
					<span class="zworkflowmanager_slider round"></span>
				</label>
				<span class="js-status-text status-text"><?php echo esc_textarea( $checked_text_wa ); ?></span>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-phone-id" class="zwf-setting-table__label">
					<?php esc_html_e( 'WhatsApp From number ID', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<input type="text"
					   id="whatsapp-phone-id"
					   name="whatsapp-phone-id"
					   value="<?php echo esc_attr( $encoded_whatsapp_from_number_id ); ?>"
					   class="zwf-setting-table__input js-live <?php echo esc_attr( $active_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-phone-id-value" value="<?php echo esc_attr( $whatsapp_from_number_id ); ?>">
				<input type="text"
					   id="whatsapp-phone-id-test"
					   name="whatsapp-phone-id-test"
					   value="<?php echo esc_attr( $encoded_whatsapp_from_number_id_test ); ?>"
					   class="zwf-setting-table__input js-test <?php echo esc_attr( $active_test_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-phone-id-test-value" value="<?php echo esc_attr( $whatsapp_from_number_id_test ); ?>">
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-whatsapp-token" class="zwf-setting-table__label">
					<?php esc_html_e( 'Token', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<input type="text"
					   id="whatsapp-token"
					   name="whatsapp-token"
					   value="<?php echo esc_attr( $encoded_whatsapp_token ); ?>"
					   class="zwf-setting-table__input js-live <?php echo esc_attr( $active_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-token-value" value="<?php echo esc_attr( $whatsapp_token ); ?>">

				<input type="text"
					   id="whatsapp-token-test"
					   name="whatsapp-token-test"
					   value="<?php echo esc_attr( $encoded_whatsapp_token_test ); ?>"
					   class="zwf-setting-table__input js-test <?php echo esc_attr( $active_test_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-token-test-value" value="<?php echo esc_attr( $whatsapp_token_test ); ?>">
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-whatsapp-token" class="zwf-setting-table__label">
					<?php esc_html_e( 'WhatsApp Business Account ID', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<input type="text"
					   id="whatsapp-business-account-id"
					   name="whatsapp-business-account-id"
					   value="<?php echo esc_attr( $encoded_whatsapp_business_account_id ); ?>"
					   class="zwf-setting-table__input js-live <?php echo esc_attr( $active_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-business-account-id-value" value="<?php echo esc_attr( $whatsapp_business_account_id ); ?>">
				<input type="text"
					   id="whatsapp-business-account-id-test"
					   name="whatsapp-business-account-id-test"
					   value="<?php echo esc_attr( $encoded_whatsapp_business_account_id_test ); ?>"
					   class="zwf-setting-table__input js-test <?php echo esc_attr( $active_test_class_wa ); ?>"
				/>
				<input type="hidden" name="whatsapp-business-account-id-test-value" value="<?php echo esc_attr( $whatsapp_business_account_id_test ); ?>">
			</td>
		</tr>
	</table>
	<button type="submit" class="button button-primary">
		<?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?>
	</button>
	<?php
		$check_connection     = esc_url( get_site_url() ) . '/wp-admin/admin.php?page=wc-workflows&tab=connection&section=whatsapp&zfn_operation_type=check_connection_whatsapp';
		$check_connection_url = wp_nonce_url( $check_connection, 'zfn_operation_type', 'zwf_nonce' );
	?>
	<a href="<?php echo esc_url( $check_connection_url ); ?>"
	   class="button button-secondary">
		<?php esc_html_e( 'Check Connection', 'flow_notify_text' ); ?>
	</a>
</form>
<?php } else { ?>
<form method="POST"
	action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	id="zwf-connection">
	<input type="hidden" name="action" value="zwf_twilio_gateway_save_changes"/>

	<table class="zwf-setting-table">
		<tbody class="zwf-setting-table__tbody">
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<strong><?php esc_html_e( 'Twilio Gateway', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<a href="https://www.twilio.com/console/project/settings"
				target="_blank"
				class="zwf-setting-table__ext-link">
					<?php esc_html_e( 'Application account settings', 'flow_notify_text' ); ?>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" role="img"
						aria-hidden="true" focusable="false">
						<path d="M18.2 17c0 .7-.6 1.2-1.2 1.2H7c-.7 0-1.2-.6-1.2-1.2V7c0-.7.6-1.2 1.2-1.2h3.2V4.2H7C5.5 4.2 4.2 5.5 4.2 7v10c0 1.5 1.2 2.8 2.8 2.8h10c1.5 0 2.8-1.2 2.8-2.8v-3.6h-1.5V17zM14.9 3v1.5h3.7l-6.4 6.4 1.1 1.1 6.4-6.4v3.7h1.5V3h-6.3z"></path>
					</svg>
				</a>
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="account_credentials" class="zwf-setting-table__label">
					<?php esc_html_e( 'Account', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td">
				<label for="account_credentials" class="zworkflowmanager_switch">
					<input type="checkbox"
						id="account_credentials"
						name="account_credentials"
						<?php echo esc_attr( $checked ); ?>
						class="js-status-switcher">
					<span class="zworkflowmanager_slider round"></span>
				</label>
				<span class="js-status-text status-text"><?php echo esc_textarea( $checked_text ); ?></span>
			</td>
		</tr>


		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-account-sid" class="zwf-setting-table__label">
					<?php esc_html_e( 'Account SID', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<input type="text"
					id="zwf-connection-account-sid"
					name="account-sid"
					value="<?php echo esc_attr( $encoded_account_sid ); ?>"
					class="zwf-setting-table__input js-live <?php echo esc_attr( $active_class ); ?>"
				/>
				<input type="hidden" name="account-sid-value" value="<?php echo esc_attr( $account_sid ); ?>">

				<input type="text"
					id="zwf-connection-account-sid-test"
					name="account-sid-test"
					value="<?php echo esc_attr( $encoded_account_sid_test ); ?>"
					class="zwf-setting-table__input js-test <?php echo esc_attr( $active_test_class ); ?>"
				/>
				<input type="hidden" name="account-sid-test-value" value="<?php echo esc_attr( $account_sid_test ); ?>">

			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-auth-token" class="zwf-setting-table__label">
					<?php esc_html_e( 'Auth Token', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<input type="text"
					id="zwf-connection-auth-token"
					name="auth-token"
					value="<?php echo esc_attr( $encoded_auth_token ); ?>"
					class="zwf-setting-table__input js-live <?php echo esc_attr( $active_class ); ?>"
				/>
				<input type="hidden" name="auth-token-value" value="<?php echo esc_attr( $auth_token ); ?>">
				<input type="text"
					id="zwf-connection-auth-token-test"
					name="auth-token-test"
					value="<?php echo esc_attr( $encoded_auth_token_test ); ?>"
					class="zwf-setting-table__input js-test <?php echo esc_attr( $active_test_class ); ?>"
				/>
				<input type="hidden" name="auth-token-test-value" value="<?php echo esc_attr( $auth_token_test ); ?>">
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-from-number" class="zwf-setting-table__label">
					<?php esc_html_e( 'From Number', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<div style="position: relative">
					<input type="text"
						id="zwf-connection-from-number"
						value="<?php echo esc_attr( $from_number ); ?>"
						pattern="[0-9\-\+\s]{9,13}"
						class="zwf-setting-table__input js-input-phone js-intl-input js-live <?php echo esc_attr( $active_class ); ?>"
					/>
					<span class="zwf-setting-table__icon js-show-notification-icon js-live <?php echo esc_attr( $active_class ); ?>"></span>
					<input type="hidden"
						name="from-number"
						value="<?php echo esc_attr( $from_number ); ?>"
						class="js-zwf-connection-from-number"
					/>
					<input type="text"
						id="zwf-connection-from-number-test"
						value="<?php echo esc_attr( $from_number_test ); ?>"
						pattern="[0-9\-\+\s]{9,13}"
						class="zwf-setting-table__input js-input-phone js-intl-input-test js-test <?php echo esc_attr( $active_test_class ); ?>"
					>
					<span class="zwf-setting-table__icon js-show-notification-icon js-test <?php echo esc_attr( $active_test_class ); ?>"></span>
					<input type="hidden"
						name="from-number-test"
						value="<?php echo esc_attr( $from_number_test ); ?>"
						class="js-zwf-connection-from-number-test"
					/>
				</div>
				<p class="zwf-setting-table__description">
					<?php esc_html_e( 'Must be a valid number linked with your Twilio account', 'flow_notify_text' ); ?>
				</p>
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<label for="zwf-connection-to-test-number" class="zwf-setting-table__label">
					<?php esc_html_e( 'To Number', 'flow_notify_text' ); ?>
				</label>
			</td>
			<td class="zwf-setting-table__td js-zwf-setting-table">
				<div style="position: relative">
					<input type="text"
						id="zwf-connection-to-number"
						value="<?php echo esc_attr( $to_number ); ?>"
						pattern="[0-9\-\+\s]{9,13}"
						class="zwf-setting-table__input js-input-phone js-intl-input2 js-live <?php echo esc_attr( $active_class ); ?>"
					/>
					<span class="zwf-setting-table__icon js-show-notification-icon js-live <?php echo esc_attr( $active_class ); ?>"></span>
					<input type="hidden"
						name="to-number"
						value="<?php echo esc_attr( $to_number ); ?>"
						class="js-zwf-connection-to-number"
					/>

					<input type="text"
						id="zwf-connection-to-number-test"
						value="<?php echo esc_attr( $to_number_test ); ?>"
						pattern="[0-9\-\+\s]{9,13}"
						class="zwf-setting-table__input js-input-phone js-intl-input2-test js-test <?php echo esc_attr( $active_test_class ); ?>"
					/>
					<span class="zwf-setting-table__icon js-show-notification-icon js-test <?php echo esc_attr( $active_test_class ); ?>"></span>
					<input type="hidden"
						name="to-number-test"
						value="<?php echo esc_attr( $to_number_test ); ?>"
						class="js-zwf-connection-to-number-test"
					/>
				</div>
				<p class="zwf-setting-table__description">
					<?php esc_html_e( '[FOR TESTING ONLY] Verified live number to test connection status with SMS Messaging Service', 'flow_notify_text' ); ?>
				</p>
			</td>
		</tr>
		<?php if ( $is_connected ) { ?>
			<tr class="zwf-setting-table__tr">
				<td class="zwf-setting-table__td full" colspan="2">
					<p class="zwf-setting-table__banner success">
						<?php esc_html_e( 'Connected', 'flow_notify_text' ); ?>
					</p>
				</td>
			</tr>
		<?php } ?>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<strong><?php esc_html_e( 'Return SMS Message', 'flow_notify_text' ); ?></strong>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td full">
				<p class="zwf-setting-table__description">
					<?php
					$site_url  = get_site_url();
					$text_link = $site_url . '/?wc_twilio_sms_response';
					?>
					<?php esc_html_e( 'When a customer replies to a SMS, Twilio will bby default respond with a generic message. In order to send back a customer return message you can modify this section. You will then need to log into your Twilio account and navigate to the', 'flow_notify_text' ); ?>
					<a href="https://www.twilio.com/user/account/phone-numbers/incoming"><?php esc_html_e( 'Phone Numbers page.', 'flow_notify_text' ); ?></a>
					<?php esc_html_e( 'Select the phone number where you want to receive SMS. Paste this URL into the Messaging > Request URL field:', 'flow_notify_text' ); ?>
					<a href="<?php echo esc_html( $site_url ); ?>/?wc_twilio_sms_response"><?php echo esc_html( $text_link ); ?></a>
				</p>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first small">
				<strong><?php esc_html_e( 'Enable return SMS message', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<input type="checkbox" id="status_return_sms_message"
					name="status_return_sms_message"
					<?php echo esc_attr( $checked_return_sms ); ?>
				>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first small">
				<strong><?php esc_html_e( 'Response Message', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<textarea class="short" style="" name="response_message"
						id="response_message"
						rows="2"
						cols="58" spellcheck="false"><?php echo esc_html( $response_message ); ?></textarea>
				<span class="info_icon"></span>
			</td>
		</tr>

		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first">
				<strong><?php esc_html_e( 'Sender ID', 'flow_notify_text' ); ?></strong>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td full">
				<p class="zwf-setting-table__description">
					<?php esc_html_e( 'Alphanumeric Sender ID allows you to set your own business brand as the Sender ID when sending one-way messages. This is only used when sending messages to', 'flow_notify_text' ); ?>
					<a href="https://support.twilio.com/hc/en-us/articles/223133767-International-support-for-Alphanumeric-Sender-ID"><?php esc_html_e( 'supported countries', 'flow_notify_text' ); ?></a>
					<?php esc_html_e( 'and messages sent using the Sender ID cannot accept customer replies. Spoofing of brands or companies with Sender ID is not allowed.', 'flow_notify_text' ); ?>
				</p>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first small">
				<strong><?php esc_html_e( 'Enable Sender ID', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<input type="checkbox" id="status_sender_id"
					name="status_sender_id"
					<?php echo esc_attr( $checked_sender_id ); ?>
				>
			</td>
		</tr>
		<tr class="zwf-setting-table__tr">
			<td class="zwf-setting-table__td first small">
				<strong><?php esc_html_e( 'Sender ID', 'flow_notify_text' ); ?></strong>
			</td>
			<td class="zwf-setting-table__td">
				<input type="text"
					name="sender_id"
					id="sender_id"
					value="<?php echo esc_attr( $sender_id ); ?>">
				<span class="info_icon"></span>
			</td>
		</tr>
		</tbody>
	</table>

	<button type="submit" class="button button-primary">
		<?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?>
	</button>

	<?php
		$check_connection     = esc_url( get_site_url() ) . '/wp-admin/admin.php?page=wc-workflows&tab=connection&zfn_operation_type=check_connection';
		$check_connection_url = wp_nonce_url( $check_connection, 'zfn_operation_type', 'zwf_nonce' );
	?>

	<a href="<?php echo esc_url( $check_connection_url ); ?>"
	class="button button-secondary">
		<?php esc_html_e( 'Check Connection', 'flow_notify_text' ); ?>
	</a>
</form>

<table class="zwf-setting-table">
	<tbody class="zwf-setting-table__tbody">
	<tr class="zwf-setting-table__tr">
		<td class="zwf-setting-table__td full" colspan="2">
			<div class="zwf-setting-table__boxes-wrapper">
				<div class="zwf-setting-table__box">
					<form method="post"
						name="zwf-twilio-test-message"
						data-role="twilio-test-message">
						<div class="zwf-setting-table__box-caption">
							<strong><?php esc_html_e( 'Test Message', 'flow_notify_text' ); ?></strong>
						</div>

						<div class="zwf-setting-table__box-input-wrapper">
							<label for="zwf-connection-test-twilio-sms"
								class="zwf-setting-table__label">
								<?php esc_html_e( 'Test Number', 'flow_notify_text' ); ?>
							</label>
							<div style="position: relative">
								<input type="text"
									id="zwf-connection-test-twilio-sms"
									value="<?php echo esc_attr( $phone_to_test_msg ); ?>"
									required
									pattern="[0-9\-\+\s]{9,13}"
									title="<?php esc_html_e( 'Enter please valid phone number', 'flow_notify_text' ); ?>"
									class="zwf-setting-table__input js-intl-input3"
								>
								<span class="zwf-setting-table__icon js-show-notification-icon"></span>
								<input type="hidden"
									name="phone_to_test_msg"
									value="<?php echo esc_attr( $phone_to_test_msg ); ?>"
									class="js-zwf-connection-test-msg"
								/>
							</div>
							<p class="zwf-setting-table__description">
								<?php esc_html_e( 'Enter a phone number to test the SMS sending.', 'flow_notify_text' ); ?>
							</p>
						</div>

						<div class="zwf-setting-table__box-input-wrapper align-right">
							<button class="button button-primary zwf-setting-table__box-submit js-submit">
								<?php esc_html_e( 'Send Test', 'flow_notify_text' ); ?>
							</button>
						</div>

						<div class="zwf-setting-table__form-operation-status js-zwf-operation-status"></div>
					</form>
				</div>

				<div class="zwf-setting-table__divider"></div>

				<div class="zwf-setting-table__box">
					<form method="post"
						name="zwf-twilio-quick-send"
						data-role="twilio-quick-send">
						<div class="zwf-setting-table__box-caption">
							<strong><?php esc_html_e( 'Quick Send', 'flow_notify_text' ); ?></strong>
						</div>

						<div class="zwf-setting-table__box-input-wrapper">
							<label for="zwf-connection-test-twilio-sms2"
								class="zwf-setting-table__label">
								<?php esc_html_e( 'Phone Number', 'flow_notify_text' ); ?>
							</label>
							<div style="position: relative">
								<input type="text"
									id="zwf-connection-test-twilio-sms2"
									name="zwf-test-twilio-sms"
									value="<?php echo esc_attr( $quick_send ); ?>"
									required
									pattern="[0-9\-\+\s]{9,13}"
									class="zwf-setting-table__input js-intl-input4"
								>
								<span class="zwf-setting-table__icon js-show-notification-icon"></span>
								<input type="hidden"
									name="quick_send"
									value="<?php echo esc_attr( $quick_send ); ?>"
									class="js-zwf-connection-quick-send"
								/>
							</div>
						</div>

						<div class="zwf-setting-table__box-input-wrapper">
							<label for="zwf-connection-test-twilio-text"
								class="zwf-setting-table__label">
								<?php esc_html_e( 'Message', 'flow_notify_text' ); ?>
							</label>
							<textarea type="text"
									id="zwf-connection-test-twilio-text"
									name="zwf-test-twilio-text"
									required
									class="zwf-setting-table__textarea"
									placeholder="Write your message..."
							></textarea>
						</div>

						<div class="zwf-setting-table__box-input-wrapper align-right">
							<button class="button button-primary zwf-setting-table__box-submit js-submit">
								<?php esc_html_e( 'Send Message', 'flow_notify_text' ); ?>
							</button>
						</div>

						<div class="zwf-setting-table__form-operation-status js-zwf-operation-status"></div>
					</form>
				</div>
			</div>
		</td>
	</tr>
	</tbody>
</table>
<?php } ?>

<?php
/**
 * Flow-Notify Send tab
 * add new send
 *
 * @package Flow-Notify/templates/send/new-send
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Send' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-send.php';
}
$new_status_send = ( isset( $_GET['send'] ) ) ? sanitize_text_field( wp_unslash( $_GET['send'] ) ) : '';
$status_send     = new ZWORKFLOWMANAGER_Send( $new_status_send );
$users_arr       = $status_send->get_users();
$recipient_types = array( 'All Customers', 'Select Customer' );
$types           = array( 'email', 'SMS', 'WhatsApp' );
$method          = array( 'Instant', 'Scheduled' );
?>
<h2 class="workflows-title">
	<?php esc_html_e( 'Send Message', 'Send' ); ?>
</h2>
<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>" id="zworkflowmanager_send_status">
	<input type="hidden" name="action" value="zworkflowmanager_new_send"/>
	<input type="hidden" name="status_id" value="<?php echo esc_attr( $new_status_send ); ?>"/>
	<input type="hidden" name="send_status" value="Scheduled"/>
	<div class="zworkflowmanager_order_wrapper">
		<div id="zworkflowmanager_order_status_data">
			<table class="zworkflowmanager_row zworkflowmanager_col_12">
				<tbody class="zworkflowmanager_row zworkflowmanager_col_12">
				<tr class="zworkflowmanager_row zworkflowmanager_col_12">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="recipient"><?php esc_html_e( 'Recipient', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<select id="recipient" class="js-send-recipient" name="recipient">
							<?php
							foreach ( $recipient_types as $r_type ) {
								echo '<option value="' . esc_attr( $r_type ) . '">' . esc_textarea( ucfirst( $r_type ) ) . '</option>';
							}
							?>
						</select>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 customer_select_wrap js-customer_select_wrap">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding"></td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<select class="js-select_type" id="users" name="user_recipient[]" multiple="multiple">
							<?php
							foreach ( $users_arr as $user ) {
								$value = $user['user_email'] . ',' . $user['billing_phone'] . ',' . $user['ID'];
								$text  = $user['first_name'] . ' ' . $user['last_name'] . ' - ' . $user['user_email'] . ' (' . $user['billing_phone'] . ')';
								echo '<option value="' . esc_attr( $value ) . '">' . esc_textarea( ucfirst( $text ) ) . '</option>';
							}
							?>
						</select>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="notification"><?php esc_html_e( 'Notification', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<select class="js-select-notification" id="notification" name="notification">
							<option value="Instant Send"><?php esc_html_e( 'Instant Send', 'flow_notify_text' ); ?></option>
							<?php
							foreach ( $status_send->get_notification() as $n_title ) {
								echo '<option value="' . esc_attr( $n_title['post_title'] ) . '">' . esc_textarea( ucfirst( $n_title['post_title'] ) ) . '</option>';
							}
							?>
						</select>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="type"><?php esc_html_e( 'Type', 'flow_notify_text' ); ?></label>
					</td>
					<td class="js-notification-type zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
						<?php
						foreach ( $types as $s_type ) {
							?>
							<input type="checkbox"
								class="js-sending-type js-sending-required"
								data-role="disabled-btn"
								id="<?php echo esc_attr( $s_type ); ?>"
								value="<?php echo esc_attr( $s_type ); ?>"
								name="<?php echo esc_attr( $s_type ); ?>">
							<span><?php echo esc_attr( $s_type ); ?></span>
						<?php } ?>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_status_fields zcustomemail_subject-wrap">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="subject"><?php esc_html_e( 'Subject', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
						<input type="text"
							class="short js-subject"
							data-role="disabled-btn"
							name="subject"
							id="subject"
							maxlength="35">
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_status_fields">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="message"><?php esc_html_e( 'Message', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zwf__message-wrap">
						<textarea class="short js-message-input js-zwf-message "
								data-role="disabled-btn"
								name="description"
								required
								id="message"
								rows="7"
								cols="20"
								spellcheck="false"></textarea>
						<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/supported-data-types.php'; ?>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="wooCommerceData"><?php esc_html_e( 'WooCommerce', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_3 col-padding-left">
						<select class="js-select-wooCommerceData select-wooCommerceData"
								data-role="select-wooCommerceData"
								id="wooCommerceData" name="wooCommerceData">
							<option value="include_data"><?php esc_html_e( 'Include Data', 'flow_notify_text' ); ?></option>
							<option value="exclude_data"><?php esc_html_e( 'Exclude Data', 'flow_notify_text' ); ?></option>
						</select>
					</td>
					<td class="zworkflowmanager_col_3 col-padding-right js-select-wooCommerceOrders-wrap">
						<select class="js-select-wooCommerceOrders select-wooCommerceOrders"
								data-role="select-wooCommerceOrders"
								id="wooCommerceOrders" name="wooCommerceOrders">
							<option value="last_order_placed"><?php esc_html_e( 'Last Order Placed', 'flow_notify_text' ); ?></option>
							<option value="all_orders_placed"><?php esc_html_e( 'All Orders Placed', 'flow_notify_text' ); ?></option>
						</select>
					</td>
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding js-show-notification-wooCommerceOrders">
						<span class="notification-email-icon js-notification-wooCommerceOrders" data-id="0"></span>
					</td>
				</tr>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
						<label for="date"><?php esc_html_e( 'When to dispatch', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_3 col-padding-left">
						<select id="date" data-role="disabled-btn" name="date" class="js-when-dispatch ">
							<?php
							foreach ( $method as $m_type ) {
								echo '<option value="' . esc_attr( $m_type ) . '" >' . esc_textarea( ucfirst( $m_type ) ) . '</option>';
							}
							?>
						</select>
					</td>
					<td class="date-time-fields js-date-time-fields"><label for="datepicker">
							<?php esc_html_e( 'Date', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_3 col-flex date-time-fields js-date-time-fields">
						<input class="js-date-time-input" data-role="disabled-btn"
							type="text" name="datepicker" id="datepicker">
					</td>
					<td class="date-time-fields js-date-time-fields">
						<label for="timepicker"><?php esc_html_e( 'Time', 'flow_notify_text' ); ?></label>
					</td>
					<td class="zworkflowmanager_col_3 col-flex date-time-fields js-date-time-fields">
						<input type="time" data-role="disabled-btn" name="timepicker"
							class="js-date-time-input" id="timepicker">
					</td>
					<td class="zworkflowmanager_col_3 col-flex">
						<button type="submit" class="disabled button button-primary button-submit js-button-send-event">
							<span class="button-text js-btn-text"><?php esc_html_e( 'Send Now', 'flow_notify_text' ); ?></span>
						</button>
					</td>
				</tr>
				</tbody>
			</table>
		</div>
	</div>
</form>

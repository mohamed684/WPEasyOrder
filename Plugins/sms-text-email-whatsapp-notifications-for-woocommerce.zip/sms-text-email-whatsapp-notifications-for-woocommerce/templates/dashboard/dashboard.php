<?php
/**
 * Flow-Notify dashboard tab
 *
 * @package Flow-Notify/templates/dashboard
 */

$zwf_dashboard    = new ZWORKFLOWMANAGER_Dashboard();
$schedule_text    = ( $zwf_dashboard->get_timeframe_schedule_message() )
	? $zwf_dashboard->get_timeframe_schedule_message() : 'No Schedule Set';
$schedule_subtext = ( $zwf_dashboard->get_timeframe_schedule_message() ) ? '' : '- Messages sent instantly on demand';
$not_activity     = empty( $zwf_dashboard->get_activity_posts() ) ? 'No activity sent yet' : '';
?>
<div class="zwf-dashboard">
	<h2 class="workflows-title"><?php esc_html_e( 'Dashboard', 'flow_notify_text' ); ?></h2>
	<div class="zwf-dashboard__content">
		<div class="zwf-dashboard__left-section">
			<div class="zwf-dashboard__quick-links-wrap">
				<div class="zwf-dashboard__quick-links">
					<a class="zwf-dashboard__quick-links_btn-wrap white-block"
					href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=send' ) ); ?>">
						<svg class="fnh-layout__nav-icon" xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 512 512">
							<path d="M492.6 226.6L44.6 34.59C40.54 32.85 36.26 31.1 32.02 31.1c-8.623 0-17.1 3.499-23.3 10.05C-.4983 51.81-2.623 66.3 3.377 78.31L96 256l-92.62 177.7c-6 12.02-3.875 26.5 5.344 36.27c6.188 6.547 14.66 10.05 23.28 10.05c4.25 0 8.531-.8438 12.59-2.594L492.6 285.4c11.78-5.031 19.41-16.61 19.41-29.41C511.1 243.2 504.4 231.6 492.6 226.6zM31.98 64.03C31.99 64.01 31.96 64.04 31.98 64.03L442.7 240H123.7L31.98 64.03zM31.75 448.5L123.7 272h318.1L31.75 448.5z"/>
						</svg>
						<?php echo esc_html__( 'Send a Message', 'flow_notify_text' ); ?>
					</a>
					<div class="zwf-dashboard__quick-links_info white-block">
						<p><?php echo esc_textarea( $zwf_dashboard->get_count_of_scheduled_posts() ); ?></p>
						<?php echo esc_html__( 'Messages Scheduled', 'flow_notify_text' ); ?>
					</div>
				</div>
				<div class="zwf-dashboard__quick-links">
					<a class="zwf-dashboard__quick-links_btn-wrap white-block"
					href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=order_status' ) ); ?>">
						<svg class="fnh-layout__nav-icon" xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 448 512">
							<path d="M88 144C88 130.7 98.75 120 112 120C125.3 120 136 130.7 136 144C136 157.3 125.3 168 112 168C98.75 168 88 157.3 88 144zM.0003 80C.0003 53.49 21.49 32 48 32H197.5C214.5 32 230.7 38.74 242.7 50.75L418.7 226.7C443.7 251.7 443.7 292.3 418.7 317.3L285.3 450.7C260.3 475.7 219.7 475.7 194.7 450.7L18.75 274.7C6.743 262.7 0 246.5 0 229.5L.0003 80zM41.37 252.1L217.4 428.1C229.9 440.6 250.1 440.6 262.6 428.1L396.1 294.6C408.6 282.1 408.6 261.9 396.1 249.4L220.1 73.37C214.1 67.37 205.1 64 197.5 64H48C39.16 64 32 71.16 32 80V229.5C32 237.1 35.37 246.1 41.37 252.1L41.37 252.1zM41.37 252.1L18.75 274.7z"/>
						</svg>
						<?php echo esc_html__( 'Manage Order Status', 'flow_notify_text' ); ?>
					</a>
					<div class="zwf-dashboard__quick-links_info white-block">
						<p><?php echo esc_textarea( $zwf_dashboard->get_count_of_order_status_posts() ); ?></p>
						<?php echo esc_html__( 'Order Statuses', 'flow_notify_text' ); ?>
					</div>
				</div>
				<div class="zwf-dashboard__quick-links">
					<a class="zwf-dashboard__quick-links_btn-wrap white-block"
					href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=emails' ) ); ?>">
						<svg class="fnh-layout__nav-icon"
							width="1792" height="1792"
							viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
							<path d="M640 896q0 53-37.5 90.5t-90.5 37.5-90.5-37.5-37.5-90.5 37.5-90.5 90.5-37.5 90.5 37.5 37.5 90.5zm384 0q0 53-37.5 90.5t-90.5 37.5-90.5-37.5-37.5-90.5 37.5-90.5 90.5-37.5 90.5 37.5 37.5 90.5zm384 0q0 53-37.5 90.5t-90.5 37.5-90.5-37.5-37.5-90.5 37.5-90.5 90.5-37.5 90.5 37.5 37.5 90.5zm-512-512q-204 0-381.5 69.5t-282 187.5-104.5 255q0 112 71.5 213.5t201.5 175.5l87 50-27 96q-24 91-70 172 152-63 275-171l43-38 57 6q69 8 130 8 204 0 381.5-69.5t282-187.5 104.5-255-104.5-255-282-187.5-381.5-69.5zm896 512q0 174-120 321.5t-326 233-450 85.5q-70 0-145-8-198 175-460 242-49 14-114 22h-5q-15 0-27-10.5t-16-27.5v-1q-3-4-.5-12t2-10 4.5-9.5l6-9 7-8.5 8-9q7-8 31-34.5t34.5-38 31-39.5 32.5-51 27-59 26-76q-157-89-247.5-220t-90.5-281q0-130 71-248.5t191-204.5 286-136.5 348-50.5 348 50.5 286 136.5 191 204.5 71 248.5z"/>
						</svg>
						<?php echo esc_html__( 'Manage Notifications', 'flow_notify_text' ); ?></a>
					<div class="zwf-dashboard__quick-links_info white-block">
						<p><?php echo esc_textarea( $zwf_dashboard->get_count_of_notifications_posts() ); ?></p>
						<?php echo esc_html__( 'Notifications', 'flow_notify_text' ); ?>
					</div>
				</div>
			</div>
			<div class="zwf-dashboard__analytics">
				<div class="zwf-dashboard__analytics-info">
					<?php
					foreach ( $zwf_dashboard->get_send_posts() as $key => $item ) {
						?>
						<div class="zwf-dashboard__analytics-info_item">
							<p class="zwf-dashboard__analytics-info_count"><?php echo esc_textarea( $item ); ?></p>
							<p class="zwf-dashboard__analytics-info_title"><?php echo esc_textarea( $key ); ?></p>
						</div>
						<?php
					}
					?>
					<a class="zwf-dashboard__link"
					href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=send' ) ); ?>">></a>
				</div>
				<canvas id="myChart" class="zwf-dashboard__myChart" width="400" height="400"></canvas>
				<div class="zwf-dashboard__no-data-chart js-no-data">
					<p>No data reporting yet</p>
				</div>
			</div>
		</div>
		<div class="zwf-dashboard__right-section">
			<div class="zwf-dashboard__message-timeframe-schedule">
				<p class="zwf-dashboard__message-timeframe-schedule_time"><?php echo esc_textarea( $schedule_text ); ?>
					<span><?php echo esc_textarea( $schedule_subtext ); ?></span>
				</p>
				<div class="zwf-dashboard__message-timeframe-schedule_description">
					<?php echo esc_html__( 'Message Timeframe Schedule', 'flow_notify_text' ); ?>
				</div>
				<a class="zwf-dashboard__link"
				href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=settings' ) ); ?>">></a>
			</div>
			<div class="zwf-dashboard__activity-log">
				<div class="zwf-dashboard__activity-log_title">
					<p><?php echo esc_html__( 'Recent Activity', 'flow_notify_text' ); ?></p>
					<a class="zwf-dashboard__link"
					href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=activities' ) ); ?>">></a>
					<?php if ( $not_activity ) { ?>
						<div class="zwf-dashboard__not-activity">
							<?php echo esc_textarea( $not_activity ); ?>
						</div>
					<?php } ?>
				</div>
				<div class="zwf-dashboard__activity-log_posts">
					<?php
					foreach ( $zwf_dashboard->get_activity_posts() as $activity_post ) {
						$customers_type = 'All Customers' !== $activity_post['email'] ? 'Select Customers' : $activity_post['email'];
						?>
						<div class="zwf-dashboard__activity-log_post">
							<a class="zwf-dashboard__post-title"
							href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=send&edit_send=' . $activity_post['id'] ) ); ?>">
								<?php echo esc_textarea( $activity_post['method'] . ' - ' . $customers_type ); ?>
							</a>
							<p class="zwf-dashboard__post-time">
								<?php echo esc_textarea( gmdate( 'm/d/Y, H:i', intval( $activity_post['sent'] ) ) ); ?>
							</p>
							<a class="zwf-dashboard__post-link"
							href="<?php echo esc_url( admin_url( 'admin.php?page=wc-workflows&tab=send&edit_send=' . $activity_post['id'] ) ); ?>"></a>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>




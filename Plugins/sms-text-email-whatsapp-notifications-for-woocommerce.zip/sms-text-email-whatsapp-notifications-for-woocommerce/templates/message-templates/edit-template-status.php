<?php
/**
 * Flow-Notify Notifications tab
 *
 * @package Flow-Notify/templates/message-template
 */

$edit_template = ( isset( $_GET['edit_template'] ) && ! empty( $_GET['edit_template'] ) ? sanitize_text_field( wp_unslash( $_GET['edit_template'] ) ) : 0 );

if ( 0 === (int) $edit_template ) {
	?>
	<h3><?php esc_html_e( 'Order Status Email doesn\'t exist', 'flow_notify_text' ); ?></h3>
	<?php
}

$message_template_post = get_post( $edit_template );

$checked              = get_post_meta( $edit_template, 'zmessagetemplate_status', true ) === 'enabled' ? 'checked' : '';
$checked_text         = get_post_meta( $edit_template, 'zmessagetemplate_status', true ) === 'enabled' ? 'Enabled' : 'Disabled';
$type_template        = get_post_meta( $edit_template, 'zsending_type', true );
$template_name        = get_post_meta( $edit_template, 'zmessagetemplate_name', true );
$template_subject     = get_post_meta( $edit_template, 'zmessagetemplate_subject', true );
$template_text        = get_post_meta( $edit_template, 'zmessagetemplate_description', true );
$approval_status      = get_post_meta( $edit_template, 'zapproval_status', true );
$category             = get_post_meta( $edit_template, 'zmessagetemplate_category', true );
$language             = get_post_meta( $edit_template, 'zmessagetemplate_language', true );
$whatsapp_template_id = get_post_meta( $edit_template, 'whatsapp_template_id', true );

if ( ! class_exists( 'ZWORKFLOWMANAGER_Whatsapp' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-whatsapp.php';
}

$whatsapp = new ZWORKFLOWMANAGER_Whatsapp();

ob_start();

$whatsapp->get_template( $template_name, $edit_template, false );

$template_status = ob_get_clean();

update_post_meta( $edit_template, 'zapproval_status', $template_status );

?>

<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>" id="zworkflowmanager_edit_status">
	<input type="hidden" name="action" value="zworkflowmanager_edit_message_template"/>
	<input type="hidden" name="status_id" value="<?php echo esc_attr( $edit_template ); ?>"/>
	<?php $nonce = wp_create_nonce( 'zwf_template_message_nonce' ); ?>
	<input type="hidden" name="zwf_template_message_nonce" value="<?php echo esc_attr( $nonce ); ?>">
	<div id="zworkflowmanager_order_status_data">
		<table class="zworkflowmanager_row zworkflowmanager_col_12">
			<tbody class="zworkflowmanager_row zworkflowmanager_col_12">
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding"><?php esc_html_e( 'Status', 'flow_notify_text' ); ?></td>
				<td class="status column-status zworkflowemail_status_toggle">
					<label class="zworkflowmanager_switch">
						<input type="checkbox"
							   id="status_toggle"
							   name="status_toggle"
								<?php echo esc_attr( $checked ); ?>
							   class="js-zworkflowmanager_status_switcher">
						<span class="zworkflowmanager_slider round"></span>
					</label>
					<span class="js-status-text status-text"><?php esc_html_e( 'Enabled', 'flow_notify_text' ); ?></span>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="post_title"><?php esc_html_e( 'Name', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short"
						   style=""
						   name="post_title"
						   id="post_title"
						   value="<?php echo esc_attr( $message_template_post->post_title ); ?>"
						   required
						   placeholder=""
						   maxlength="35">
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="type"><?php esc_html_e( 'Type', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select id="type" name="sending_type" class="js-sending-type" disabled>
						<option value="SMS" <?php echo ( 'sms' === $type_template ) ? 'selected' : ''; ?>><?php esc_html_e( 'SMS', 'flow_notify_text' ); ?></option>
						<option value="email"  <?php echo ( 'email' === $type_template ) ? 'selected' : ''; ?>><?php esc_html_e( 'Email', 'flow_notify_text' ); ?></option>
						<option value="whatsapp"  <?php echo ( 'whatsapp' === $type_template ) ? 'selected' : ''; ?>><?php esc_html_e( 'WhatsApp', 'flow_notify_text' ); ?></option>
					</select>
					<input type="hidden" name="sending_type" value="<?php echo esc_html( $type_template ); ?>">
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row zcustomemail_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="zmessagetemplate_subject"><?php esc_html_e( 'Subject', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short js-subject"
						   name="zmessagetemplate_subject"
						   id="zmessagetemplate_subject"
						   maxlength="35"
						   value="<?php echo esc_attr( $template_subject ); ?>"
						   >
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="zcustomemail_template_name"><?php esc_html_e( 'Template name', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short js-subject"
						   name="zcustomemail_template_name"
						   id="zcustomemail_template_name"
						   maxlength="35"
						   value="<?php echo esc_attr( $template_name ); ?>"
						   disabled
						   >
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<?php esc_html_e( 'Template language', 'flow_notify_text' ); ?>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select name="template_language" id="template_language" disabled>
						<option value="en_US" <?php echo ( 'en_US' === $language ) ? 'selected' : ''; ?>>English (US)</option>
						<option value="en_GB" <?php echo ( 'en_GB' === $language ) ? 'selected' : ''; ?>>English (UK)</option>
						<option value="af" <?php echo ( 'af' === $language ) ? 'selected' : ''; ?>>Afrikaans</option>
						<option value="sq" <?php echo ( 'sq' === $language ) ? 'selected' : ''; ?>>Albanian</option>
						<option value="ar" <?php echo ( 'ar' === $language ) ? 'selected' : ''; ?>>Arabic</option>
						<option value="az" <?php echo ( 'az' === $language ) ? 'selected' : ''; ?>>Azerbaijani</option>
						<option value="bn" <?php echo ( 'bn' === $language ) ? 'selected' : ''; ?>>Bengali</option>
						<option value="bg" <?php echo ( 'bg' === $language ) ? 'selected' : ''; ?>>Bulgarian</option>
						<option value="ca" <?php echo ( 'ca' === $language ) ? 'selected' : ''; ?>>Catalan</option>
						<option value="zh_CN" <?php echo ( 'zh_CN' === $language ) ? 'selected' : ''; ?>>Chinese (CHN)</option>
						<option value="zh_HK" <?php echo ( 'zh_HK' === $language ) ? 'selected' : ''; ?>>Chinese (HKG)</option>
						<option value="zh_TW" <?php echo ( 'zh_TW' === $language ) ? 'selected' : ''; ?>>Chinese (TAI)</option>
						<option value="hr" <?php echo ( 'hr' === $language ) ? 'selected' : ''; ?>>Croatian</option>
						<option value="cs" <?php echo ( 'cs' === $language ) ? 'selected' : ''; ?>>Czech</option>
						<option value="da" <?php echo ( 'da' === $language ) ? 'selected' : ''; ?>>Danish</option>
						<option value="nl" <?php echo ( 'nl' === $language ) ? 'selected' : ''; ?>>Dutch</option>
						<option value="et" <?php echo ( 'et' === $language ) ? 'selected' : ''; ?>>Estonian</option>
						<option value="fil" <?php echo ( 'fil' === $language ) ? 'selected' : ''; ?>>Filipino</option>
						<option value="fi" <?php echo ( 'fi' === $language ) ? 'selected' : ''; ?>>Finnish</option>
						<option value="fr" <?php echo ( 'fr' === $language ) ? 'selected' : ''; ?>>French</option>
						<option value="ka" <?php echo ( 'ka' === $language ) ? 'selected' : ''; ?>>Georgian</option>
						<option value="de" <?php echo ( 'de' === $language ) ? 'selected' : ''; ?>>German</option>
						<option value="el" <?php echo ( 'el' === $language ) ? 'selected' : ''; ?>>Greek</option>
						<option value="gu" <?php echo ( 'gu' === $language ) ? 'selected' : ''; ?>>Gujarati</option>
						<option value="ha" <?php echo ( 'ha' === $language ) ? 'selected' : ''; ?>>Hausa</option>
						<option value="he" <?php echo ( 'he' === $language ) ? 'selected' : ''; ?>>Hebrew</option>
						<option value="hi" <?php echo ( 'hi' === $language ) ? 'selected' : ''; ?>>Hindi</option>
						<option value="hu" <?php echo ( 'hu' === $language ) ? 'selected' : ''; ?>>Hungarian</option>
						<option value="id" <?php echo ( 'id' === $language ) ? 'selected' : ''; ?>>Indonesian</option>
						<option value="ga" <?php echo ( 'ga' === $language ) ? 'selected' : ''; ?>>Irish</option>
						<option value="it" <?php echo ( 'it' === $language ) ? 'selected' : ''; ?>>Italian</option>
						<option value="ja" <?php echo ( 'ja' === $language ) ? 'selected' : ''; ?>>Japanese</option>
						<option value="kn" <?php echo ( 'kn' === $language ) ? 'selected' : ''; ?>>Kannada</option>
						<option value="kk" <?php echo ( 'kk' === $language ) ? 'selected' : ''; ?>>Kazakh</option>
						<option value="rw_RW" <?php echo ( 'rw_RW' === $language ) ? 'selected' : ''; ?>>Kinyarwanda</option>
						<option value="ko" <?php echo ( 'ko' === $language ) ? 'selected' : ''; ?>>Korean</option>
						<option value="ky_KG" <?php echo ( 'ky_KG' === $language ) ? 'selected' : ''; ?>>Kyrgyz (Kyrgyzstan)</option>
						<option value="lo" <?php echo ( 'lo' === $language ) ? 'selected' : ''; ?>>Lao</option>
						<option value="lv" <?php echo ( 'lv' === $language ) ? 'selected' : ''; ?>>Latvian</option>
						<option value="lt" <?php echo ( 'lt' === $language ) ? 'selected' : ''; ?>>Lithuanian</option>
						<option value="mk" <?php echo ( 'mk' === $language ) ? 'selected' : ''; ?>>Macedonian</option>
						<option value="ms" <?php echo ( 'ms' === $language ) ? 'selected' : ''; ?>>Malay</option>
						<option value="ml" <?php echo ( 'ml' === $language ) ? 'selected' : ''; ?>>Malayalam</option>
						<option value="mr" <?php echo ( 'mr' === $language ) ? 'selected' : ''; ?>>Marathi</option>
						<option value="nb" <?php echo ( 'nb' === $language ) ? 'selected' : ''; ?>>Norwegian</option>
						<option value="fa" <?php echo ( 'fa' === $language ) ? 'selected' : ''; ?>>Persian</option>
						<option value="pl" <?php echo ( 'pl' === $language ) ? 'selected' : ''; ?>>Polish</option>
						<option value="pt_BR" <?php echo ( 'pt_BR' === $language ) ? 'selected' : ''; ?>>Portuguese (BR)</option>
						<option value="pt_PT" <?php echo ( 'pt_PT' === $language ) ? 'selected' : ''; ?>>Portuguese (POR)</option>
						<option value="pa" <?php echo ( 'pa' === $language ) ? 'selected' : ''; ?>>Punjabi</option>
						<option value="ro" <?php echo ( 'ro' === $language ) ? 'selected' : ''; ?>>Romanian</option>
						<option value="ru" <?php echo ( 'ru' === $language ) ? 'selected' : ''; ?>>Russian</option>
						<option value="sr" <?php echo ( 'sr' === $language ) ? 'selected' : ''; ?>>Serbian</option>
						<option value="sk" <?php echo ( 'sk' === $language ) ? 'selected' : ''; ?>>Slovak</option>
						<option value="sl" <?php echo ( 'sl' === $language ) ? 'selected' : ''; ?>>Slovenian</option>
						<option value="es" <?php echo ( 'es' === $language ) ? 'selected' : ''; ?>>Spanish</option>
						<option value="es_AR" <?php echo ( 'es_AR' === $language ) ? 'selected' : ''; ?>>Spanish (ARG)</option>
						<option value="es_ES" <?php echo ( 'es_ES' === $language ) ? 'selected' : ''; ?>>Spanish (SPA)</option>
						<option value="es_MX" <?php echo ( 'es_MX' === $language ) ? 'selected' : ''; ?>>Spanish (MEX)</option>
						<option value="sw" <?php echo ( 'sw' === $language ) ? 'selected' : ''; ?>>Swahili</option>
						<option value="sv" <?php echo ( 'sv' === $language ) ? 'selected' : ''; ?>>Swedish</option>
						<option value="ta" <?php echo ( 'ta' === $language ) ? 'selected' : ''; ?>>Tamil</option>
						<option value="te" <?php echo ( 'te' === $language ) ? 'selected' : ''; ?>>Telugu</option>
						<option value="th" <?php echo ( 'th' === $language ) ? 'selected' : ''; ?>>Thai</option>
						<option value="tr" <?php echo ( 'tr' === $language ) ? 'selected' : ''; ?>>Turkish</option>
						<option value="uk" <?php echo ( 'uk' === $language ) ? 'selected' : ''; ?>>Ukrainian</option>
						<option value="ur" <?php echo ( 'ur' === $language ) ? 'selected' : ''; ?>>Urdu</option>
						<option value="uz" <?php echo ( 'uz' === $language ) ? 'selected' : ''; ?>>Uzbek</option>
						<option value="vi" <?php echo ( 'vi' === $language ) ? 'selected' : ''; ?>>Vietnamese</option>
						<option value="zu" <?php echo ( 'zu' === $language ) ? 'selected' : ''; ?>>Zulu</option>
					</select>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<?php esc_html_e( 'Template category', 'flow_notify_text' ); ?>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select name="template_category" id="template_category" <?php echo ( 'whatsapp' === $type_template && 'REJECTED' !== $approval_status ) ? 'disabled' : ''; ?>>
						<option value="Marketing" <?php echo ( 'Marketing' === $category ) ? 'selected' : ''; ?>>Marketing</option>
						<option value="Authentication" <?php echo ( 'Authentication' === $category ) ? 'selected' : ''; ?>>Authentication</option>
						<option value="Utility" <?php echo ( 'Utility' === $category ) ? 'selected' : ''; ?>>Utility</option>
					</select>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row zworkflowmanager_order_status_fields">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="message"><?php esc_html_e( 'Message', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zwf__message-wrap">
					<textarea class="short js-zwf-message"
							  name="description"
							  id="message"
							  rows="7"
							  cols="20"
							  spellcheck="false"
							  <?php echo ( 'whatsapp' === $type_template && 'REJECTED' !== $approval_status ) ? 'disabled' : ''; ?>
					><?php echo esc_attr( $template_text ); ?></textarea>
					<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/supported-data-types.php'; ?>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<span class="whatsapp_approval_status">Status</span>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">

					<input type="text" class="zworkflow_approval_status whatsapp_approval_status" id="zworkflow_approval_status" name="approval_status" value="<?php echo esc_attr( $approval_status ); ?>" disabled>
					<?php if ( 'whatsapp' === $type_template ) { ?>
					<button type="button" id="zworkflowmanager_get_status" class="button button-primary get-status" data-template-name="<?php echo esc_attr( $template_name ); ?>" data-template-id="<?php echo esc_attr( $edit_template ); ?>">
						<?php esc_html_e( 'Get Status', 'flow_notify_text' ); ?>
					</button>
						<a href="https://business.facebook.com/wa/manage/message-templates/" target="_blank" class="zworkflowmanager_view_status">View Status in WhatsApp Message templates Manager</a>
					<?php } ?>
				</td>
			</tr>
			<tr class="zworkflowmanager_flex_center margin-top zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_4 zworkflowmanager_disabled_padding">
					<button type="submit"
							id="zworkflowmanager_save_message_template"
							class="button button-primary"><?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?>
					</button>
					<?php
						$delete_link       = admin_url( 'admin.php?page=wc-workflows&tab=connection&zfn_operation_type=delete_message_template&message_template_id=' . $edit_template . '&sending_type=' . $type_template . '&whatsapp_template_id=' . $whatsapp_template_id . '&template_name=' . $template_name );
						$delete_nonce_link = wp_nonce_url( $delete_link, 'zfn_operation_type', 'zwf_nonce' );
					?>
					<a href="<?php echo esc_url( $delete_nonce_link ); ?>"
					   class="button delete-notification-btn js-delete-notification js-delete-message-template">
						<?php esc_html_e( 'Delete', 'flow_notify_text' ); ?>
					</a>
				</td>
				<td class="zworkflowmanager_col_8 zworkflowmanager_disabled_padding zworkflowmanager_button_right">
					<a href="?page=wc-workflows&tab=emails&section=message-templates" class="zworkflowmanager_button_template"><?php esc_html_e( 'Message Template Dashboard', 'flow_notify_text' ); ?></a>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
</form>

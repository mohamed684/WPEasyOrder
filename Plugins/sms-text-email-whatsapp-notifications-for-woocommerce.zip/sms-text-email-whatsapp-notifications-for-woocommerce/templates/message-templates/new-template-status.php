<?php
/**
 * Flow-Notify Notifications tab
 * add new notification
 *
 * @package Flow-Notify/templates/emails/new-email-status
 */

?>
<form method="POST"
	  action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	  id="zworkflowmanager_edit_status">
	<input type="hidden" name="action" value="zworkflowmanager_new_message_template">
	<?php $nonce = wp_create_nonce( 'zwf_template_message_nonce' ); ?>
	<input type="hidden" name="zwf_template_message_nonce" value="<?php echo esc_attr( $nonce ); ?>">
	<div id="zworkflowmanager_order_status_data">
		<table class="zworkflowmanager_row zworkflowmanager_col_12">
			<tbody class="zworkflowmanager_row zworkflowmanager_col_12">
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding"><?php esc_html_e( 'Status', 'flow_notify_text' ); ?></td>
				<td class="status column-status zworkflowemail_status_toggle">
					<label class="zworkflowmanager_switch">
						<input type="checkbox"
							   id="status_toggle"
							   name="status_toggle"
							   checked
							   class="js-zworkflowmanager_status_switcher">
						<span class="zworkflowmanager_slider round"></span>
					</label>
					<span class="js-status-text status-text"><?php esc_html_e( 'Enabled', 'flow_notify_text' ); ?></span>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="post_title"><?php esc_html_e( 'Name', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short"
						   style=""
						   name="post_title"
						   id="post_title"
						   value=""
						   required
						   placeholder=""
						   maxlength="35">
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="type"><?php esc_html_e( 'Type', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select id="type" name="sending_type" class="js-sending-type">
						<option value="SMS"><?php esc_html_e( 'SMS', 'flow_notify_text' ); ?></option>
						<option value="email"><?php esc_html_e( 'Email', 'flow_notify_text' ); ?></option>
						<option value="whatsapp"><?php esc_html_e( 'WhatsApp', 'flow_notify_text' ); ?></option>
					</select>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row zcustomemail_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="zmessagetemplate_subject"><?php esc_html_e( 'Subject', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short js-subject"
						   name="zmessagetemplate_subject"
						   id="zmessagetemplate_subject"
						   maxlength="35">
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="zcustomemail_template_name"><?php esc_html_e( 'Template name', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						   class="short js-subject"
						   name="zcustomemail_template_name"
						   id="zcustomemail_template_name"
						   maxlength="35"
						   >
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<?php esc_html_e( 'Template language', 'flow_notify_text' ); ?>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select name="template_language" id="template_language">
						<option value="en_US">English (US)</option>
						<option value="en_GB">English (UK)</option>
						<option value="af">Afrikaans</option>
						<option value="sq">Albanian</option>
						<option value="ar">Arabic</option>
						<option value="az">Azerbaijani</option>
						<option value="bn">Bengali</option>
						<option value="bg">Bulgarian</option>
						<option value="ca">Catalan</option>
						<option value="zh_CN">Chinese (CHN)</option>
						<option value="zh_HK">Chinese (HKG)</option>
						<option value="zh_TW">Chinese (TAI)</option>
						<option value="hr">>Croatian</option>
						<option value="cs">Czech</option>
						<option value="da">Danish</option>
						<option value="nl">Dutch</option>
						<option value="et">Estonian</option>
						<option value="fil">Filipino</option>
						<option value="fi">Finnish</option>
						<option value="fr">French</option>
						<option value="ka">Georgian</option>
						<option value="de">German</option>
						<option value="el">Greek</option>
						<option value="gu">Gujarati</option>
						<option value="ha">Hausa</option>
						<option value="he">Hebrew</option>
						<option value="hi">Hungarian</option>
						<option value="id">Indonesian</option>
						<option value="ga">Irish</option>
						<option value="it">Italian</option>
						<option value="ja">Japanese</option>
						<option value="kn">Kannada</option>
						<option value="kk">Kazakh</option>
						<option value="rw_RW">Kinyarwanda</option>
						<option value="ko">Korean</option>
						<option value="ky_KG">Kyrgyz (Kyrgyzstan)</option>
						<option value="lo">Lao</option>
						<option value="lv">Latvian</option>
						<option value="lt">Lithuanian</option>
						<option value="mk">Macedonian</option>
						<option value="ms">Malay</option>
						<option value="ml">Malayalam</option>
						<option value="mr">Marathi</option>
						<option value="nb">Norwegian</option>
						<option value="fa">Persian</option>
						<option value="pl">Polish</option>
						<option value="pt_BR">Portuguese (BR)</option>
						<option value="pt_PT">Portuguese (POR)</option>
						<option value="pa">Punjabi</option>
						<option value="ro">Romanian</option>
						<option value="ru">Russian</option>
						<option value="sr">Serbian</option>
						<option value="sk">Slovak</option>
						<option value="sl">Slovenian</option>
						<option value="es">Spanish</option>
						<option value="es_AR">Spanish (ARG)</option>
						<option value="es_ES">Spanish (SPA)</option>
						<option value="es_MX">Spanish (MEX)</option>
						<option value="sw">Swahili</option>
						<option value="sv">Swedish</option>
						<option value="ta">Tamil</option>
						<option value="te">Telugu</option>
						<option value="th">Thai</option>
						<option value="tr">Turkish</option>
						<option value="uk">Ukrainian</option>
						<option value="ur">Urdu</option>
						<option value="uz">Uzbek</option>
						<option value="vi">Vietnamese</option>
						<option value="zu">Zulu</option>
					</select>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row ztemplatename_subject-wrap">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<?php esc_html_e( 'Template category', 'flow_notify_text' ); ?>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<select name="template_category" id="template_category">
						<option value="Marketing">Marketing</option>
						<option value="Authentication">Authentication</option>
						<option value="Utility">Utility</option>
					</select>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row zworkflowmanager_order_status_fields">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="message"><?php esc_html_e( 'Message', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zwf__message-wrap">
					<textarea class="short js-zwf-message"
							  name="description"
							  id="message"
							  rows="7"
							  cols="20"
							  spellcheck="false"></textarea>
					<?php require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/supported-data-types.php'; ?>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<snap class="whatsapp_approval_status">Status</snap>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text" class="zworkflow_approval_status whatsapp_approval_status" name="approval_status" value="Need Approval" disabled>
					<button type="submit"
							id="zworkflowmanager_save_message_template"
							class="button button-primary"><?php esc_html_e( 'Save', 'flow_notify_text' ); ?>
					</button>
					<a href="?page=wc-workflows&tab=emails&section=message-templates" class="zwf__email-button"><?php esc_html_e( 'Message Template Dashboard', 'flow_notify_text' ); ?></a>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
</form>

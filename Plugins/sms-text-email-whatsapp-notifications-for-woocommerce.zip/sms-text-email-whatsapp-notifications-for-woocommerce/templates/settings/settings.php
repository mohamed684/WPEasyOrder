<?php
/**
 * Flow-Notify settings tab
 *
 * @package Flow-Notify/templates/settings
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Settings' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-settings.php';
}

if ( ! class_exists( 'ZWORKFLOWMANAGER_Logger' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-logger.php';
}

$logger                = new ZWORKFLOWMANAGER_Logger();
$settings_status       = new ZWORKFLOWMANAGER_Settings();
$settings              = $settings_status->get_settings();
$select_values         = array(
	'email'    => 'Email',
	'sms'      => 'SMS',
	'whatsapp' => 'WhatsApp',
);
$display_select_values = array(
	'always'       => 'Always',
	'out_of_stock' => 'Only when out of stock',
);

$section = ( isset( $_GET['section'] ) ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';

?>

<h3 class="workflows-title"><?php esc_html_e( 'Settings', 'flow_notify_text' ); ?></h3>
<nav class="nav-tab-wrapper woo-nav-tab-wrapper">
	<a class="nav-tab<?php echo ( ( ! $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=settings"><?php echo esc_html( 'General' ); ?></a>
	<a class="nav-tab<?php echo ( ( 'opt-ins' === $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=settings&section=opt-ins"><?php echo esc_html( 'Opt-ins' ); ?></a>
	<a class="nav-tab<?php echo ( ( 'support' === $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=settings&section=support"><?php echo esc_html( 'Support' ); ?></a>
</nav>

<?php if ( 'opt-ins' === $section ) { ?>

	<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
		id="zworkflowmanager_settings_template">
		<input type="hidden" name="action" value="zworkflowmanager_settings_template">
		<?php wp_nonce_field( 'settings_notify_action', 'settings_notify_nonce_field' ); ?>
		<input type="hidden" name="type-form" value="opt-in">
		<div class="wrap woocommerce" style="margin-top:10px;">
			<h3><?php esc_html_e( 'Product Settings', 'flow_notify_text' ); ?></h3>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Product Page', 'flow_notify_text' ); ?></h3>
			<label for="product_page">
				<?php $checked = ( isset( $settings['product_page'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="product_page" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					id="product_page"
					name="product_page"/>
				<span>
					<?php esc_html_e( 'Enable notification opt-in on product pages', 'flow_notify_text' ); ?>
				</span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Display', 'flow_notify_text' ); ?></h3>
			<label for="display_on_product_page">
				<select id="display_on_product_page"
						name="display_on_product_page">
					<?php
					foreach ( $display_select_values as $value => $text ) {
						$selected = ( isset( $settings['display_on_product_page'] ) && $settings['display_on_product_page'] === $value ) ? 'selected' : '';
						?>
						<option <?php echo esc_attr( $selected ); ?> value="<?php echo esc_attr( $value ); ?>">
							<?php echo esc_textarea( $text ); ?>
						</option>
					<?php } ?>
				</select>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Notify Opt-in Text', 'flow_notify_text' ); ?></h3>
			<label for="notify_opt_in_text">
				<input type="text"
					value="<?php echo isset( $settings['notify_opt_in_text'] ) ? esc_attr( $settings['notify_opt_in_text'] ) : ''; ?>"
					id="notify_opt_in_text"
					name="notify_opt_in_text"/>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Notify Button Text', 'flow_notify_text' ); ?></h3>
			<label for="notify_button_text">
				<input type="text"
					value="<?php echo isset( $settings['notify_button_text'] ) ? esc_attr( $settings['notify_button_text'] ) : ''; ?>"
					id="notify_button_text"
					name="notify_button_text"/>
			</label>
		</div>
		<div class="wrap woocommerce" style="margin-top:10px;">
			<h3><?php esc_html_e( 'Checkout Settings', 'flow_notify_text' ); ?></h3>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Notification opt-in', 'flow_notify_text' ); ?></h3>
			<label for="notification_opt-in">
				<?php $checked = ( isset( $settings['notification_opt-in'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="notification_opt-in" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					id="notification_opt-in"
					name="notification_opt-in"/>
				<span>
					<?php esc_html_e( 'Enable notification opt-in', 'flow_notify_text' ); ?>
				</span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Default Country Code', 'flow_notify_text' ); ?></h3>
			<div class="default-code-wrapper">
				<input id="zwf_default-code" type="text">
				<input id="zwf_default-code-hidden" type="hidden" name="default_code">
			</div>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Opt-in Text', 'flow_notify_text' ); ?></h3>
			<label for="opt-in_text">
				<input type="text"
					value="<?php echo isset( $settings['opt-in_text'] ) ? esc_attr( $settings['opt-in_text'] ) : ''; ?>"
					id="opt-in_text"
					name="opt-in_text"/>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Communication preference', 'flow_notify_text' ); ?></h3>
			<label for="communication_preference">
				<?php $checked = ( isset( $settings['communication_preference'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_preference" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					class="js-communication_preference"
					id="communication_preference"
					name="communication_preference"/>
				<span>
					<?php esc_html_e( 'Enable communication preference selection on checkout', 'flow_notify_text' ); ?>
				</span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3> <?php esc_html_e( 'Display Communication Methods', 'flow_notify_text' ); ?></h3>
			<label for="communication_methods_email">
				<?php $checked = ( isset( $settings['communication_methods_email'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_email" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					class="js-communication_methods"
					value="email"
					id="communication_methods_email"
					name="communication_methods_email"/>
				<span><?php esc_html_e( 'Email', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3></h3>
			<label for="communication_methods_sms">
				<?php $checked = ( isset( $settings['communication_methods_sms'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_sms" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					class="js-communication_methods"
					value="sms"
					id="communication_methods_sms"
					name="communication_methods_sms"/>
				<span><?php esc_html_e( 'SMS', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3></h3>
			<label for="communication_methods_whatsapp">
				<?php $checked = ( isset( $settings['communication_methods_whatsapp'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_whatsapp" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					   class="js-communication_methods"
					   value="whatsapp"
					   id="communication_methods_whatsapp"
					   name="communication_methods_whatsapp"/>
				<span><?php esc_html_e( 'WhatsApp', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap margin-bottom">
			<h3><?php esc_html_e( 'Default Communication Method', 'flow_notify_text' ); ?></h3>
			<label for="default_communication_method">
				<select class="js-default_communication_method"
						id="default_communication_method"
						name="default_communication_method">
					<?php
					foreach ( $select_values as $value => $text ) {
						$selected = ( isset( $settings['default_communication_method'] ) && $settings['default_communication_method'] === $value ) ? 'selected' : '';
						?>
						<option <?php echo esc_attr( $selected ); ?> value="<?php echo esc_attr( $value ); ?>">
							<?php echo esc_attr( $text ); ?>
						</option>
					<?php } ?>
				</select>
			</label>
		</div>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?></button>
	</form>

<?php } elseif ( 'support' === $section ) { ?>
<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	  id="zworkflowmanager_settings_template">
	<input type="hidden" name="action" value="zworkflowmanager_settings_template">
	<?php wp_nonce_field( 'settings_notify_action', 'settings_notify_nonce_field' ); ?>
	<input type="hidden" name="type-form" value="support">
	<div class="settings_template__wrap">
		<div class="settings_template__block-wrap support">
			<h3><?php esc_html_e( 'Requests', 'flow_notify_text' ); ?></h3>
			<a href="https://bizswoop.atlassian.net/servicedesk/customer/portal/4/group/4/create/10049" target="_blank" class="external-link"><?php esc_html_e( 'Create a support request', 'flow_notify_text' ); ?></a>
		</div>
		<div>
			<h3><?php esc_html_e( 'Connections', 'flow_notify_text' ); ?></h3>
		</div>
		<div class="settings_template__block-wrap support">
			<h3><?php esc_html_e( 'Active', 'flow_notify_text' ); ?></h3>
			<label for="save_info_logs">
				<?php $checked = ( isset( $settings['save_info_logs'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="save_info_logs" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					   id="save_info_logs"
					   name="save_info_logs"/>
				<span><?php esc_html_e( 'Save info logs', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap support">
			<h3><?php esc_html_e( 'Log file content', 'flow_notify_text' ); ?></h3>
			<a href="<?php echo esc_url( ZWORKFLOWMANAGER_LOGS_CONNECTION_PATH ); ?>" class="button light view-log<?php echo ( ! $logger::get_connection_logs_filesize() ) ? ' disabled' : ''; ?>" target="_blank"><?php esc_html_e( 'View log', 'flow_notify_text' ); ?></a>
			<button type="button" class="button light copy-log-connection zworkflowmanager_opy-log"<?php echo ( ! $logger::get_connection_logs_filesize() ) ? ' disabled="disabled"' : ''; ?>><?php esc_html_e( 'Copy log', 'flow_notify_text' ); ?></button>
		</div>
		<div class="settings_template__block-wrap support">
			<?php
				$clear_log_url       = get_site_url() . '/wp-admin/admin.php?page=wc-workflows&tab=settings&section=support&zfn_operation_type=clear-log-connection';
				$clear_log_url_nonce = wp_nonce_url( $clear_log_url, 'zfn_operation_type', 'zwf_nonce' );
			?>
			<h3><?php esc_html_e( 'Clear log file', 'flow_notify_text' ); ?> (<?php esc_html_e( 'Size', 'flow_notify_text' ); ?> <?php echo esc_attr( $logger::get_connection_logs_filesize() ) . 'KB'; ?> )</h3>
			<a href="<?php echo esc_url( $clear_log_url_nonce ); ?>" class="button light clear-log-connection<?php echo ( ! $logger::get_connection_logs_filesize() ) ? ' disabled' : ''; ?>"><?php esc_html_e( 'Clear log file', 'flow_notify_text' ); ?></a>
		</div>
		<div>
			<h3><?php esc_html_e( 'Plugin', 'flow_notify_text' ); ?></h3>
		</div>
		<div class="settings_template__block-wrap support">
			<h3><?php esc_html_e( 'Log file content', 'flow_notify_text' ); ?></h3>
			<a href="<?php echo esc_url( ZWORKFLOWMANAGER_LOGS_PATH ); ?>" class="button light view-log<?php echo ( ! $logger::get_logs_filesize() ) ? ' disabled' : ''; ?>" target="_blank"><?php esc_html_e( 'View log', 'flow_notify_text' ); ?></a>
			<button type="button" class="button light copy-log zworkflowmanager_opy-log"<?php echo ( ! $logger::get_logs_filesize() ) ? ' disabled="disabled"' : ''; ?>><?php esc_html_e( 'Copy log', 'flow_notify_text' ); ?></button>
		</div>
		<?php
			$clear_log_file_url   = get_site_url() . '/wp-admin/admin.php?page=wc-workflows&tab=settings&section=support&zfn_operation_type=clear-log';
			$clear_log_file_nonce = wp_nonce_url( $clear_log_file_url, 'zfn_operation_type', 'zwf_nonce' );
		?>
		<div class="settings_template__block-wrap support">
			<h3><?php esc_html_e( 'Clear log file', 'flow_notify_text' ); ?> (<?php esc_html_e( 'Size', 'flow_notify_text' ); ?>  <?php echo esc_attr( $logger::get_logs_filesize() ) . 'KB'; ?>)</h3>
			<a href="<?php echo esc_url( $clear_log_file_nonce ); ?>" class="button light clear-log<?php echo ( ! $logger::get_logs_filesize() ) ? ' disabled' : ''; ?>"><?php esc_html_e( 'Clear log file', 'flow_notify_text' ); ?></a>
		</div>
		<div class="settings_template__block-wrap support margin-bottom">
			<h3><?php esc_html_e( 'Delete Data and Reset', 'flow_notify_text' ); ?></h3>
			<label for="delete_setting">
				<?php $checked = ( isset( $settings['delete_setting'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="delete_setting" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					   id="delete_setting"
					   name="delete_setting"/>
				<span><?php esc_html_e( 'Yes, Delete data and reset settings when plugin is deactivated and deleted. All settings will be deleted.', 'flow_notify_text' ); ?></span>
			</label>
		</div>
	</div>
	<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?></button>
</form>
<?php } else { ?>

<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	id="zworkflowmanager_settings_template">
	<input type="hidden" name="action" value="zworkflowmanager_settings_template">
	<?php wp_nonce_field( 'settings_notify_action', 'settings_notify_nonce_field' ); ?>
	<input type="hidden" name="type-form" value="general">
	<div class="settings_template__wrap">
		<div class="wrap woocommerce" style="margin-top:10px;">
			<h3><?php esc_html_e( 'Notification Settings', 'flow_notify_text' ); ?></h3>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Message Timeframe Schedule', 'flow_notify_text' ); ?></h3>
			<label for="message_timeframe_schedule">
				<?php $checked = ( isset( $settings['message_timeframe_schedule'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="message_timeframe_schedule" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					class="js-message_timeframe_schedule"
					id="message_timeframe_schedule"
					name="message_timeframe_schedule"/>
				<span>
					<?php esc_html_e( 'Enable a Message Timeframe Schedule', 'flow_notify_text' ); ?>
				</span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3> <?php esc_html_e( 'Communication Methods for Schedule', 'flow_notify_text' ); ?></h3>
			<label for="communication_methods_schedule_email">
				<?php $checked = ( isset( $settings['communication_methods_schedule_email'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_schedule_email" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					   class="js-communication_methods_schedule"
					   value="email"
					   id="communication_methods_schedule_email"
					   name="communication_methods_schedule_email"/>
				<span><?php esc_html_e( 'Email', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3></h3>
			<label for="communication_methods_schedule_sms">
				<?php $checked = ( isset( $settings['communication_methods_schedule_sms'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_schedule_sms" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					class="js-communication_methods_schedule"
					value="sms"
					id="communication_methods_schedule_sms"
					name="communication_methods_schedule_sms"/>
				<span><?php esc_html_e( 'SMS', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3></h3>
			<label for="communication_methods_schedule_wa">
				<?php $checked = ( isset( $settings['communication_methods_schedule_wa'] ) ) ? 'checked' : ''; ?>
				<input type="hidden" name="communication_methods_schedule_wa" value="off">
				<input type="checkbox" <?php echo esc_attr( $checked ); ?>
					   class="js-communication_methods_schedule"
					   value="whatsapp"
					   id="communication_methods_schedule_wa"
					   name="communication_methods_schedule_wa"/>
				<span><?php esc_html_e( 'WhatsApp', 'flow_notify_text' ); ?></span>
			</label>
		</div>
		<div class="settings_template__block-wrap">
			<h3><?php esc_html_e( 'Schedule Timeframe for Messages', 'flow_notify_text' ); ?></h3>
			<label for="schedule_timeframe">
				<span><?php esc_html_e( 'Time', 'flow_notify_text' ); ?></span>
				<input data-schedule-time="<?php echo isset( $settings['schedule_timeframe_from'] ) ? esc_attr( $settings['schedule_timeframe_from'] ) : ''; ?>"
					class="js-schedule_timeframe js-schedule_timeframe_from" type="time"
					name="schedule_timeframe_from"
					id="schedule_timeframe_from">
				<span><?php esc_html_e( ' - ', 'flow_notify_text' ); ?></span>
				<input data-schedule-time="<?php echo isset( $settings['schedule_timeframe_to'] ) ? esc_attr( $settings['schedule_timeframe_to'] ) : ''; ?>"
					class="js-schedule_timeframe js-schedule_timeframe_to" type="time"
					name="schedule_timeframe_to"
					id="schedule_timeframe_to">
				<span class="schedule_timeframe_message"><?php esc_html_e( 'Messages will only be sent during the timeframe schedule based upon ', 'flow_notify_text' ); ?>
					<a href="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>"><?php esc_html_e( 'General Settings', 'flow_notify_text' ); ?></a>
					<?php esc_html_e( ' > Timezone Settings, Local Time', 'flow_notify_text' ); ?>
				</span>
			</label>
		</div>
	</div>
	<?php
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/email-template-settings.php';
	?>
	<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Changes', 'flow_notify_text' ); ?></button>
</form>
<?php } ?>

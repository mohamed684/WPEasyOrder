<?php
/**
 * Flow-Notify Order Status tab
 *
 * @package Flow-Notify/templates/order-statuses/order-statuses
 */

$order_tab    = ( isset( $_GET['tab'] ) ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
$notification = ( isset( $_GET['notification'] ) ) ? sanitize_text_field( wp_unslash( $_GET['notification'] ) ) : '';

$order_status_tab_active = ( 'order_status' === $order_tab ) ? 'nav-tab-active' : ' ';
$emails_tab_active       = ( 'emails' === $order_tab ) ? 'nav-tab-active' : ' ';
$connection_tab_active   = ( 'connection' === $order_tab ) ? 'nav-tab-active' : ' ';
$send_tab_active         = ( 'send' === $order_tab ) ? 'nav-tab-active' : ' ';
$activities_tab_active   = ( 'activities' === $order_tab ) ? 'nav-tab-active' : ' ';
$settings_tab_active     = ( 'settings' === $order_tab ) ? 'nav-tab-active' : ' ';
$dashboard_tab_active    = ( 'dashboard' === $order_tab ) ? 'nav-tab-active' : ' ';

if ( 'order_status' === $order_tab ) {
	$edit_order_status = ( isset( $_GET['edit_status'] ) ) ? sanitize_text_field( wp_unslash( $_GET['edit_status'] ) ) : 0;
	$add_new           = ( isset( $_GET['add_new'] ) ) ? sanitize_text_field( wp_unslash( $_GET['add_new'] ) ) : 0;

	if ( 0 !== (int) $edit_order_status ) {
		require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/order-statuses/edit-order-status.php';
	} elseif ( 0 !== (int) $add_new ) {
		require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/order-statuses/new-order-status.php';
	} else {
		echo '<div class="wrap woocommerce flex-wrap" style="margin-top:10px;">
                <h3 class="workflows-title">' . esc_html__( 'Order Status', 'flow_notify_text' ) . '</h3>
                <a href="' . esc_url( add_query_arg( array( 'add_new' => 1 ) ) ) . '"
                   class="page-title-action"
                   style="margin-left:15px;">' . esc_html__( 'Add', 'flow_notify_text' ) . '</a>
              </div>';

		require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-order-statuses.php';

		$order_statuses_list = new ZWORKFLOWMANAGER_Core_Order_Statuses();
		$order_statuses_list->print_overview();
	}
} elseif ( 'emails' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/emails/emails.php';
} elseif ( 'connection' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/connection/connection.php';
} elseif ( 'send' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/send/send.php';
} elseif ( 'activities' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/activities/activities.php';
} elseif ( 'settings' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/settings/settings.php';
} elseif ( 'dashboard' === $order_tab ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'templates/dashboard/dashboard.php';
}



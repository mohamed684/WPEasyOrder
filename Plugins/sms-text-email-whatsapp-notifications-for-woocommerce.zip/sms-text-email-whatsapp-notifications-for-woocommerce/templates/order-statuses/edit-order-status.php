<?php
/**
 * Flow-Notify Order Status tab
 * edit order status
 *
 * @package Flow-Notify/templates/order-statuses/edit-order-status
 */

if ( ! class_exists( 'ZWORKFLOWMANAGER_Order_Status' ) ) {
	require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/models/class-zworkflowmanager-order-status.php';
}

$edit_order_status = ( isset( $_GET['edit_status'] ) && ! empty( $_GET['edit_status'] ) ? sanitize_text_field( wp_unslash( $_GET['edit_status'] ) ) : 0 );

if ( 0 === (int) $edit_order_status ) {
	?>
	<h3><?php esc_html_e( 'Order status doesn\'t exist', 'flow_notify_text' ); ?></h3>
	<?php
}


$order_status = new ZWORKFLOWMANAGER_Order_Status( $edit_order_status );
?>
<?php
if ( ! $order_status->is_core_status() ) :
	?>
	<div id="zworkflowmanager_delete_order_status_container" class="zworkflowmanager_loading_screen">
		<img alt="loading" id="zworkflowmanager_loading_img"
			src="<?php echo esc_attr( plugin_dir_url( ZWORKFLOWMANAGER_BASE_FILE ) ) . 'assets/img/wpspin_light-2x.gif'; ?>"
			class="zworkflowmanager_hidden"/>
		<div id="zworkflowmanager_delete_order_status_box"
			class="zworkflowmanager_row zworkflowmanager_col_4 zworkflowmanager_disabled_padding"
			style="z-index: 4; margin: 6rem auto; padding: 1rem 2rem !important; border: 1px solid; background: white; text-align: center;">
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding" style="text-align: right">
				<a id="zworkflowmanager_close_delete_order_status_box"><span class="dashicons dashicons-no-alt"></span></a>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
				<h3><?php esc_html_e( 'Are you sure you want to delete this order status?', 'flow_notify_text' ); ?></h3>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
				<p>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=shop_order&post_status=' ) . $order_status->get_slug() ); ?>">
						<?php echo esc_textarea( 'There are currently ' . $order_status->get_orders_count() . ' orders marked as ' . $order_status->get_status_title() . '' ); ?>
					</a>
				</p>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
				<p><?php esc_html_e( 'You can choose to reassign the status of existing orders with another before deleting or have it reassigned automatically.', 'flow_notify_text' ); ?></p>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
				<select name="new_status" id="new_status_reassign">
					<?php
					$order_statuses = wc_get_order_statuses();
					if ( $order_statuses ) {
						foreach ( $order_statuses as $slug => $name ) {
							if ( $slug !== $order_status->get_slug() ) {
								echo '<option value="' . esc_attr( $slug ) . '">' . esc_textarea( $name ) . '</option>';
							}
						}
					}
					?>
				</select>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding" style="margin-top: 1rem;">
				<a id="zworkflowmanager_delete_reassign_button" class="button"
				data-id="<?php echo esc_attr( $order_status->get_id() ); ?>"
				style="margin-right:10px;"><?php esc_html_e( 'Reassign and delete', 'flow_notify_text' ); ?></a>
				<a id="zworkflowmanager_delete_directly_button" class="button"
				data-id="<?php echo esc_attr( $order_status->get_id() ); ?>"><?php esc_html_e( 'Delete', 'flow_notify_text' ); ?></a>
			</div>
			<div class="zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
				<p>
					<span><i><?php esc_html_e( 'Either operation cannot be undone automatically.', 'flow_notify_text' ); ?></i></span><br>
					<span><i><?php esc_html_e( 'Email and other actions will not be triggered automatically.', 'flow_notify_text' ); ?></i></span>
				</p>
			</div>
		</div>
	</div>
<?php endif; ?>
<h2 class="workflows-title"><?php esc_html_e( 'Edit Order Status', 'flow_notify_text' ); ?>
</h2>
<form method="POST" action="<?php echo esc_attr( admin_url( 'admin-post.php' ) ); ?>"
	id="zworkflowmanager_edit_status">
	<input type="hidden" name="action" value="zworkflowmanager_edit_status">
	<input type="hidden" name="status_id" value="<?php echo esc_attr( $edit_order_status ); ?>">
	<?php $nonce = wp_create_nonce( 'zwf_order_status' ); ?>
	<input type="hidden" id="zwf_order_status" name="zwf_order_status" value="<?php echo esc_attr( $nonce ); ?>">
	<div id="zworkflowmanager_order_status_data">
		<div class="zworkflowmanager_edit_status_title">
			<h3><?php esc_html_e( 'Order Status Data', 'flow_notify_text' ); ?></h3>
		</div>
		<table class="zworkflowmanager_row zworkflowmanager_col_12">
			<tbody class="zworkflowmanager_row zworkflowmanager_col_12">
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="post_title"><?php esc_html_e( 'Name', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						class="short"
						style=""
						name="post_title"
						id="post_title"
						value="<?php echo esc_attr( $order_status->get_name() ); ?>"
						required
						placeholder=""
						maxlength="35"
						<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="slug"><?php esc_html_e( 'Slug', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						class="short"
						style=""
						name="slug"
						id="slug"
						value="<?php echo esc_attr( $order_status->get_slug() ); ?>"
						placeholder=""
						required
						maxlength="17" onchange="leadingWC(this)"
						<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>>
				</td>
			</tr>

			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row zworkflowmanager_order_status_fields">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="order_description"><?php esc_html_e( 'Description', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<textarea name="order_description" id="order_description" rows="2"
							spellcheck="false"><?php echo esc_textarea( $order_status->get_description() ); ?></textarea>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="text_color"><?php esc_html_e( 'Text Color', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						class="short zworkflowmanager_wp_colorpick"
						style=""
						name="text_color"
						id="text_color"
						value="<?php echo esc_attr( $order_status->get_text_color() ); ?>"
						placeholder=""
						maxlength="35">
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="background_color"><?php esc_html_e( 'Text Background Color', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding">
					<input type="text"
						class="short zworkflowmanager_wp_colorpick"
						style=""
						name="background_color"
						id="background_color"
						value="<?php echo esc_attr( $order_status->get_background_color() ); ?>"
						placeholder=""
						maxlength="35">
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding" style="align-self: baseline;">
					<label for="action_icon_box"
						class="zworkflowmanager_col_2 zworkflowmanager_disabled_padding"><?php esc_html_e( 'Icon Action', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
					<div id="action_icon_box"
						class="zworkflowmanager_col_12 zworkflowmanager_center zworkflowmanager_disabled_padding"
						style="height: 200px; overflow-y: scroll; overflow-x:hidden;">
						<div class="zworkflowmanager_col_12 zworkflowmanager_center zworkflowmanager_disabled_padding zworkflowmanager_row">
							<?php
							$icons      = get_option( 'zworkflowmanager_icons' );
							$order_icon = $order_status->get_action_icon();
							foreach ( $icons as $class => $glyph ) :
								?>
								<div class="zworkflowmanager_col_1 zworkflowmanager_center
								<?php echo $order_icon === $class ? 'zworkflowmanager_selected_hover_icon' : ''; ?>"
									style="padding: 5px 0; !important;">
									<input type="radio" name="zworkflowmanager_action_icon"
										value="<?php echo esc_attr( $class ); ?>"
										id="zworkflowmanager_action_icon_<?php echo esc_attr( $class ); ?>"
										class="zworkflowmanager_hidden"
										<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>/>
									<label class="zworkflowmanager_action_icon_label
									<?php echo $order_status->is_core_status() ? 'zworkflowmanager_disabled' : ''; ?>"
										style="margin-left: 0;"
										for="zworkflowmanager_action_icon_<?php echo esc_attr( $class ); ?>">
										<i class="<?php echo esc_attr( $class ); ?>" aria-hidden="true"></i>
									</label>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="zworkflowmanager_next_statuses"><?php esc_html_e( 'Next Statuses', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
					<select id="zworkflowmanager_next_statuses"
							name="next_statuses[]" multiple="multiple">
						<?php
						$order_statuses = $order_status->get_core_statuses();
						$order_names    = $order_status->get_order_status_title();

						foreach ( $order_names as $key => $name ) {
							if ( array_search( $name, $order_statuses, true ) ) {
								continue;
							}
							$order_statuses += array( $key => $name );
						}
						$next_statues = $order_status->get_next_statuses();
						if ( $order_statuses ) {
							foreach ( $order_statuses as $slug => $name ) {
								$extra = '';
								if ( array_search( $slug, $next_statues, true ) ) {
									$extra = 'selected="selected"';
								}
								echo '<option value="' . esc_attr( $slug ) . '" ' . esc_attr( $extra ) . '>' . esc_textarea( $name ) . '</option>';
							}
						}
						?>
					</select>
				</td>
			</tr>
			<?php if ( ! $order_status->is_core_status() ) : ?>
				<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
					<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding" style="align-self: baseline">
						<label for="zworkflowmanager_default_status"><?php esc_html_e( 'Default Statuses', 'flow_notify_text' ); ?></label>

					</td>
					<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
						<select id="zworkflowmanager_default_status"
								name="default_status" required>
							<option value=""><?php esc_html_e( 'Select one status...', 'flow_notify_text' ); ?></option>
							<?php
							$order_statuses = $order_status->get_core_statuses();
							$default_status = $order_status->get_default_status();
							if ( $order_statuses ) {
								foreach ( $order_statuses as $key => $o_status ) {
									$extra = '';
									if ( $key === $default_status ) {
										$extra = 'selected="selected"';
									}
									echo '<option value="' . esc_attr( $key ) . '" ' . esc_attr( $extra ) . '>' . esc_textarea( $o_status ) . '</option>';
								}
							}
							?>
						</select>
						<label for="zworkflowmanager_default_status"><?php esc_html_e( 'Note: If Workflow Manager is deactivated, custom order status will be automatically changed to default order status setting', 'flow_notify_text' ); ?></label>
					</td>
				</tr>
			<?php endif; ?>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="bulk_action"><?php esc_html_e( 'Bulk Actions', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
					<input type="checkbox" id="bulk_action"
						name="bulk_action" <?php checked( $order_status->get_is_bulk_action(), true ); ?>
						<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>/>
					<span><?php esc_html_e( 'Allow option to be enabled in Order List bulk actions', 'flow_notify_text' ); ?></span>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="include_in_reports"><?php esc_html_e( 'Include in reports', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
					<input type="checkbox" id="include_in_reports"
						name="include_in_reports" <?php checked( $order_status->get_include_in_reports(), true ); ?>
						<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>/>
					<span><?php esc_html_e( 'For WooCommerce reporting, show orders data tagged with the Order Status', 'flow_notify_text' ); ?></span>
				</td>
			</tr>
			<tr class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_order_detail_row">
				<td class="zworkflowmanager_col_3 zworkflowmanager_disabled_padding">
					<label for="is_paid"><?php esc_html_e( 'Paid', 'flow_notify_text' ); ?></label>
				</td>
				<td class="zworkflowmanager_col_9 zworkflowmanager_disabled_padding zworkflowmanager_order_status_fields">
					<select id="is_paid" name="is_paid"
						<?php echo $order_status->is_core_status() ? 'disabled' : ''; ?>>
						<option value="yes" <?php echo selected( $order_status->is_paid(), true ); ?>><?php esc_html_e( 'Orders with this status have been paid', 'flow_notify_text' ); ?>
						</option>
						<option value="needs_payment" <?php echo selected( $order_status->needs_payment(), true ); ?>><?php esc_html_e( 'Orders with this status require payment', 'flow_notify_text' ); ?>
						</option>
						<option value="no" <?php echo selected( ! $order_status->needs_payment() && ! $order_status->is_paid(), true ); ?>><?php esc_html_e( 'Orders are neither paid nor require payment (Default)', 'flow_notify_text' ); ?>
						</option>
					</select>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
	<div class="zworkflowmanager_row zworkflowmanager_col_12 zworkflowmanager_disabled_padding">
		<div class="zworkflowmanager_button_wrap">
			<button type="submit"
					class="button button-primary"><?php esc_html_e( 'Save Order Status', 'flow_notify_text' ); ?></button>
			<?php
				$delete_link       = get_site_url() . '/wp-admin/admin.php?page=wc-workflows&tab=connection&zfn_operation_type=delete_order_status&order_status_id=' . $edit_order_status;
				$delete_nonce_link = wp_nonce_url( $delete_link, 'zfn_operation_type', 'zwf_nonce' );
			?>
			<a href="<?php echo esc_url( $delete_nonce_link ); ?>"
			class="button delete-notification-btn js-delete-order-status">
				<?php esc_html_e( 'Delete Order Status', 'flow_notify_text' ); ?>
			</a>
		</div>
	</div>
</form>


<script>
	function leadingWC( input ) {
		if ( input.value[0] === 'w' && input.value[1] === 'c' && input.value[2] === '-' ) {
		}
		else {
			input.value = 'wc-' + input.value;
		}
	}
</script>

<?php
/**
 * Flow-Notify activity tab
 *
 * @package Flow-Notify/templates/activities
 */

$section = ( isset( $_GET['section'] ) ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';
?>

<?php
/* You're on the second page */
echo '<div class="wrap woocommerce" style="margin-top:10px;">
            <h3 class="workflows-title">Activity</h3>
        </div>';
?>

<nav class="nav-tab-wrapper woo-nav-tab-wrapper">
	<a class="nav-tab<?php echo ( ( ! $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=activities"><?php echo esc_html( 'Activity' ); ?></a>
	<a class="nav-tab<?php echo ( ( 'opt-ins' === $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=activities&section=opt-ins"><?php echo esc_html( 'Opt-ins' ); ?></a>
	<a class="nav-tab<?php echo ( ( 'logs' === $section ) ? ' nav-tab-active' : '' ); ?>" href="?page=wc-workflows&tab=activities&section=logs"><?php echo esc_html( 'Logs' ); ?></a>
</nav>

<?php

require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-send.php';
require_once ZWORKFLOWMANAGER_PLUGIN_DIR . 'helper/class-zworkflowmanager-core-opt-ins.php';

$status_emails_list = new ZWORKFLOWMANAGER_Core_Opt_Ins();
$send_statuses_list = new ZWORKFLOWMANAGER_Core_Send();

switch ( $section ) {
	case 'logs':
		$send_statuses_list->print_logs();
		break;
	case 'opt-ins':
		$status_emails_list->print_overview();
		break;
	default:
		$send_statuses_list->print_activity();
}

<?php
/**
 * Flow-Notify supported-data-types
 *
 * @package Flow-Notify/templates/supported-data-types
 */

global $wpdb;

/* Get an array of all existing coupon codes */
$coupon_codes        = $wpdb->get_results(
	"SELECT post_title, post_name
                FROM $wpdb->posts
                WHERE post_type = 'shop_coupon'
                AND post_status = 'publish'
                "
);
$index               = 0;
$select_products_arr = array(
	'Product Name'         => 'product_',
	'Product URL'          => 'product_permalink_',
	'Product SKU'          => 'product_sku_',
	'Product Sale Price'   => 'product_sale_price_',
	'Product Sale Start'   => 'product_date_on_sale_from_',
	'Product Sale End'     => 'product_date_on_sale_to_',
	'Product Stock Status' => 'product_stock_status_',
	'Product Stock'        => 'product_stock_quantity_',
	'Product Rating'       => 'product_average_rating_',
);

?>
<div class="zwf__email-content-types wf-email-content-types-other">
	<input type="text" hidden name="product-values" class="js-product-values" value="">
	<div class="zwf__notification-email-wrap">
		<strong><?php esc_html_e( 'Supported Data Types:', 'flow_notify_text' ); ?></strong>
		<span class="notification-email-icon js-show-notification-email-icon"></span>
	</div>
	<a data-value="{order_id}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Order ID', 'flow_notify_text' ); ?></a>
	<a data-value="{date}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Date', 'flow_notify_text' ); ?></a>
	<a data-value="{payment_method}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Payment Method', 'flow_notify_text' ); ?></a>
	<a data-value="{shipping_method}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Shipping Method', 'flow_notify_text' ); ?></a>
	<a data-value="{transaction_id}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Transaction ID', 'flow_notify_text' ); ?></a>
	<a data-value="{billing_name}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Billing Name', 'flow_notify_text' ); ?></a>
	<a data-value="{billing_email}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Billing Email', 'flow_notify_text' ); ?></a>
	<a data-value="{order_total}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Order Total', 'flow_notify_text' ); ?></a>
	<a data-value="{shipping_total}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Shipping Total', 'flow_notify_text' ); ?></a>
	<a data-value="{tax_total}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Tax Total', 'flow_notify_text' ); ?></a>
	<a data-value="{site_name}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Site Name', 'flow_notify_text' ); ?></a>
	<a data-value="{site_url}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Site URL', 'flow_notify_text' ); ?></a>
	<a data-value="{order_status}"
	class="js-email-button zwf__email-button"><?php esc_html_e( 'Order Status', 'flow_notify_text' ); ?></a>
	<?php
	foreach ( $select_products_arr as $key => $item ) {
		?>
		<div id="timing_select-products-<?php echo esc_attr( $index ); ?>" class="zwf_select-wrap">
			<a class="zwf__email-button">
				<?php echo esc_textarea( $key ); ?>
			</a>
			<a class="zwf__close-input-btn"></a>
			<div class="zwf_preloder"></div>
			<input type="text" class="zwf_search-product" placeholder="Product name..." data-select-products="<?php echo esc_attr( $item ); ?>">
			<ul id="<?php echo esc_attr( $item ) . 'ul'; ?>" class="zwf_-select-list" data-offset="20">
			</ul>
		</div>
		<?php
		$index ++;
	}
	?>
	<div class="select-wrap">
		<a class="zwf__email-button">
			<?php esc_html_e( 'Coupon', 'flow_notify_text' ); ?>
		</a>
		<a class="zwf__close-btn"></a>
		<select class="js-select-coupon select-coupon" id="select-coupon" name="coupon_name">
			<option selected value=""></option>
			<?php
			foreach ( $coupon_codes as $coupon ) {
				$coupon_title = $coupon->post_title;
				$value        = 'coupon_' . $coupon->post_name;

				if ( preg_match_all( "/[\[^\'£$%^%&*()}{@:\'#~?><>,;@]/", $coupon_title ) ) {
					continue;
				}
				?>
				<option value="{<?php echo esc_attr( $value ); ?>}"><?php echo esc_textarea( $coupon_title ); ?></option>
			<?php } ?>
		</select>
	</div>
</div>


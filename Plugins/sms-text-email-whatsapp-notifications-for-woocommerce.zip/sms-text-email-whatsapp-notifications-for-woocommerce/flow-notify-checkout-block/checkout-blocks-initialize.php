<?php

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema;

$test = 300;

add_action(
	'woocommerce_blocks_loaded',
	function() {
		require_once 'class-blocks-integration.php';
		add_action(
			'woocommerce_blocks_checkout_block_registration',
			function( $integration_registry ) {
				$integration_registry->register( new Blocks_Integration() );
			}
		);

		if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			woocommerce_store_api_register_endpoint_data(
				array(
					'endpoint'        => CheckoutSchema::IDENTIFIER,
					'namespace'       => 'flow-notify-checkout-block',
					'data_callback'   => 'cb_data_callback',
					'schema_callback' => 'cb_schema_callback',
					'schema_type'     => ARRAY_A,
				)
			);
		}
	}
);


/**
 * Callback function to register endpoint data for blocks.
 *
 * @return array
 */
function cb_data_callback() {
	return array(
		'whatsapp_phone'              => '',
		'opt-in_text'                 => '',
		'zwf_country_code'            => '',
		'zworkflow_select_phone_type' => '',
		'zwf_communication'           => '',
	);
}

/**
 * Callback function to register schema for data.
 *
 * @return array
 */
function cb_schema_callback() {
	return array(
		'whatsapp_phone'              => array(
			'description' => __( 'WhatsApp phone', 'flow-notify-checkout-block' ),
			'type'        => array( 'string', 'null' ),
			'readonly'    => true,
		),
		'opt-in_text'                 => array(
			'description' => __( 'Get order notifications', 'flow-notify-checkout-block' ),
			'type'        => array( 'boolean', 'null' ),
			'readonly'    => true,
		),
		'zwf_country_code'            => array(
			'description' => __( 'Country code ', 'flow-notify-checkout-block' ),
			'type'        => array( 'string', 'null' ),
		),
		'zworkflow_select_phone_type' => array(
			'description' => __( 'Phone type', 'flow-notify-checkout-block' ),
			'type'        => array( 'string', 'null' ),
		),
		'zwf_communication'           => array(
			'description' => __( 'Communication preference', 'flow-notify-checkout-block' ),
			'type'        => array( 'string', 'null' ),
		),
	);
}

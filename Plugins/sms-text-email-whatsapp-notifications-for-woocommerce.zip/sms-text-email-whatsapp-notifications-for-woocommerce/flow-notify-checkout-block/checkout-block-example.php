<?php
/**
 * Flow-Notify Blocks Example
 *
 * @package Flow-Notify
 */

require_once 'checkout-blocks-initialize.php';

class Flow_Checkout_Block_Example {

	public function __construct() {
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( &$this, 'orddd_update_block_order_meta_delivery_date' ), 10, 2 );
		add_action( 'init', array( $this, 'create_block_interactive_block_block_init' ) );
		add_action( '__experimental_woocommerce_blocks_add_data_attributes_to_block', array( $this, 'add_attributes_to_block' ) );
	}

	public function create_block_interactive_block_block_init() {
		register_block_type(
			__DIR__,
			array(
				'render_callback' => array( $this, 'render_block_with_attribures' ),
			)
		);
	}

	public function render_block_with_attribures( $attributes = array(), $content = '' ) {
		if ( ! is_admin() ) {
			enqueue_frontend_script();
		}
		return $content;
	}

	public function add_attributes_to_block( $whitelisted_blocks ) {
		$whitelisted_blocks[] = 'flow-notify-checkout-block/communication-preferences';
		return $whitelisted_blocks;
	}

	public static function orddd_update_block_order_meta_delivery_date( $order, $request ) {
		$data = isset( $request['extensions']['flow-notify-checkout-block'] ) ? $request['extensions']['flow-notify-checkout-block'] : array();

		if ( isset( $data['whatsapp_phone'] ) ) {
			$order->update_meta_data( 'whatsapp_phone', $data['whatsapp_phone'] );
		}

		if ( isset( $data['opt-in_text'] ) ) {
			$order->update_meta_data( 'opt-in_text', sanitize_text_field( $data['opt-in_text'] ) );
			$order->save();
		}

		if ( isset( $data['zwf_country_code'] ) ) {
			$order->update_meta_data( 'zworkflow_billing_code', preg_replace( '/[^0-9]/', '', $data['zwf_country_code'] ) );
			$order->save();
		}

		if ( isset( $data['zworkflow_select_phone_type'] ) ) {
			$order->update_meta_data( 'zworkflow_select_phone_type', sanitize_text_field( $data['zworkflow_select_phone_type'] ) );
			$order->save();
		}

		if ( isset( $data['zwf_communication'] ) ) {
			$order->update_meta_data( 'communication_preference', sanitize_text_field( $data['zwf_communication'] ) );
			$order->save();
		}

	}

}

$checkout_block_example = new Flow_Checkout_Block_Example();

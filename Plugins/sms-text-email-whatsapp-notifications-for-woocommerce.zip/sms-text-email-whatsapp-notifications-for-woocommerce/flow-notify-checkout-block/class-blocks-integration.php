<?php
/**
 * Flow-Notify Blocks Integration
 *
 * @package Flow-Notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

define( 'ORDD_BLOCK_VERSION', '1.0.0' );

class Blocks_Integration implements IntegrationInterface {

	/**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'communication-preferences';
	}

	/**
	 * When called invokes any initialization/setup for the integration.
	 */
	public function initialize() {
		$this->register_block_frontend_scripts();
		$this->register_block_editor_scripts();
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return array( 'checkout-block-frontend' );
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return array( 'communication-preferences-block-editor' );
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 *
	 * @return array
	 */
	public function get_script_data() {
		return array();
	}

	/**
	 * Register scripts for delivery date block editor.
	 *
	 * @return void
	 */
	public function register_block_editor_scripts() {
		$script_url        = plugins_url( 'build/index.js', __FILE__ );
		$script_asset_path = plugins_url( 'build/index.asset.php', __FILE__ );
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => $this->get_file_version( $script_asset_path ),
			);

		wp_register_script(
			'communication-preferences-block-editor',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	/**
	 * Register scripts for frontend block.
	 *
	 * @return void
	 */
	public function register_block_frontend_scripts() {
		$script_url        = plugins_url( 'build/checkout-block-frontend.js', __FILE__ );
		$script_asset_path = plugins_url( 'build/checkout-block-frontend.asset.php', __FILE__ );

		$script_asset = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => $this->get_file_version( $script_asset_path ),
			);

		wp_register_script(
			'checkout-block-frontend',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		$arr_settings = array();

		if ( isset( get_option( 'notification_email_settings' )['communication_methods_sms'] ) ) {
			$arr_settings['sms'] = 'SMS';
		}

		if ( isset( get_option( 'notification_email_settings' )['communication_methods_whatsapp'] ) ) {
			$arr_settings['whatsapp'] = 'WhatsApp';
		}

		if ( isset( get_option( 'notification_email_settings' )['communication_methods_email'] ) ) {
			$arr_settings['email'] = 'Email';
		}

		wp_localize_script(
			'checkout-block-frontend',
			'communication_methods',
			array(
				'chosen_communication_methods' => get_user_meta( get_current_user_id(), 'communication_preference', true ),
				'communication_array'          => $arr_settings,
			)
		);
	}

	/**
	 * Get the file modified time as a cache buster if we're in dev mode.
	 *
	 * @param string $file Local path to the file.
	 * @return string The cache buster value to use for the given file.
	 */
	protected function get_file_version( $file ) {
		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG && file_exists( $file ) ) {
			return filemtime( $file );
		}
		return ORDD_BLOCK_VERSION;
	}

}

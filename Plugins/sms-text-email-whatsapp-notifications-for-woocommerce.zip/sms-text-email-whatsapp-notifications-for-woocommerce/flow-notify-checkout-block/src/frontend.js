import metadata from './block.json';
import { useEffect, useState, useCallback } from '@wordpress/element';
const { registerPlugin } = wp.plugins;
const { ExperimentalOrderMeta } = wc.blocksCheckout;
import { render, Suspense } from '@wordpress/element';

// Global import
const { registerCheckoutBlock } = wc.blocksCheckout;

export const Block = ({  children, checkoutExtensionData }) => {
	const [ phoneType, setPhoneType ] = useState('billing');
	const { setExtensionData } = checkoutExtensionData;
	const [activeItem, setActiveItem] = useState(false);
	const [inputValue, setInputValue] = useState('');
	const [countryCode, setCountryCode] = useState('');
	const [isChecked, setIsChecked] = useState(false);
	const [methods, setMethods] = useState([]);
	const [selectedMethod, setSelectedMethod] = useState('');
	const [isActiveBlock, setIsActiveBlock] = useState(false);

	useEffect(() => {
		if (window.communication_methods.communication_array) {
			const parsedMethods = Object.entries(window.communication_methods.communication_array).map(([key, value]) => ({
				method: key,
				label: value,
			}));
			setMethods(parsedMethods);

			const chosenMethod = window.communication_methods.chosen_communication_methods;
			if (chosenMethod && parsedMethods.some(({ method }) => method === chosenMethod)) {
				setSelectedMethod(chosenMethod);
				if (chosenMethod === 'whatsapp') {
					setIsActiveBlock(true);
				}
			}
		}
	}, []);


	const handlePhoneTypeChange = useCallback((event) => {
		const value = event.target.value;
		setPhoneType(value);
		setExtensionData('flow-notify-checkout-block', 'zworkflow_select_phone_type', value);
	}, [setPhoneType, setExtensionData]);

	useEffect( () => {
		setExtensionData( 'flow-notify-checkout-block', 'whatsapp_phone', inputValue );
	}, [inputValue, setExtensionData]);

	const handleChange = useCallback(
		( value ) => {
			setInputValue( value.target.value );
			setExtensionData( 'flow-notify-checkout-block', 'whatsapp_phone', value );
		},
		[ setInputValue. setExtensionData ]
	);

	const handleCountryCodeChange = useCallback(
		(event) => {
			setCountryCode(event.target.value);
			setExtensionData('flow-notify-checkout-block', 'zwf_country_code', event.target.value);
		},
		[setCountryCode, setExtensionData]
	);

	const handleCheckboxChange = useCallback(
		(event) => {
			setIsChecked(event.target.checked);
			setExtensionData('flow-notify-checkout-block', 'opt-in_text', event.target.checked);
		},
		[setIsChecked, setExtensionData]
	);

	const handleMethodChange = useCallback((event) => {
		const newMethod = event.target.value;
		setSelectedMethod(newMethod);
		setExtensionData('flow-notify-checkout-block', 'zwf_communication', newMethod);
		if (newMethod === 'whatsapp') {
			setIsActiveBlock(true);
		} else {
			setPhoneType('billing');
			setActiveItem('');
			setIsActiveBlock(false);
		}
	}, [setSelectedMethod, setPhoneType, setActiveItem, setExtensionData]);

	return (
		<div className={'zwf-gutenberg-fields'}>
			<div className="wc-block-components-checkbox">
				<label htmlFor="zwf-checkbox-notifications">
					<input
						id="zwf-checkbox-notifications"
						className="wc-block-components-checkbox__input"
						type="checkbox"
						aria-invalid="false"
						name="opt-in_text"
						checked={isChecked}
						onChange={handleCheckboxChange}
					/>
					<svg className="wc-block-components-checkbox__mark" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 20">
						<path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"></path>
					</svg>
					<span className="wc-block-components-checkbox__label">Get order notifications</span>
				</label>
			</div>
			<p className="form-row form-row-wide validate-required" id="communication_preference_field" data-priority="">
				<label htmlFor="communication_preference" className="">Communication Preference<abbr className="required" title="required">*</abbr></label>
				<span className="woocommerce-input-wrapper">
                    <select name="zwf_communication" value={selectedMethod} onChange={handleMethodChange}>
						{methods.map(({ method, label }) => (
							<option key={method} value={method}>{label}</option>
						))}
					</select>
                </span>
			</p>
			<ul id="zworkflow-select-phone-type-block" className={`${isActiveBlock ? 'active' : ''}`}>
				<li onClick={() => { setActiveItem('li-1') }}>
					<input type="radio" id="zworkflow-select-whatsapp" name="zworkflow_select_phone_type" value="whatsapp" checked={phoneType === 'whatsapp'} onChange={handlePhoneTypeChange} />
					<label className="zworkflow-select-phone-label" htmlFor="zworkflow-select-whatsapp">Use my WhatsApp number</label>
					<div className={`zworkflow-select-cheque ${"li-1"===activeItem ? 'show' : ''}`}>
						<input type="tel" name="zwf_country_code" className="zwf_country_code" placeholder="Country Code" value={countryCode} onChange={handleCountryCodeChange} />
						<input type="tel" name="whatsapp_phone"
							   placeholder="Phone for WhatsApp" value={inputValue} onChange={handleChange} />
					</div>
				</li>
				<li onClick={() => {setActiveItem('li-2')}}>
					<input type="radio" id="zworkflow-select-billing" name="zworkflow_select_phone_type" value="billing" checked={phoneType === 'billing'} onChange={handlePhoneTypeChange} />
					<label className="zworkflow-select-phone-label" htmlFor="zworkflow-select-billing">Use my billing phone number</label>
				</li>
			</ul>
		</div>
	);
};

const options = {
	metadata,
	component: Block
};

registerCheckoutBlock(options);


window.addEventListener( 'DOMContentLoaded', () => {
	const element = document.getElementById('zwf_checkout-block-notify');
	if ( element ) {
		const attributes = { ...element.dataset };
		render(
			<Suspense fallback={ <div className="wp-block-placeholder" /> }>
				<Block { ...attributes } />
			</Suspense>,
			element
		);
	}
} );
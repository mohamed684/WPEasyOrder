const Webpack = require( 'webpack' );
const path = require( 'path' );
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const BrowserSyncPlugin = require('browser-sync-webpack-plugin');

const dotenv = require('dotenv');
dotenv.config();

const PATH_ASSETS = path.resolve(__dirname, 'assets');
const WP_URL = process.env.WP_URL || 'http://localhost:8002';
const DEV_HTTP_PORT = process.env.DEV_HTTP_PORT || 8003;

module.exports = {
    entry: {
        app: './src/main.js',
        libsApp: './src/libs.js',
        appPublic: './src/js/main-public.js',
    },

    output: {
        filename: 'js/[name].js',
        path: PATH_ASSETS
    },
    mode: 'production',
    externals: {
        jquery: 'jQuery',
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            },
            {
                test: /\.(sa|sc|c)ss$/,
                use: [
                    {
                        loader: MiniCssExtractPlugin.loader,
                        options: {
                            publicPath: '../',
                        },
                    },
                    'css-loader',
                    'resolve-url-loader',
                    {
                        loader: 'sass-loader',
                        options: {
                            sourceMap: true
                        }
                    },
                ],
            },
            {
                test: /\.(png|svg|jpe?g|gif)$/,
                type: 'asset/resource',
                generator: {
                    filename: content => content.filename.replace(/^src\//, '')
                }
            },
            {
                test: /\.(ttf|eot|otf|woff|woff2)$/,
                type: 'asset/resource',
                generator: {
                    filename: content => content.filename.replace(/^src\//, '')
                }
            }
        ]
    },

    plugins: [
        new Webpack.ProvidePlugin(
            {
                $: 'jquery',
                jQuery: 'jquery',
                'window.jQuery': 'jquery'
            }
        ),
        new MiniCssExtractPlugin({
            filename: 'styles/[name].css',
            chunkFilename: 'styles/[id].css'
        }),
        new BrowserSyncPlugin({
            files: [
                path.resolve(__dirname, 'assets/**/*'),
                path.resolve(__dirname, '**/*.php'),
            ],
            proxy: WP_URL,
            port: DEV_HTTP_PORT,
            ui: false,
            ghostMode: false,
        }),
    ],
};

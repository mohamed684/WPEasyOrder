<?php
/**
 * The admin-settings functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Settings {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * The settings of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $settings    The settings of this plugin.
	 */
	private $settings;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of this plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->settings    = get_option( 'order_notifications_on_whatsapp_for_woocommerce' );

		add_action( 'admin_head', array( $this, 'remove_menus' ) );
		add_filter( 'submenu_file', array( $this, 'submenu_file' ), 99, 2 );
				add_filter( 'parent_file', array( $this, 'parent_file' ), 99, 1 );
		add_action( 'cmb2_admin_init', array( $this, 'register_options' ) );

				add_action( 'cmb2_after_options-page_form_order_notifications_on_whatsapp_for_woocommerce', array( $this, 'tab1_help' ), 10, 2 );

	}

	/**
	 * Remove menus.
	 *
	 * @since 1.0.0
	 */
	public function remove_menus() {
		global $submenu;
		if ( isset( $submenu['order_notifications_on_whatsapp_for_woocommerce'] ) ) {
			$hide_menus = $this->get_settings_sub();
			foreach ( $submenu['order_notifications_on_whatsapp_for_woocommerce'] as $k => $v ) {
				if ( in_array( $v[2], $hide_menus, true ) ) {
					unset( $submenu['order_notifications_on_whatsapp_for_woocommerce'][ $k ] );
				}
			}
		}
	}

	/**
	 * Change the submenu file name.
	 *
	 * @since  1.0.0
	 * @param  string $submenu_file Submenu file.
	 * @param  string $parent_file  Parent file.
	 * @return string    $submenu_file  Submenu file.
	 */
	public function submenu_file( $submenu_file, $parent_file ) {
		$sub_menu_items = $this->get_settings_sub();
		if ( isset( $_GET['page'] ) && in_array( $_GET['page'], $sub_menu_items ) ) {
			return 'order_notifications_on_whatsapp_for_woocommerce';
		}

		if ( 'post-new.php?post_type=whatsapp-templates' == $submenu_file ) {
			return 'edit.php?post_type=whatsapp-templates';
		}

		return $submenu_file;
	}

		/**
		 * Change parentmenu file name
		 *
		 * @since   1.0.0
		 * @param string $parent_file Parent file name.
		 * @return string $parent_file Parent file name.
		 */
	public function parent_file( $parent_file ) {
		if ( 'edit.php?post_type=whatsapp-templates' == $parent_file ) {
			return 'order_notifications_on_whatsapp_for_woocommerce';
		}
		return $parent_file;
	}

	/**
	 * Return menu names to remove
	 *
	 * @since  1.0.0
	 * @return array
	 */
	public function get_settings_sub() {
		return array( 'order_notifications_on_whatsapp_for_woocommerce_order_notification', 'order_notifications_on_whatsapp_for_woocommerce_chat' );
	}



	/**
	 * Register plugin options for settings
	 *
	 * @since 1.0.0
	 */
	public function register_options() {
		/**
		 * Registers main options page menu item and form.
		 */
		$args = array(
			'id'           => 'order_notifications_on_whatsapp_for_woocommerce',
			'title'        => esc_html__( 'WhatsApp Notifications Settings', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'menu_title'   => esc_html__( 'WhatsApp Notifications', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'object_types' => array( 'options-page' ),
			'option_key'   => 'order_notifications_on_whatsapp_for_woocommerce',
			'tab_group'    => 'order_notifications_on_whatsapp_for_woocommerce',
			'tab_title'    => esc_html__( 'WhatsApp API', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'icon_url'     => 'dashicons-whatsapp',
			'position'     => 65,
			// 'parent_slug'  => 'onww-page',
		);

		$main_options = new_cmb2_box( $args );

		$fields = $this->get_whatsapp_settings();
		foreach ( $fields as $field ) {
			$main_options->add_field( $field );
		}

		if ( 'on' != $this->settings['enable'] ) {
			return;
		}

		$args = array(
			'id'           => 'order_notifications_on_whatsapp_for_woocommerce_order_notification',
			'title'        => esc_html__( 'Order Notification Triggers', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'object_types' => array( 'options-page' ),
			'option_key'   => 'order_notifications_on_whatsapp_for_woocommerce_order_notification',
			'tab_group'    => 'order_notifications_on_whatsapp_for_woocommerce',
			'tab_title'    => esc_html__( 'Order Notification Triggers', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'parent_slug'  => 'order_notifications_on_whatsapp_for_woocommerce',
		);

		$order_notification_options = new_cmb2_box( $args );

		$fields = $this->get_order_notification_settings();
		foreach ( $fields as $field ) {
			$order_notification_options->add_field( $field );
		}

		$args = array(
			'id'           => 'order_notifications_on_whatsapp_for_woocommerce_chat',
			'title'        => esc_html__( 'Click to Chat', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'object_types' => array( 'options-page' ),
			'option_key'   => 'order_notifications_on_whatsapp_for_woocommerce_chat',
			'tab_group'    => 'order_notifications_on_whatsapp_for_woocommerce',
			'tab_title'    => esc_html__( 'Click to Chat', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'parent_slug'  => 'order_notifications_on_whatsapp_for_woocommerce',
		);

		$order_notification_options = new_cmb2_box( $args );

		$fields = $this->get_click_to_chat_settings();
		foreach ( $fields as $field ) {
			$order_notification_options->add_field( $field );
		}
	}

	/**
	 * Return general settings fields
	 *
	 * @since  1.0.0
	 * @return array     $fields
	 */
	public function get_whatsapp_settings() {
		$fields = array();

		$fields['enable'] = array(
			'name' => esc_html__( 'Enable', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enable Order otifications on WhatsApp ', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'enable',
			'type' => 'checkbox',
		);

		$fields['api_token'] = array(
			'name' => esc_html__( 'WhatsApp Bearer Token', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Bearer Token to be used for all other WhatsApp Business API calls, you can get it from Meta WhatsApp Manager.', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'api_token',
			'type' => 'text',
		);

		$fields['whatsapp_mobile_number'] = array(
			'name' => esc_html__( 'WhatsApp Mobile Number', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enter your WhatsApp mobile number for your business', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'whatsapp_mobile_number',
			'type' => 'text',
		);

		$fields['whatsapp_business_account_id'] = array(
			'name' => esc_html__( 'WhatsApp Business Account ID', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enter your unique WhatsApp Business ID', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'whatsapp_business_account_id',
			'type' => 'text',
		);

		$fields['whatsapp_phone_number_id'] = array(
			'name' => esc_html__( 'WhatsApp Phone number ID', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enter your WhatsApp Mobile Number ID', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'whatsapp_phone_number_id',
			'type' => 'text',
		);

		$fields['whatsapp_admin_mobile_number'] = array(
			'name' => esc_html__( 'Admin Mobile Number', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enter Admin Mobile Number', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'whatsapp_admin_mobile_number',
			'type' => 'text',
		);

		$desc = esc_html__( 'Enable the logging of errors.', 'order-notifications-on-whatsapp-for-woocommerce' );

		if ( defined( 'WC_LOG_DIR' ) ) {
			$log_url = add_query_arg( 'tab', 'logs', add_query_arg( 'page', 'wc-status', admin_url( 'admin.php' ) ) );
			$log_key = $this->plugin_name . '-' . sanitize_file_name( wp_hash( $this->plugin_name ) ) . '-log';
			$log_url = add_query_arg( 'log_file', $log_key, $log_url );
			/* translators: %1$s: Link start, %2$s : Link End. */
			$desc .= ' | ' . sprintf( esc_html__( '%1$sView Log%2$s', 'order-notifications-on-whatsapp-for-woocommerce' ), '<a href="' . esc_url( $log_url ) . '">', '</a>' );
		}

		$fields['enable_log'] = array(
			'name' => esc_html__( 'Enable Logging', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => $desc,
			'id'   => 'enable_log',
			'type' => 'checkbox',
		);

		return apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_whatsapp_api_settings_fields', $fields );
	}

	/**
	 * Return general settings fields
	 *
	 * @since  1.0.0
	 * @return array     $fields
	 */
	public function get_order_notification_settings() {
		$fields = array();

		$templates = array( '' => esc_html__( 'Select Template', 'order-notifications-on-whatsapp-for-woocommerce' ) );

		$args = array(
			'post_type'      => 'whatsapp-templates',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'meta_query'     => array(
				'key'     => '_whatsapp_message_status',
				'value'   => 'APPROVED',
				'compare' => '=',
			),
		);

		$templates_query = new WP_Query( $args );

		if ( $templates_query->have_posts() ) {
			while ( $templates_query->have_posts() ) {
				$templates_query->the_post();
				$templates[ get_the_id() ] = get_the_title() . ' (' . get_post_meta( get_the_id(), 'template_name', true ) . ')';
			}
		}

		$fields['opt_user'] = array(
			'name' => esc_html__( 'Opt-in Consent on Checkout', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'opt_user',
			'type' => 'title',
		);

		$fields['opt_in_checkbox_checkout_enable'] = array(
			'name' => esc_html__( 'Enable', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Add an opt-in checkbox to WooCommerce checkout form. Once enabled, WhatsApp notification will be sent only to customers who opt-in during checkout.', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'opt_in_checkbox_checkout_enable',
			'type' => 'checkbox',
		);
		$fields['opt_in_checkbox_checkout_label']  = array(
			'name'    => esc_html__( 'Opt-in Checkbox Text', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc'    => esc_html__( 'Enter text for the opt-in checkbox', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'default' => esc_html__( 'Receive order updates on WhatsApp', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'      => 'opt_in_checkbox_checkout_label',
			'type'    => 'text',
		);

		$fields['new_order_notification_title'] = array(
			'name' => esc_html__( 'New Order Notification', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'New Order Notification to admin ', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'new_order_notification_title',
			'type' => 'title',
		);

		$fields['new_order_notification_enable'] = array(
			'name' => esc_html__( 'Enable', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enable New Order Notification', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'new_order_notification_enable',
			'type' => 'checkbox',
		);

		$fields['new_order_notification_template'] = array(
			'name'    => esc_html__( 'Message Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			/* translators: %1$s a tag with link, %2$s a close tag */
			'desc'    => sprintf( esc_html__( 'Select message template, or %1$s Create new template %2$s', 'order-notifications-on-whatsapp-for-woocommerce' ), '<a href="' . esc_url( admin_url( 'post-new.php?post_type=whatsapp-templates' ) ) . '">', '</a>' ),
			'id'      => 'new_order_notification_template',
			'type'    => 'select',
			'options' => $templates,
		);

		$status = wc_get_order_statuses();
		$prefix = 'wc-';
		foreach ( $status as $key => $val ) {
			if ( substr( $key, 0, strlen( $prefix ) ) == $prefix ) {
				$key = substr( $key, strlen( $prefix ) );

				$fields[ 'order_notification_title_' . $key ] = array(
					'name' => sprintf( '%s %s', esc_html__( 'Send Notification when Order is', 'order-notifications-on-whatsapp-for-woocommerce' ), $val ),
					'desc' => sprintf( '%s %s', __( 'This notification will send when a order status is changed to', 'order-notifications-on-whatsapp-for-woocommerce' ), $val ),
					'id'   => 'order_notification_title_' . $key,
					'type' => 'title',
				);

				$fields[ 'enable_order_notification_admin_' . $key ] = array(
					'name' => esc_html__( 'Send notification to admin', 'order-notifications-on-whatsapp-for-woocommerce' ),
					'desc' => sprintf( '%s %s', __( 'Send notification to admin when order is', 'order-notifications-on-whatsapp-for-woocommerce' ), $val ),
					'id'   => 'enable_order_notification_admin_' . $key,
					'type' => 'checkbox',
				);

				$fields[ 'order_notification_admin_template_' . $key ] = array(
					'name'    => esc_html__( 'Message Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
					/* translators: %1$s a tag with link, %2$s a close tag */
					'desc'    => sprintf( esc_html__( 'Select message template, or %1$s Create new template %2$s', 'order-notifications-on-whatsapp-for-woocommerce' ), '<a href="' . esc_url( admin_url( 'post-new.php?post_type=whatsapp-templates' ) ) . '">', '</a>' ),
					'id'      => 'order_notification_admin_template_' . $key,
					'type'    => 'select',
					'options' => $templates,
				);

				$fields[ 'enable_order_notification_customer_' . $key ] = array(
					'name' => esc_html__( 'Send notification to customer', 'order-notifications-on-whatsapp-for-woocommerce' ),
					'desc' => sprintf( '%s %s', __( 'Send notification to customer when order is', 'order-notifications-on-whatsapp-for-woocommerce' ), $val ),
					'id'   => 'enable_order_notification_customer_' . $key,
					'type' => 'checkbox',
				);

				$fields[ 'order_notification_customer_template_' . $key ] = array(
					'name'    => esc_html__( 'Message Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
					/* translators: %1$s a tag with link, %2$s a close tag */
					'desc'    => sprintf( esc_html__( 'Select message template, or %1$s Create new template %2$s', 'order-notifications-on-whatsapp-for-woocommerce' ), '<a href="' . esc_url( admin_url( 'post-new.php?post_type=whatsapp-templates' ) ) . '">', '</a>' ),
					'id'      => 'order_notification_customer_template_' . $key,
					'type'    => 'select',
					'options' => $templates,
				);
			}
		}

		return apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_whatsapp_get_order_notification_settings_fields', $fields );
	}

	/**
	 * Return click to chat settings fields
	 *
	 * @since  1.0.0
	 * @return array     $fields
	 */
	public function get_click_to_chat_settings() {
		$fields = array();

		$fields['ctc_enable'] = array(
			'name' => esc_html__( 'Enable', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Show a click to chat button on your website for your visitors to start a WhatsApp chat with you.', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'ctc_enable',
			'type' => 'checkbox',
		);

		$fields['ctc_number'] = array(
			'name' => esc_html__( 'Whatsapp Number', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'Enter your WhatsApp number with country code. Eg. +919988776655', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'ctc_number',
			'type' => 'text',
		);

		$fields['ctc_message'] = array(
			'name' => esc_html__( 'Greeting Message', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc' => esc_html__( 'This text will be added to user\'s WhatsApp chat text field when they click on the button.', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'   => 'ctc_message',
			'type' => 'text',
		);

		$fields['ctc_style'] = array(
			'name'        => esc_html__( 'Button Style', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'desc'        => esc_html__( 'Choose a button style. A preview is shown at the bottom right of this screen. You can update the button style by writing custom CSS in your theme.', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'id'          => 'ctc_style',
			'type'        => 'radio_image',
			'options'     => array(
				'style-1' => esc_html__( 'Style 1', 'order-notifications-on-whatsapp-for-woocommerce' ),
				'style-2' => esc_html__( 'Style 2', 'order-notifications-on-whatsapp-for-woocommerce' ),
				'style-3' => esc_html__( 'Style 3', 'order-notifications-on-whatsapp-for-woocommerce' ),
			),
			'images_path' => ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_URL,
			'images'      => array(
				'style-1' => 'admin/images/style-1.png',
				'style-2' => 'admin/images/style-2.png',
				'style-3' => 'admin/images/style-3.png',
			),
		);

		return apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_whatsapp_get_click_to_chat_settings_fields', $fields );
	}

	/**
	 * Display settings help.
	 *
	 * @since  1.0.0
	 * @param string $object_id Object id.
	 * @param object $cmb2 Cmb2 Object.
	 */
	public function tab1_help( $object_id, $cmb2 ) {
		include_once ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_DIR . '/admin/partials/admin-dashboard.php';
	}

}

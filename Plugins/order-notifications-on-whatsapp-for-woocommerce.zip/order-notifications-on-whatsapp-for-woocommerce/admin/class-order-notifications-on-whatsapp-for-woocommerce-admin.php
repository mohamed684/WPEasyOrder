<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */

use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of this plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		add_action( 'admin_menu', array( $this, 'admin_menu_page' ) );

		add_action( 'admin_notices', array( $this, 'show_notices' ), 30 );

		add_action( 'add_meta_boxes', array( $this, 'add_order_meta_box' ) );
		add_action( 'wp_ajax_onww_order_message_load_message', array( $this, 'order_message_load_message' ) );
		add_action( 'wp_ajax_onww_order_message_send_message', array( $this, 'order_message_send_message' ) );

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name . '-featherlight', plugin_dir_url( __FILE__ ) . 'featherlight/featherlight.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/order-notifications-on-whatsapp-for-woocommerce-admin.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( $this->plugin_name . '-featherlight', plugin_dir_url( __FILE__ ) . 'featherlight/featherlight.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/order-notifications-on-whatsapp-for-woocommerce-admin.js', array( 'jquery' ), $this->version, false );

		$params = array(
			'ajax_url'              => WC()->ajax_url(),
			'wc_ajax_url'           => WC_AJAX::get_endpoint( '%%endpoint%%' ),
			'fetch_templates_nonce' => wp_create_nonce( 'onww-fetch-templates-nonce' ),
			'map_variables_nonce'   => wp_create_nonce( 'onww-map-variables-nonce' ),
			'load_mesage_nonce'     => wp_create_nonce( 'onww-load-message-nonce' ),
			'send_message_nonce'    => wp_create_nonce( 'onww-send-message-nonce' ),
		);

		wp_localize_script( $this->plugin_name, 'onww_admin_params', $params );
	}

	/**
	 * Add meta box to orders.
	 *
	 * @since     1.0.0
	 */
	public function add_order_meta_box() {
		$screen = wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled() ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

		add_meta_box( 'onww_order_meta_box', esc_html__( 'WhatsApp Messages', 'order-notifications-on-whatsapp-for-woocommerce' ), array( $this, 'display_order_meta_box' ), $screen, 'side', 'default' );
	}

	/**
	 * Display metabox.
	 *
	 * @since     1.0.0
	 * @param WP_Post $post Post.
	 */
	public function display_order_meta_box( $post ) {
		$order    = ( $post instanceof WP_Post ) ? wc_get_order( $post->ID ) : $post;
		$order_id = $order->get_id();
		?>
		<p><?php echo esc_attr__( 'Message', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></p>
		<p><textarea name="onww_order_message" id="onww_order_message" class="input-text" style="width: 100%;" rows="4"></textarea></p>
		<div class="onww_order_message_buttons">
			<a data-order-id="<?php echo esc_attr( $order_id ); ?>" class="button onww_order_message_buttons_load_message" href="javascript:void(0)"><?php echo esc_attr__( 'Load Order Status Message', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></a>
			<a data-order-id="<?php echo esc_attr( $order_id ); ?>" class="button onww_order_message_buttons_send_message button-primary" href="javascript:void(0)"><?php echo esc_attr__( 'Send', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></a>
		</div>
		<?php
	}

	/**
	 * Load order message.
	 *
	 * @since     1.0.0
	 */
	public function order_message_load_message() {
		if ( isset( $_POST['security'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['security'] ) ), 'onww-load-message-nonce' ) ) {
			$order_id = isset( $_POST['order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : 0;
			if ( ! empty( $order_id ) ) {
				$order                 = wc_get_order( $order_id );
				$order_status          = $order->get_status();
				$notification_settings = get_option( 'order_notifications_on_whatsapp_for_woocommerce_order_notification' );
				$template_id           = $notification_settings[ "order_notification_customer_template_{$order_status}" ];
				$template_cls          = new Order_Notifications_On_Whatsapp_For_Woocommerce_Template();
				$preview               = $template_cls->preview_template_message( $template_id, $order );
				wp_send_json_success(
					array(
						'message'     => $preview,
						'template_id' => $template_id,
					)
				);
			}
		}
	}

	/**
	 * Send order message.
	 *
	 * @since     1.0.0
	 */
	public function order_message_send_message() {
		if ( isset( $_POST['security'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['security'] ) ), 'onww-send-message-nonce' ) ) {
			$order_id = isset( $_POST['order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : 0;
			if ( ! empty( $order_id ) ) {

				$template_id = '';
				$message     = '';
				if ( isset( $_POST['template_id'] ) ) {
					$template_id = sanitize_text_field( wp_unslash( $_POST['template_id'] ) );
				}
				if ( isset( $_POST['message'] ) ) {
					$message = sanitize_text_field( wp_unslash( $_POST['message'] ) );
				}
				$status = apply_filters( 'onww_custom_message', '', $order_id, $template_id, $message );
				wp_send_json_success(
					array(
						'message'     => $status,
						'template_id' => $template_id,
					)
				);
			}
		}
	}

	/**
	 * Register admin menu page
	 *
	 * @since 1.0.0
	 */
	public function admin_menu_page() {

		add_submenu_page(
			'order_notifications_on_whatsapp_for_woocommerce',
			esc_html__( 'WhatsApp Notifications Settings', 'order-notifications-on-whatsapp-for-woocommerce' ),
			esc_html__( 'Settings', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'manage_options',
			'order_notifications_on_whatsapp_for_woocommerce'
		);
	}

	/**
	 * Display set up the plugin banner.
	 *
	 * @since 1.0.0
	 */
	public function show_notices() {
		$options = get_option( 'order_notifications_on_whatsapp_for_woocommerce', false );
		if ( false == $options ) {
			?>
	<div class="notice notice-info">
		<p>
			<?php
				/* translators: %1$s a tag with link, %2$s a close tag */
				echo sprintf( esc_html__( 'Thank you for installing the Order Notifications on WhatsApp for WooCommerce plugin. To get started, please %1$sconfigure the plugin%2$s to send WhatsApp notifications for your WooCommerce orders using the official WhatsApp Cloud APIs.', 'order-notifications-on-whatsapp-for-woocommerce' ), '<a href="' . esc_url( admin_url( 'admin.php?page=order_notifications_on_whatsapp_for_woocommerce' ) ) . '">', '</a>' );
			?>
				</p>
	</div>
			<?php
		}
	}

}

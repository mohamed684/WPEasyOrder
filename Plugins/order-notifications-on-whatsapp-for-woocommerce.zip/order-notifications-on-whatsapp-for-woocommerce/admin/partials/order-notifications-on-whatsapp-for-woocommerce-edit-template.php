<?php
/**
 * Provide a edit the whatsapp template view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin/partials
 */

?>
<div class="onww-edit-template-container">
	<h3><?php esc_html_e( 'Map Variables', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></h3>
	<form method="post" class="onww-edit-template-form">
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'Template Name', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></th>
				<td><?php echo esc_html( $template->name ); ?></td>
			</tr>
			<?php
			foreach ( $template->components as $component ) {
				if ( 'HEADER' == $component->type ) {
					$header_text      = $component->text;
					$head_param_count = substr_count( $header_text, '{{' );
					?>
					<tr>
						<th><?php esc_html_e( 'Header Text', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></th>
						<td><?php echo wp_kses( $component->text, array( 'br' => array() ) ); ?></td>
					</tr>
					<?php
					if ( ! empty( $head_param_count ) ) {
						?>
						<tr>
							<th><?php esc_html_e( 'Head Parameters', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></th>
							<td>
								<?php
								for ( $hpc = 1; $hpc <= $head_param_count; $hpc++ ) {
									?>
									<div class="onww-edit-template-header-parm">
										<strong><?php echo esc_html( " {{{$hpc}}} " ); ?></strong>
										<select name="onww-template-header-parms[]">
											<option value=""><?php esc_html_e( 'Select Value', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></option>
											<?php
											foreach ( $template_placeholders as $placeholder => $placeholder_value ) {
												?>
												<option value="<?php echo esc_attr( $placeholder ); ?>"><?php echo esc_attr( $placeholder_value ); ?></option>
												<?php
											}
											?>
										</select>
									</div>
									<?php
								}
								?>
							</td>
						</tr>
						<?php
					}
				}

				if ( 'BODY' == $component->type ) {
					$body_text        = $component->text;
					$body_param_count = substr_count( $body_text, '{{' );
					?>
					<tr>
						<th><?php esc_html_e( 'Body Text', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></th>
						<td><?php echo wp_kses( nl2br( $component->text ), array( 'br' => array() ) ); ?></td>
					</tr>
					<?php
					if ( ! empty( $body_param_count ) ) {
						?>
						<tr>
							<th><?php esc_html_e( 'Body Parameters', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></th>
							<td>
								<?php
								for ( $bpc = 1; $bpc <= $body_param_count; $bpc++ ) {
									?>
									<div class="onww-edit-template-body-parm">
										<strong><?php echo esc_html( " {{{$bpc}}} " ); ?></strong>
										<select name="onww-template-body-parms[]">
											<option value=""><?php echo esc_html_e( 'Select Value', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></option>
											<?php
											foreach ( $template_placeholders as $placeholder => $placeholder_value ) {
												?>
												<option  value="<?php echo esc_attr( $placeholder ); ?>"><?php echo esc_attr( $placeholder_value ); ?></option>
												<?php
											}
											?>
										</select>
									</div>
									<?php
								}
								?>
							</td>
						</tr>
						<?php
					}
				}
			}
			?>
			<tr>
				<th> </th>
				<td class="onww-edit-template-buttons"> <input type="submit" class="button button-primary" value="<?php esc_html_e( 'Save Changes', 'order-notifications-on-whatsapp-for-woocommerce' ); ?>"> <span class="whatsapp-template-update-message"><?php esc_html_e( 'Template Updated. Loading next template..', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></span> </td>
			</tr>
		</table>
		<input type="hidden" name="template_id" value="<?php echo esc_attr( $template->id ); ?>" />
		<input type="hidden" name="action" value="onww_template_map_variables_update" />

		<?php
		wp_nonce_field( 'onww-update-template-nonce' );
		?>
	</form>
</div>

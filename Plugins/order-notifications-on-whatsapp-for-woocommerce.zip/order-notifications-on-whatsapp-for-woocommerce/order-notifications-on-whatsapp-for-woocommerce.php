<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://procomsoftsol.com
 * @since             1.0.0
 * @package           Order_Notifications_On_Whatsapp_For_Woocommerce
 *
 * @wordpress-plugin
 * Plugin Name:       Order Notifications on WhatsApp for WooCommerce
 * Plugin URI:        https://procomsoftsol.com
 * Description:       Send WhatsApp notifications using the official WhatsApp Cloud APIs for WooCommerce orders.
 * Version:           1.0.0
 * Author:            Procom
 * Author URI:        https://procomsoftsol.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       order-notifications-on-whatsapp-for-woocommerce
 * Domain Path:       /languages
 * Requires at least: 4.6
 * Tested up to: 6.5
 * WC requires at least: 4.0.0
 * WC tested up to:   9.0
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * 
 * Woo: 18734003901727:b24450e29fb2819ddbb369bddd99bcbe
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_VERSION', '1.0.0' );

/**
 * Currently plugin file.
 */
define( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_FILE', __FILE__ );

/**
 * Currently plugin basename.
 */
define( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_BASENAME', plugin_basename( ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_FILE ) );

/**
 * Currently plugin dir.
 */
define( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

/**
 * Currently plugin url.
 */
define( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_URL', plugin_dir_url( __FILE__ ) );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-order-notifications-on-whatsapp-for-woocommerce-activator.php
 */
function activate_order_notifications_on_whatsapp_for_woocommerce() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-activator.php';
	Order_Notifications_On_Whatsapp_For_Woocommerce_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-order-notifications-on-whatsapp-for-woocommerce-deactivator.php
 */
function deactivate_order_notifications_on_whatsapp_for_woocommerce() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-deactivator.php';
	Order_Notifications_On_Whatsapp_For_Woocommerce_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_order_notifications_on_whatsapp_for_woocommerce' );
register_deactivation_hook( __FILE__, 'deactivate_order_notifications_on_whatsapp_for_woocommerce' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_order_notifications_on_whatsapp_for_woocommerce() {

	$plugin = new Order_Notifications_On_Whatsapp_For_Woocommerce();
	$plugin->run();
}

/**
 * Check if WooCommerce is active
 */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || ( is_multisite() && array_key_exists( 'woocommerce/woocommerce.php', get_site_option( 'active_sitewide_plugins' ) ) ) ) {
	run_order_notifications_on_whatsapp_for_woocommerce();
} else {
	add_action( 'admin_notices', 'order_notifications_on_whatsapp_for_woocommerce_installed_notice' );
}

/**
 * Display WooCommerce Activation notice.
 */
function order_notifications_on_whatsapp_for_woocommerce_installed_notice() {
	?>
	<div class="error">
		<p><?php echo esc_html__( 'Order Notifications on WhatsApp for WooCommerce requires the WooCommerce. Please install or activate woocommere', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></p>
	</div>
	<?php
}

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

